// Peak Focus App - ADHD-Friendly Productivity App
class PeakFocusApp {
    constructor() {
        this.currentScreen = 'dashboard';
        this.timerState = {
            isRunning: false,
            isPaused: false,
            currentTime: 25 * 60, // 25 minutes in seconds
            totalTime: 25 * 60,
            sessionCount: 0
        };
        
        this.appData = {
            tasksCompletedToday: 3,
            currentStreak: 5,
            mountainProgress: 65,
            dailyPomodoroGoal: 4,
            currentSession: 1,
            tasks: [
                {id: 1, title: "Review project proposal", completed: true, priority: "high"},
                {id: 2, title: "Reply to emails", completed: true, priority: "medium"},
                {id: 3, title: "Plan weekly schedule", completed: false, priority: "high"},
                {id: 4, title: "Call dentist", completed: false, priority: "low"}
            ],
            settings: {
                fontSize: 'medium',
                notifications: true,
                sound: true,
                vibration: true,
                focusDuration: 25,
                breakDuration: 5
            }
        };
        
        this.taskIdCounter = 5;
        this.timerInterval = null;
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.renderTasks();
        this.updateDashboard();
        this.updateSettings();
        this.applyFontSize();
    }
    
    setupEventListeners() {
        // Navigation
        document.querySelectorAll('[data-screen]').forEach(button => {
            button.addEventListener('click', (e) => {
                const targetScreen = e.target.closest('[data-screen]').dataset.screen;
                this.navigateToScreen(targetScreen);
            });
        });
        
        // Timer controls
        document.getElementById('timer-start').addEventListener('click', () => this.startTimer());
        document.getElementById('timer-pause').addEventListener('click', () => this.pauseTimer());
        document.getElementById('timer-reset').addEventListener('click', () => this.resetTimer());
        
        // Task management
        document.getElementById('add-task-btn').addEventListener('click', () => this.addTask());
        document.getElementById('new-task-input').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.addTask();
        });
        
        // Settings
        document.getElementById('font-size').addEventListener('change', (e) => this.updateFontSize(e.target.value));
        document.getElementById('notifications').addEventListener('change', (e) => this.updateSetting('notifications', e.target.checked));
        document.getElementById('sound').addEventListener('change', (e) => this.updateSetting('sound', e.target.checked));
        document.getElementById('vibration').addEventListener('change', (e) => this.updateSetting('vibration', e.target.checked));
        document.getElementById('focus-duration').addEventListener('change', (e) => this.updateFocusDuration(parseInt(e.target.value)));
        document.getElementById('break-duration').addEventListener('change', (e) => this.updateSetting('breakDuration', parseInt(e.target.value)));
    }
    
    navigateToScreen(screenName) {
        // Hide all screens
        document.querySelectorAll('.screen').forEach(screen => {
            screen.classList.remove('active');
        });
        
        // Show target screen
        document.getElementById(screenName).classList.add('active');
        
        // Update navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-screen="${screenName}"].nav-item`).classList.add('active');
        
        this.currentScreen = screenName;
        
        // Screen-specific actions
        if (screenName === 'dashboard') {
            this.updateDashboard();
        } else if (screenName === 'pomodoro') {
            this.resetTimer();
        }
    }
    
    // Timer functionality
    startTimer() {
        if (this.timerState.isPaused) {
            this.resumeTimer();
        } else {
            this.timerState.isRunning = true;
            this.timerState.currentTime = this.appData.settings.focusDuration * 60;
            this.timerState.totalTime = this.appData.settings.focusDuration * 60;
        }
        
        document.getElementById('timer-start').classList.add('hidden');
        document.getElementById('timer-pause').classList.remove('hidden');
        
        this.timerInterval = setInterval(() => {
            this.updateTimer();
        }, 1000);
        
        this.updateClimberPosition();
    }
    
    pauseTimer() {
        this.timerState.isPaused = true;
        this.timerState.isRunning = false;
        clearInterval(this.timerInterval);
        
        document.getElementById('timer-start').classList.remove('hidden');
        document.getElementById('timer-pause').classList.add('hidden');
    }
    
    resumeTimer() {
        this.timerState.isPaused = false;
        this.timerState.isRunning = true;
        
        this.timerInterval = setInterval(() => {
            this.updateTimer();
        }, 1000);
    }
    
    resetTimer() {
        this.timerState.isRunning = false;
        this.timerState.isPaused = false;
        this.timerState.currentTime = this.appData.settings.focusDuration * 60;
        this.timerState.totalTime = this.appData.settings.focusDuration * 60;
        
        clearInterval(this.timerInterval);
        
        document.getElementById('timer-start').classList.remove('hidden');
        document.getElementById('timer-pause').classList.add('hidden');
        
        this.updateTimerDisplay();
        this.updateTimerProgress();
        this.resetClimberPosition();
    }
    
    updateTimer() {
        if (this.timerState.currentTime > 0) {
            this.timerState.currentTime--;
            this.updateTimerDisplay();
            this.updateTimerProgress();
            this.updateClimberPosition();
        } else {
            this.completeTimer();
        }
    }
    
    completeTimer() {
        this.timerState.isRunning = false;
        this.timerState.sessionCount++;
        this.appData.currentSession++;
        
        clearInterval(this.timerInterval);
        
        document.getElementById('timer-start').classList.remove('hidden');
        document.getElementById('timer-pause').classList.add('hidden');
        
        // Update mountain progress
        this.appData.mountainProgress = Math.min(100, this.appData.mountainProgress + 10);
        this.updateMountainVisualization();
        
        // Play completion sound if enabled
        if (this.appData.settings.sound) {
            this.playCompletionSound();
        }
        
        // Show celebration
        this.showCelebration('Amazing! You completed a focus session!');
        
        this.resetTimer();
    }
    
    updateTimerDisplay() {
        const minutes = Math.floor(this.timerState.currentTime / 60);
        const seconds = this.timerState.currentTime % 60;
        
        document.getElementById('timer-minutes').textContent = minutes.toString().padStart(2, '0');
        document.getElementById('timer-seconds').textContent = seconds.toString().padStart(2, '0');
    }
    
    updateTimerProgress() {
        const progress = (this.timerState.totalTime - this.timerState.currentTime) / this.timerState.totalTime;
        const circumference = 2 * Math.PI * 90; // radius is 90
        const dashOffset = circumference * (1 - progress);
        
        document.getElementById('timer-progress').style.strokeDashoffset = dashOffset;
    }
    
    updateClimberPosition() {
        const progress = (this.timerState.totalTime - this.timerState.currentTime) / this.timerState.totalTime;
        const maxLeft = 170; // Adjust based on container width
        const leftPosition = 10 + (progress * maxLeft);
        
        document.querySelector('.climber-animated').style.left = `${leftPosition}px`;
    }
    
    resetClimberPosition() {
        document.querySelector('.climber-animated').style.left = '10px';
    }
    
    // Task management
    addTask() {
        const input = document.getElementById('new-task-input');
        const title = input.value.trim();
        
        if (title) {
            const newTask = {
                id: this.taskIdCounter++,
                title: title,
                completed: false,
                priority: 'medium'
            };
            
            this.appData.tasks.unshift(newTask);
            input.value = '';
            this.renderTasks();
            
            // Provide immediate feedback
            this.showToast('Task added successfully!', 'success');
        }
    }
    
    toggleTask(taskId) {
        const task = this.appData.tasks.find(t => t.id === taskId);
        if (task) {
            task.completed = !task.completed;
            
            if (task.completed) {
                this.appData.tasksCompletedToday++;
                this.appData.mountainProgress = Math.min(100, this.appData.mountainProgress + 5);
                this.updateMountainVisualization();
                this.showToast('Great job completing that task!', 'success');
                
                // Check if we should show celebration
                if (this.appData.tasksCompletedToday % 5 === 0) {
                    setTimeout(() => {
                        this.showCelebration('Incredible! You\'ve completed 5 tasks!');
                    }, 1000);
                }
            } else {
                this.appData.tasksCompletedToday = Math.max(0, this.appData.tasksCompletedToday - 1);
                this.appData.mountainProgress = Math.max(0, this.appData.mountainProgress - 5);
                this.updateMountainVisualization();
            }
            
            this.renderTasks();
            this.updateDashboard();
        }
    }
    
    deleteTask(taskId) {
        this.appData.tasks = this.appData.tasks.filter(t => t.id !== taskId);
        this.renderTasks();
        this.showToast('Task removed', 'info');
    }
    
    renderTasks() {
        const taskList = document.getElementById('task-list');
        
        if (this.appData.tasks.length === 0) {
            taskList.innerHTML = `
                <div class="task-item" style="text-align: center; opacity: 0.6;">
                    <p>No tasks yet. Add your first task above! 🎯</p>
                </div>
            `;
            return;
        }
        
        taskList.innerHTML = this.appData.tasks.map(task => `
            <div class="task-item ${task.completed ? 'completed' : ''}">
                <div class="task-checkbox ${task.completed ? 'checked' : ''}" onclick="app.toggleTask(${task.id})">
                    ${task.completed ? '✓' : ''}
                </div>
                <div class="task-content">
                    <div class="task-title ${task.completed ? 'completed' : ''}">${task.title}</div>
                    <div class="task-priority priority-${task.priority}">${task.priority}</div>
                </div>
                <button class="btn btn--outline btn--sm" onclick="app.deleteTask(${task.id})" style="margin-left: auto;">
                    Delete
                </button>
            </div>
        `).join('');
    }
    
    // Dashboard updates
    updateDashboard() {
        // Update stats
        document.querySelector('.stats-grid .stat-card:first-child .stat-number').textContent = this.appData.tasksCompletedToday;
        document.querySelector('.stats-grid .stat-card:last-child .stat-number').textContent = this.appData.currentSession - 1;
        
        // Update streak
        document.querySelector('.streak-number').textContent = this.appData.currentStreak;
        
        // Update mountain visualization
        this.updateMountainVisualization();
    }
    
    updateMountainVisualization() {
        const skyReveal = document.querySelector('.sky-reveal');
        const progressNumber = document.querySelector('.progress-number');
        
        skyReveal.style.height = `${this.appData.mountainProgress}%`;
        progressNumber.textContent = `${this.appData.mountainProgress}%`;
    }
    
    // Settings management
    updateSetting(key, value) {
        this.appData.settings[key] = value;
        
        if (key === 'fontSize') {
            this.applyFontSize();
        }
        
        this.showToast('Setting updated', 'success');
    }
    
    updateFontSize(size) {
        this.appData.settings.fontSize = size;
        this.applyFontSize();
        this.showToast('Font size updated', 'success');
    }
    
    updateFocusDuration(minutes) {
        this.appData.settings.focusDuration = minutes;
        this.timerState.currentTime = minutes * 60;
        this.timerState.totalTime = minutes * 60;
        this.updateTimerDisplay();
        this.updateTimerProgress();
        this.showToast('Focus duration updated', 'success');
    }
    
    applyFontSize() {
        document.body.dataset.fontSize = this.appData.settings.fontSize;
    }
    
    updateSettings() {
        document.getElementById('font-size').value = this.appData.settings.fontSize;
        document.getElementById('notifications').checked = this.appData.settings.notifications;
        document.getElementById('sound').checked = this.appData.settings.sound;
        document.getElementById('vibration').checked = this.appData.settings.vibration;
        document.getElementById('focus-duration').value = this.appData.settings.focusDuration;
        document.getElementById('break-duration').value = this.appData.settings.breakDuration;
        
        // Update session info
        document.getElementById('current-session').textContent = this.appData.currentSession;
        document.getElementById('daily-goal').textContent = this.appData.dailyPomodoroGoal;
    }
    
    // Celebration and feedback
    showCelebration(message) {
        document.getElementById('celebration-message').textContent = message;
        this.navigateToScreen('celebration');
        
        // Auto-hide celebration after 5 seconds
        setTimeout(() => {
            if (this.currentScreen === 'celebration') {
                this.navigateToScreen('dashboard');
            }
        }, 5000);
    }
    
    showToast(message, type = 'info') {
        // Create toast element
        const toast = document.createElement('div');
        toast.className = `status status--${type}`;
        toast.textContent = message;
        toast.style.position = 'fixed';
        toast.style.top = '20px';
        toast.style.left = '50%';
        toast.style.transform = 'translateX(-50%)';
        toast.style.zIndex = '1000';
        toast.style.padding = '12px 20px';
        toast.style.borderRadius = '8px';
        toast.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
        
        document.body.appendChild(toast);
        
        // Remove toast after 3 seconds
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 3000);
    }
    
    playCompletionSound() {
        // Create a simple audio context for completion sound
        if ('AudioContext' in window || 'webkitAudioContext' in window) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            const ctx = new AudioContext();
            
            // Create a simple success tone
            const oscillator = ctx.createOscillator();
            const gainNode = ctx.createGain();
            
            oscillator.connect(gainNode);
            gainNode.connect(ctx.destination);
            
            oscillator.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
            oscillator.frequency.setValueAtTime(659.25, ctx.currentTime + 0.1); // E5
            oscillator.frequency.setValueAtTime(783.99, ctx.currentTime + 0.2); // G5
            
            gainNode.gain.setValueAtTime(0.3, ctx.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
            
            oscillator.start(ctx.currentTime);
            oscillator.stop(ctx.currentTime + 0.5);
        }
    }
    
    // Accessibility helpers
    announceToScreenReader(message) {
        const announcement = document.createElement('div');
        announcement.setAttribute('aria-live', 'polite');
        announcement.setAttribute('aria-atomic', 'true');
        announcement.className = 'sr-only';
        announcement.textContent = message;
        
        document.body.appendChild(announcement);
        
        setTimeout(() => {
            document.body.removeChild(announcement);
        }, 1000);
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new PeakFocusApp();
});

// Handle keyboard navigation
document.addEventListener('keydown', (e) => {
    // Escape key to go back
    if (e.key === 'Escape' && window.app && window.app.currentScreen !== 'dashboard') {
        window.app.navigateToScreen('dashboard');
    }
    
    // Space bar to start/pause timer when on pomodoro screen
    if (e.key === ' ' && window.app && window.app.currentScreen === 'pomodoro') {
        e.preventDefault();
        if (window.app.timerState.isRunning) {
            window.app.pauseTimer();
        } else {
            window.app.startTimer();
        }
    }
});

// Handle visibility change to pause timer when tab is not active
document.addEventListener('visibilitychange', () => {
    if (window.app && window.app.timerState.isRunning && document.hidden) {
        // Optional: pause timer when user switches tabs
        // This can be helpful for ADHD users to prevent losing progress
        console.log('Tab hidden - timer continues running');
    }
});

// Service worker registration for offline support (if needed in future)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        // Could register a service worker here for offline functionality
        console.log('Peak Focus App loaded successfully');
    });
}