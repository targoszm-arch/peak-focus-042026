-- Create relationships table to link tasks, projects, and notes
CREATE TABLE public.relationships (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  source_type TEXT NOT NULL CHECK (source_type IN ('task', 'note', 'project')),
  source_id UUID NOT NULL,
  target_type TEXT NOT NULL CHECK (target_type IN ('task', 'note', 'project')),
  target_id UUID NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  -- Prevent duplicate relationships
  UNIQUE(source_type, source_id, target_type, target_id),
  -- Prevent self-relationships
  CHECK (NOT (source_type = target_type AND source_id = target_id))
);

-- Enable RLS
ALTER TABLE public.relationships ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can manage their own relationships" 
ON public.relationships 
FOR ALL 
USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX idx_relationships_source ON public.relationships(source_type, source_id);
CREATE INDEX idx_relationships_target ON public.relationships(target_type, target_id);
CREATE INDEX idx_relationships_user ON public.relationships(user_id);

-- Create function to get related items
CREATE OR REPLACE FUNCTION public.get_related_items(
  p_user_id UUID,
  p_entity_type TEXT,
  p_entity_id UUID
)
RETURNS TABLE (
  relationship_id UUID,
  related_type TEXT,
  related_id UUID,
  related_title TEXT,
  related_created_at TIMESTAMP WITH TIME ZONE
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    r.id as relationship_id,
    r.target_type as related_type,
    r.target_id as related_id,
    CASE 
      WHEN r.target_type = 'task' THEN t.title
      WHEN r.target_type = 'note' THEN n.title
      WHEN r.target_type = 'project' THEN p.name
    END as related_title,
    CASE 
      WHEN r.target_type = 'task' THEN t.created_at
      WHEN r.target_type = 'note' THEN n.created_at
      WHEN r.target_type = 'project' THEN p.created_at
    END as related_created_at
  FROM public.relationships r
  LEFT JOIN public.tasks t ON (r.target_type = 'task' AND r.target_id = t.id AND t.user_id = p_user_id)
  LEFT JOIN public.notes n ON (r.target_type = 'note' AND r.target_id = n.id AND n.user_id = p_user_id)
  LEFT JOIN public.projects p ON (r.target_type = 'project' AND r.target_id = p.id AND p.user_id = p_user_id)
  WHERE r.user_id = p_user_id 
    AND r.source_type = p_entity_type 
    AND r.source_id = p_entity_id
  
  UNION ALL
  
  SELECT 
    r.id as relationship_id,
    r.source_type as related_type,
    r.source_id as related_id,
    CASE 
      WHEN r.source_type = 'task' THEN t.title
      WHEN r.source_type = 'note' THEN n.title
      WHEN r.source_type = 'project' THEN p.name
    END as related_title,
    CASE 
      WHEN r.source_type = 'task' THEN t.created_at
      WHEN r.source_type = 'note' THEN n.created_at
      WHEN r.source_type = 'project' THEN p.created_at
    END as related_created_at
  FROM public.relationships r
  LEFT JOIN public.tasks t ON (r.source_type = 'task' AND r.source_id = t.id AND t.user_id = p_user_id)
  LEFT JOIN public.notes n ON (r.source_type = 'note' AND r.source_id = n.id AND n.user_id = p_user_id)
  LEFT JOIN public.projects p ON (r.source_type = 'project' AND r.source_id = p.id AND p.user_id = p_user_id)
  WHERE r.user_id = p_user_id 
    AND r.target_type = p_entity_type 
    AND r.target_id = p_entity_id;
END;
$$;