
-- Create notes table for project-specific notes
CREATE TABLE public.notes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  project_id UUID REFERENCES public.projects(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  content TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for notes
ALTER TABLE public.notes ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for notes
CREATE POLICY "Users can view their own notes" 
  ON public.notes 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own notes" 
  ON public.notes 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own notes" 
  ON public.notes 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own notes" 
  ON public.notes 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Create checklists table for task subtasks
CREATE TABLE public.checklists (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  task_id UUID NOT NULL REFERENCES public.tasks(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  title TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for checklists
ALTER TABLE public.checklists ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for checklists
CREATE POLICY "Users can manage their own checklists" 
  ON public.checklists 
  FOR ALL 
  USING (auth.uid() = user_id);

-- Create checklist items table
CREATE TABLE public.checklist_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  checklist_id UUID NOT NULL REFERENCES public.checklists(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  text TEXT NOT NULL,
  completed BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  completed_at TIMESTAMP WITH TIME ZONE
);

-- Enable RLS for checklist items
ALTER TABLE public.checklist_items ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for checklist items
CREATE POLICY "Users can manage their own checklist items" 
  ON public.checklist_items 
  FOR ALL 
  USING (auth.uid() = user_id);

-- Create task attachments table
CREATE TABLE public.task_attachments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  task_id UUID NOT NULL REFERENCES public.tasks(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size INTEGER,
  content_type TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for task attachments
ALTER TABLE public.task_attachments ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for task attachments
CREATE POLICY "Users can manage their own task attachments" 
  ON public.task_attachments 
  FOR ALL 
  USING (auth.uid() = user_id);

-- Create note attachments table
CREATE TABLE public.note_attachments (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  note_id UUID NOT NULL REFERENCES public.notes(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  file_name TEXT NOT NULL,
  file_path TEXT NOT NULL,
  file_size INTEGER,
  content_type TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for note attachments
ALTER TABLE public.note_attachments ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for note attachments
CREATE POLICY "Users can manage their own note attachments" 
  ON public.note_attachments 
  FOR ALL 
  USING (auth.uid() = user_id);

-- Create storage buckets for file uploads
INSERT INTO storage.buckets (id, name, public) VALUES ('task-files', 'task-files', false);
INSERT INTO storage.buckets (id, name, public) VALUES ('note-files', 'note-files', false);

-- Create storage policies for task files
CREATE POLICY "Users can upload task files" 
  ON storage.objects 
  FOR INSERT 
  WITH CHECK (bucket_id = 'task-files' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view their task files" 
  ON storage.objects 
  FOR SELECT 
  USING (bucket_id = 'task-files' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their task files" 
  ON storage.objects 
  FOR DELETE 
  USING (bucket_id = 'task-files' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Create storage policies for note files
CREATE POLICY "Users can upload note files" 
  ON storage.objects 
  FOR INSERT 
  WITH CHECK (bucket_id = 'note-files' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view their note files" 
  ON storage.objects 
  FOR SELECT 
  USING (bucket_id = 'note-files' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their note files" 
  ON storage.objects 
  FOR DELETE 
  USING (bucket_id = 'note-files' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Add updated_at trigger for notes
CREATE TRIGGER update_notes_updated_at
  BEFORE UPDATE ON public.notes
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();
