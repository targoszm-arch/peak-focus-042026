
-- Fix 1: Update the update_updated_at_column function with explicit search_path
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$function$;

-- Fix 2: Create a function to validate file uploads server-side
CREATE OR REPLACE FUNCTION public.validate_file_upload(
    file_name TEXT,
    content_type TEXT,
    file_size INTEGER
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
    allowed_types TEXT[] := ARRAY[
        'image/jpeg',
        'image/png', 
        'image/gif',
        'image/webp',
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'text/plain',
        'text/csv'
    ];
    max_file_size INTEGER := 10485760; -- 10MB in bytes
BEGIN
    -- Check file size
    IF file_size > max_file_size THEN
        RETURN FALSE;
    END IF;
    
    -- Check content type
    IF content_type IS NULL OR NOT (content_type = ANY(allowed_types)) THEN
        RETURN FALSE;
    END IF;
    
    -- Check for suspicious file extensions
    IF file_name ~* '\.(exe|bat|cmd|scr|pif|com|dll|vbs|js|jar|php|asp|jsp)$' THEN
        RETURN FALSE;
    END IF;
    
    RETURN TRUE;
END;
$function$;

-- Fix 3: Add validation triggers for file uploads
CREATE OR REPLACE FUNCTION public.validate_task_attachment()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
BEGIN
    IF NOT public.validate_file_upload(NEW.file_name, NEW.content_type, NEW.file_size) THEN
        RAISE EXCEPTION 'Invalid file upload: file type not allowed or size too large';
    END IF;
    RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.validate_note_attachment()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
BEGIN
    IF NOT public.validate_file_upload(NEW.file_name, NEW.content_type, NEW.file_size) THEN
        RAISE EXCEPTION 'Invalid file upload: file type not allowed or size too large';
    END IF;
    RETURN NEW;
END;
$function$;

-- Create triggers for file upload validation
DROP TRIGGER IF EXISTS validate_task_attachment_trigger ON public.task_attachments;
CREATE TRIGGER validate_task_attachment_trigger
    BEFORE INSERT OR UPDATE ON public.task_attachments
    FOR EACH ROW
    EXECUTE FUNCTION public.validate_task_attachment();

DROP TRIGGER IF EXISTS validate_note_attachment_trigger ON public.note_attachments;
CREATE TRIGGER validate_note_attachment_trigger
    BEFORE INSERT OR UPDATE ON public.note_attachments
    FOR EACH ROW
    EXECUTE FUNCTION public.validate_note_attachment();

-- Fix 4: Add rate limiting table for auth attempts
CREATE TABLE IF NOT EXISTS public.auth_rate_limit (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ip_address INET NOT NULL,
    email TEXT,
    attempt_type TEXT NOT NULL, -- 'signin', 'signup', 'reset'
    attempts INTEGER DEFAULT 1,
    first_attempt TIMESTAMP WITH TIME ZONE DEFAULT now(),
    last_attempt TIMESTAMP WITH TIME ZONE DEFAULT now(),
    blocked_until TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Add RLS to rate limit table
ALTER TABLE public.auth_rate_limit ENABLE ROW LEVEL SECURITY;

-- Create policy for rate limiting (allow service role to manage)
CREATE POLICY "Service role can manage rate limits" ON public.auth_rate_limit
    FOR ALL USING (auth.role() = 'service_role');

-- Add index for performance
CREATE INDEX IF NOT EXISTS idx_auth_rate_limit_ip_email ON public.auth_rate_limit(ip_address, email);
CREATE INDEX IF NOT EXISTS idx_auth_rate_limit_blocked_until ON public.auth_rate_limit(blocked_until);
