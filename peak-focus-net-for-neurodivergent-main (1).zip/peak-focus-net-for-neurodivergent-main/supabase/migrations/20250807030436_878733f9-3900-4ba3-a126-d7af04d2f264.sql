-- Add note_id column to checklists table to support both task and note checklists
ALTER TABLE public.checklists 
ADD COLUMN note_id UUID REFERENCES public.notes(id) ON DELETE CASCADE;

-- Make task_id nullable since we now support both tasks and notes
ALTER TABLE public.checklists 
ALTER COLUMN task_id DROP NOT NULL;

-- Add constraint to ensure either task_id or note_id is provided, but not both
ALTER TABLE public.checklists 
ADD CONSTRAINT checklists_single_parent_check 
CHECK (
  (task_id IS NOT NULL AND note_id IS NULL) OR 
  (task_id IS NULL AND note_id IS NOT NULL)
);

-- Update RLS policies to include note-based access
DROP POLICY IF EXISTS "Users can manage their own checklists" ON public.checklists;

CREATE POLICY "Users can manage their own checklists" 
ON public.checklists 
FOR ALL 
USING (
  auth.uid() = user_id OR
  (note_id IS NOT NULL AND EXISTS (
    SELECT 1 FROM public.notes 
    WHERE notes.id = checklists.note_id AND notes.user_id = auth.uid()
  ))
);