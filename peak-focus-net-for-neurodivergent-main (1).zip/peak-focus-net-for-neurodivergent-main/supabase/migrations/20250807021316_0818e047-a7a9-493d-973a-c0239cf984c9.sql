-- Create storage policies for note-files bucket

-- Policy for users to insert their own files
CREATE POLICY "Users can upload their own note files" 
ON storage.objects 
FOR INSERT 
WITH CHECK (
  bucket_id = 'note-files' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Policy for users to view their own files
CREATE POLICY "Users can view their own note files" 
ON storage.objects 
FOR SELECT 
USING (
  bucket_id = 'note-files' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Policy for users to update their own files
CREATE POLICY "Users can update their own note files" 
ON storage.objects 
FOR UPDATE 
USING (
  bucket_id = 'note-files' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);

-- Policy for users to delete their own files
CREATE POLICY "Users can delete their own note files" 
ON storage.objects 
FOR DELETE 
USING (
  bucket_id = 'note-files' AND 
  auth.uid()::text = (storage.foldername(name))[1]
);