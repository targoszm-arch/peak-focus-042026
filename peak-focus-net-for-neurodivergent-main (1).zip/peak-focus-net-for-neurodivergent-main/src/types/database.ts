
export type Priority = 'low' | 'medium' | 'high' | 'urgent';
export type TaskStatus = 'todo' | 'in_progress' | 'completed' | 'archived';
export type MountainTheme = 'alpine' | 'desert' | 'volcanic' | 'coastal' | 'forest';

export interface Project {
  id: string;
  user_id: string;
  name: string;
  description?: string;
  color: string;
  icon: string;
  estimated_duration: number;
  actual_duration: number;
  due_date?: string;
  completion_percentage: number;
  mountain_theme: MountainTheme;
  created_at: string;
  updated_at: string;
}

export interface Task {
  id: string;
  user_id: string;
  project_id?: string;
  title: string;
  description?: string;
  estimated_duration: number;
  actual_duration?: number;
  due_date?: string;
  due_time?: string;
  priority: Priority;
  status: TaskStatus;
  pomodoro_sessions_planned: number;
  pomodoro_sessions_completed: number;
  completion_date?: string;
  created_at: string;
  updated_at: string;
}

export interface Tag {
  id: string;
  user_id: string;
  name: string;
  color: string;
  created_at: string;
}

export interface Note {
  id: string;
  user_id: string;
  project_id?: string;
  title: string;
  content?: string;
  created_at: string;
  updated_at: string;
}

export interface Checklist {
  id: string;
  task_id: string;
  user_id: string;
  title: string;
  created_at: string;
}

export interface ChecklistItem {
  id: string;
  checklist_id: string;
  user_id: string;
  text: string;
  completed: boolean;
  created_at: string;
  completed_at?: string;
}

export interface TaskAttachment {
  id: string;
  task_id: string;
  user_id: string;
  file_name: string;
  file_path: string;
  file_size?: number;
  content_type?: string;
  created_at: string;
}

export interface NoteAttachment {
  id: string;
  note_id: string;
  user_id: string;
  file_name: string;
  file_path: string;
  file_size?: number;
  content_type?: string;
  created_at: string;
}

export interface PomodoroSession {
  id: string;
  user_id: string;
  task_id?: string;
  project_id?: string;
  duration_minutes: number;
  completed_at: string;
  notes?: string;
}

export interface DailyProgress {
  id: string;
  user_id: string;
  date: string;
  total_tasks_planned: number;
  total_tasks_completed: number;
  total_minutes_planned: number;
  total_minutes_completed: number;
  mountain_reduction_percentage: number;
  sky_reveal_level: number;
  created_at: string;
  updated_at: string;
}
