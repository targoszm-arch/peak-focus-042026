import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Folder, Check, X, Edit2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { Project, MountainTheme } from '@/types/database';
interface ProjectFormProps {
  onSubmit: (projectData: Partial<Project>) => Promise<void>;
  trigger?: React.ReactNode;
  project?: Project;
}
const defaultMountainThemes: {
  value: MountainTheme;
  label: string;
  color: string;
}[] = [{
  value: 'alpine',
  label: 'Alpine',
  color: '#3b82f6'
}, {
  value: 'desert',
  label: 'Desert',
  color: '#f59e0b'
}, {
  value: 'volcanic',
  label: 'Volcanic',
  color: '#ef4444'
}, {
  value: 'coastal',
  label: 'Coastal',
  color: '#06b6d4'
}, {
  value: 'forest',
  label: 'Forest',
  color: '#22c55e'
}];
export const ProjectForm = ({
  onSubmit,
  trigger,
  project
}: ProjectFormProps) => {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState(project?.name || '');
  const [description, setDescription] = useState(project?.description || '');
  const [color, setColor] = useState(project?.color || '#3b82f6');
  const [theme, setTheme] = useState<MountainTheme>(project?.mountain_theme || 'alpine');

  // Simplified theme handling - just use the default themes without editing
  const [editingTheme, setEditingTheme] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const {
    toast
  } = useToast();
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      toast({
        title: "Project name required",
        description: "Please enter a project name",
        variant: "destructive"
      });
      return;
    }
    setLoading(true);
    try {
      const projectData: Partial<Project> = {
        name: name.trim(),
        description: description.trim() || undefined,
        color,
        mountain_theme: theme,
        icon: 'folder',
        estimated_duration: 0,
        actual_duration: 0,
        completion_percentage: 0
      };
      console.log('[PROJECT_FORM] Submitting project data:', projectData);
      await onSubmit(projectData);
      if (!project) {
        setName('');
        setDescription('');
        setColor('#3b82f6');
        setTheme('alpine');
      }
      setOpen(false);
    } catch (error) {
      console.error('Project form error:', error);
      toast({
        title: project ? "Failed to update project" : "Failed to create project",
        description: "Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  const handleThemeEdit = (themeValue: string, currentLabel: string) => {
    setEditingTheme(themeValue);
    setEditValue(currentLabel);
  };
  const handleThemeSave = (themeValue: string) => {
    // For now, just cancel editing since we're not persisting custom labels
    setEditingTheme(null);
    setEditValue('');
  };
  const handleThemeCancel = () => {
    setEditingTheme(null);
    setEditValue('');
  };
  const handleKeyDown = (e: React.KeyboardEvent, themeValue: string) => {
    e.stopPropagation();
    if (e.key === 'Enter') {
      handleThemeSave(themeValue);
    } else if (e.key === 'Escape') {
      handleThemeCancel();
    }
  };
  const handleThemeSelect = (themeValue: MountainTheme, themeColor: string) => {
    if (editingTheme !== themeValue) {
      setTheme(themeValue);
      setColor(themeColor);
      console.log('[PROJECT_FORM] Theme selected:', themeValue, 'Color:', themeColor);
    }
  };
  return <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || <Button size="sm" variant="outline">
            <Plus className="w-4 h-4 mr-2" />
            New Project
          </Button>}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] max-w-[95vw]">
        <DialogHeader>
          <DialogTitle>
            {project ? 'Edit Project' : 'Create New Project'}
          </DialogTitle>
          <DialogDescription>
            {project ? 'Update your project details and settings.' : 'Set up a new project with a theme and color scheme.'}
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name">Project Name</Label>
            <Input id="name" value={name} onChange={e => setName(e.target.value)} placeholder="Enter project name..." required disabled={loading} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description (optional)</Label>
            <Textarea id="description" value={description} onChange={e => setDescription(e.target.value)} placeholder="Describe your project..." disabled={loading} className="min-h-[80px]" />
          </div>

          <div className="grid grid-cols-2 gap-6">
            

            
          </div>

          <div className="flex gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} className="flex-1" disabled={loading}>
              Cancel
            </Button>
            <Button type="submit" disabled={!name.trim() || loading} className="flex-1">
              {loading ? <>
                  <div className="w-4 h-4 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent" />
                  {project ? 'Updating...' : 'Creating...'}
                </> : <>
                  <Folder className="w-4 h-4 mr-2" />
                  {project ? 'Update Project' : 'Create Project'}
                </>}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>;
};