
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Folder } from 'lucide-react';
import type { Project } from '@/types/database';

interface ProjectSelectorProps {
  projects: Project[];
  selectedProject: string;
  onProjectChange: (projectId: string) => void;
}

export const ProjectSelector = ({ projects, selectedProject, onProjectChange }: ProjectSelectorProps) => {
  return (
    <Select value={selectedProject} onValueChange={onProjectChange}>
      <SelectTrigger className="w-[180px]">
        <div className="flex items-center">
          <Folder className="w-4 h-4 mr-2" />
          <SelectValue />
        </div>
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="all">
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-gray-400 mr-2" />
            All Projects
          </div>
        </SelectItem>
        {projects.map((project) => (
          <SelectItem key={project.id} value={project.id}>
            <div className="flex items-center">
              <div 
                className="w-3 h-3 rounded-full mr-2" 
                style={{ backgroundColor: project.color }}
              />
              {project.name}
            </div>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
};
