import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardTitle } from '@/components/ui/card';
import { ConsistentCardHeader } from '@/components/ui/consistent-card-header';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { ProjectForm } from './ProjectForm';
import { ProjectDetail } from './ProjectDetail';
import { Folder, Edit, Trash2, Target, Pencil } from 'lucide-react';
import type { Project, Task, Note } from '@/types/database';
interface ProjectManagementProps {
  projects: Project[];
  tasks?: Task[];
  notes?: Note[];
  onCreateProject: (projectData: Partial<Project>) => Promise<void>;
  onUpdateProject: (id: string, updates: Partial<Project>) => Promise<void>;
  onDeleteProject: (id: string) => Promise<void>;
  onCreateTask?: (taskData: Partial<Task>) => Promise<void>;
  onUpdateTask?: (id: string, updates: Partial<Task>) => Promise<void>;
  onDeleteTask?: (id: string) => Promise<void>;
  onCreateNote?: (noteData: Partial<Note>) => Promise<void>;
  onUpdateNote?: (id: string, updates: Partial<Note>) => Promise<void>;
  onDeleteNote?: (id: string) => Promise<void>;
}
export const ProjectManagement = ({
  projects,
  tasks = [],
  notes = [],
  onCreateProject,
  onUpdateProject,
  onDeleteProject,
  onCreateTask,
  onUpdateTask,
  onDeleteTask,
  onCreateNote,
  onUpdateNote,
  onDeleteNote
}: ProjectManagementProps) => {
  const [deletingProject, setDeletingProject] = useState<string | null>(null);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [localProjects, setLocalProjects] = useState<Project[]>(projects);

  // Update local state when projects prop changes
  useEffect(() => {
    setLocalProjects(projects);
  }, [projects]);
  const handleUpdateProject = async (id: string, updates: Partial<Project>) => {
    // Optimistically update local state
    setLocalProjects(prev => prev.map(project => project.id === id ? {
      ...project,
      ...updates
    } : project));
    try {
      await onUpdateProject(id, updates);
    } catch (error) {
      // Revert on error
      setLocalProjects(projects);
      throw error;
    }
  };
  const handleDeleteProject = async (projectId: string) => {
    setDeletingProject(projectId);
    try {
      await onDeleteProject(projectId);
    } finally {
      setDeletingProject(null);
    }
  };

  // If a project is selected, show the detail view
  if (selectedProject && onCreateTask && onUpdateTask && onDeleteTask && onCreateNote && onUpdateNote && onDeleteNote) {
    return <ProjectDetail project={selectedProject} tasks={tasks} notes={notes} onUpdateProject={handleUpdateProject} onDeleteProject={onDeleteProject} onCreateTask={onCreateTask} onUpdateTask={onUpdateTask} onDeleteTask={onDeleteTask} onCreateNote={onCreateNote} onUpdateNote={onUpdateNote} onDeleteNote={onDeleteNote} onBack={() => setSelectedProject(null)} />;
  }
  if (localProjects.length === 0) {
    return <Card className="border-0 bg-white/80 backdrop-blur-sm shadow-lg">
        <CardContent className="text-center py-12">
          <div className="mb-6">
            <Folder className="w-16 h-16 mx-auto text-muted-foreground" />
          </div>
          <h3 className="text-xl font-semibold mb-3">No projects yet</h3>
          <p className="text-muted-foreground mb-6">
            Create your first project to organize your tasks and track progress.
          </p>
        </CardContent>
      </Card>;
  }
  return <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {localProjects.map(project => {
      const projectTasks = tasks.filter(task => task.project_id === project.id);
      const projectNotes = notes.filter(note => note.project_id === project.id);
      const completedTasks = projectTasks.filter(task => task.status === 'completed').length;
      return <Card key={project.id} className="hover:shadow-md transition-shadow h-52 flex flex-col justify-between">
            <div>
              <ConsistentCardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{
                  backgroundColor: project.color
                }} />
                    <CardTitle className="text-base">{project.name}</CardTitle>
                  </div>
                  
                </div>
              </ConsistentCardHeader>
              
              <CardContent className="pt-0 px-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                  <Target className="w-4 h-4" />
                  <span>{Math.round(project.completion_percentage)}% complete</span>
                </div>

                {/* Project Stats */}
                <div className="grid grid-cols-2 gap-2 mb-2 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    
                    <span>{projectTasks.length}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span>Notes:</span>
                    <span>{projectNotes.length}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span>Completed:</span>
                    <span>{completedTasks}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span>Time:</span>
                    <span>{Math.round((project.actual_duration || 0) / 60)}h</span>
                  </div>
                </div>
              </CardContent>
            </div>
            
            <CardContent className="px-4 pb-2">
              <div className="flex gap-2">
                {/* Edit Detail Button - only show if handlers are available */}
                {onCreateTask && onUpdateTask && onDeleteTask && onCreateNote && onUpdateNote && onDeleteNote && <Button size="sm" variant="outline" onClick={() => setSelectedProject(project)} className="flex-1">
                    <Pencil className="w-4 h-4 mr-2" />
                    Edit
                  </Button>}
                
                
                
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete Project</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete "{project.name}"? This will also remove all tasks associated with this project. This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={() => handleDeleteProject(project.id)} className="bg-red-600 hover:bg-red-700" disabled={deletingProject === project.id}>
                        {deletingProject === project.id ? 'Deleting...' : 'Delete'}
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </CardContent>
          </Card>;
    })}
    </div>;
};