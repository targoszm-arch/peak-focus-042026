import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TaskForm } from '@/components/tasks/TaskForm';
import { TaskList } from '@/components/tasks/TaskList';
import { NoteForm } from '@/components/notes/NoteForm';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { ProjectForm } from './ProjectForm';
import { Plus, Edit, Trash2, CheckCircle, Clock, FileText, Target } from 'lucide-react';
import { format } from 'date-fns';
import type { Project, Task, Note } from '@/types/database';

interface ProjectDetailProps {
  project: Project;
  tasks: Task[];
  notes: Note[];
  onUpdateProject: (id: string, updates: Partial<Project>) => Promise<void>;
  onDeleteProject: (id: string) => Promise<void>;
  onCreateTask: (taskData: Partial<Task>) => Promise<void>;
  onUpdateTask: (id: string, updates: Partial<Task>) => Promise<void>;
  onDeleteTask: (id: string) => Promise<void>;
  onCreateNote: (noteData: Partial<Note>) => Promise<void>;
  onUpdateNote: (id: string, updates: Partial<Note>) => Promise<void>;
  onDeleteNote: (id: string) => Promise<void>;
  onBack: () => void;
}

export const ProjectDetail = ({
  project,
  tasks,
  notes,
  onUpdateProject,
  onDeleteProject,
  onCreateTask,
  onUpdateTask,
  onDeleteTask,
  onCreateNote,
  onUpdateNote,
  onDeleteNote,
  onBack
}: ProjectDetailProps) => {
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [deletingProject, setDeletingProject] = useState(false);
  const [deletingTaskId, setDeletingTaskId] = useState<string | null>(null);

  const projectTasks = tasks.filter(task => task.project_id === project.id);
  const projectNotes = notes.filter(note => note.project_id === project.id);
  const completedTasks = projectTasks.filter(task => task.status === 'completed').length;
  const totalTasks = projectTasks.length;
  const completionPercentage = totalTasks > 0 ? Math.round(completedTasks / totalTasks * 100) : 0;

  const handleDeleteProject = async () => {
    setDeletingProject(true);
    try {
      await onDeleteProject(project.id);
      onBack();
    } finally {
      setDeletingProject(false);
    }
  };

  const handleCreateTask = async (taskData: Partial<Task>) => {
    await onCreateTask({
      ...taskData,
      project_id: project.id
    });
    setShowTaskForm(false);
  };

  const handleUpdateTask = async (taskId: string, taskData: Partial<Task>) => {
    await onUpdateTask(taskId, taskData);
  };

  const handleDeleteTask = async (taskId: string) => {
    setDeletingTaskId(taskId);
    try {
      await onDeleteTask(taskId);
    } finally {
      setDeletingTaskId(null);
    }
  };

  const handleCreateNote = async (noteData: Partial<Note>) => {
    await onCreateNote({
      ...noteData,
      project_id: project.id
    });
  };

  return (
    <div className="space-y-6">
      {/* Project Header */}
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-4">
          <Button variant="ghost" onClick={onBack} className="mt-1">
            ← Back
          </Button>
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-4 h-4 rounded-full" style={{
              backgroundColor: project.color
            }} />
              <h1 className="text-2xl font-bold">{project.name}</h1>
              <Badge variant="secondary">{project.mountain_theme}</Badge>
            </div>
            {project.description && <p className="text-muted-foreground">{project.description}</p>}
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <ProjectForm project={project} onSubmit={updates => onUpdateProject(project.id, updates)} trigger={<Button size="sm" variant="outline">
                <Edit className="w-4 h-4 mr-2" />
                Edit
              </Button>} />
          
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700">
                <Trash2 className="w-4 h-4 mr-2" />
                Delete
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete Project</AlertDialogTitle>
                <AlertDialogDescription>
                  Are you sure you want to delete "{project.name}"? This will also remove all tasks and notes associated with this project. This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDeleteProject} className="bg-red-600 hover:bg-red-700" disabled={deletingProject}>
                  {deletingProject ? 'Deleting...' : 'Delete'}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      {/* Project Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Target className="w-4 h-4" />
              Progress
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completionPercentage}%</div>
            <p className="text-xs text-muted-foreground">
              {completedTasks} of {totalTasks} tasks
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <CheckCircle className="w-4 h-4" />
              Tasks
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalTasks}</div>
            <p className="text-xs text-muted-foreground">
              {completedTasks} completed
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <FileText className="w-4 h-4" />
              Notes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{projectNotes.length}</div>
            <p className="text-xs text-muted-foreground">
              Total notes
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Duration
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Math.round((project.actual_duration || 0) / 60)}h
            </div>
            <p className="text-xs text-muted-foreground">
              Time spent
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Project Content */}
      <Tabs defaultValue="tasks" className="w-full">
        <TabsList>
          <TabsTrigger value="tasks">Tasks ({totalTasks})</TabsTrigger>
          <TabsTrigger value="notes">Notes ({projectNotes.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="tasks" className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Project Tasks</h3>
            <TaskForm 
              projects={[]} 
              onSubmit={handleCreateTask} 
              onCancel={() => setShowTaskForm(false)} 
              trigger={
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Task
                </Button>
              }
            />
          </div>
          
          {projectTasks.length === 0 ? (
            <Card>
              <CardContent className="text-center py-12">
                <Target className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No tasks yet</h3>
                <p className="text-muted-foreground mb-4">
                  Create your first task for this project to get started.
                </p>
              </CardContent>
            </Card>
          ) : (
            <TaskList
              tasks={projectTasks}
              projects={[project]}
              onUpdateTask={handleUpdateTask}
              onDeleteTask={handleDeleteTask}
              showMountain={false}
            />
          )}
        </TabsContent>

        <TabsContent value="notes" className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Project Notes</h3>
            <NoteForm projects={[]} onSubmit={handleCreateNote} trigger={<Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Note
                </Button>} />
          </div>
          
          {projectNotes.length === 0 ? <Card>
              <CardContent className="text-center py-12">
                <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No notes yet</h3>
                <p className="text-muted-foreground">
                  Create your first note for this project to capture ideas and progress.
                </p>
              </CardContent>
            </Card> : <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {projectNotes.map(note => <Card key={note.id} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base line-clamp-1">{note.title}</CardTitle>
                    <CardDescription className="text-xs">
                      {format(new Date(note.updated_at), 'MMM dd, yyyy')}
                    </CardDescription>
                  </CardHeader>
                  {note.content && <CardContent className="pt-0">
                      <p className="text-sm text-muted-foreground line-clamp-3">
                        {note.content}
                      </p>
                    </CardContent>}
                </Card>)}
            </div>}
        </TabsContent>
      </Tabs>
    </div>
  );
};
