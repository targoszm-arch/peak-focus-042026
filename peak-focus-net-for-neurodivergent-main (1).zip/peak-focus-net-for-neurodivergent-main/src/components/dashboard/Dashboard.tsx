import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TaskForm } from '@/components/tasks/TaskForm';
import { ProjectForm } from '@/components/projects/ProjectForm';
import { NoteForm } from '@/components/notes/NoteForm';
import { TaskList } from '@/components/tasks/TaskList';
import { ProjectManagement } from '@/components/projects/ProjectManagement';
import { NotesList } from '@/components/notes/NotesList';
import { MountainVisualization } from '@/components/mountain/MountainVisualization';
import { ProgressTaskList } from '@/components/progress/ProgressTaskList';
import { useTasks } from '@/hooks/useTasks';
import { useNotes } from '@/hooks/useNotes';
import { useAuth } from '@/hooks/useAuth';
import { Mountain, CheckSquare, FolderOpen, FileText, TrendingUp, Plus, LogOut } from 'lucide-react';
import { UserProfile } from '@/components/profile/UserProfile';
import { useProfile } from '@/hooks/useProfile';
export function Dashboard() {
  const {
    user,
    signOut
  } = useAuth();
  const {
    tasks,
    projects,
    dailyProgress,
    loading: tasksLoading,
    operationLoading,
    saveTask,
    updateTask,
    deleteTask,
    saveProject,
    updateProject,
    deleteProject
  } = useTasks();
  const {
    notes,
    loading: notesLoading,
    saveNote,
    updateNote,
    deleteNote
  } = useNotes();
  const { profile } = useProfile();
  const [activeTab, setActiveTab] = useState('overview');
  if (!user || tasksLoading || notesLoading) {
    return <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Mountain className="w-16 h-16 mx-auto mb-4 text-muted-foreground animate-pulse" />
          <p className="text-muted-foreground text-lg">Loading your productivity mountain...</p>
        </div>
      </div>;
  }
  console.log('[DASHBOARD] Rendering with dailyProgress:', dailyProgress);
  const completionPercentage = dailyProgress?.mountain_reduction_percentage || 0;
  const tasksCompleted = dailyProgress?.total_tasks_completed || 0;
  const totalTasks = dailyProgress?.total_tasks_planned || 0;
  return <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <Mountain className="w-8 h-8 text-indigo-600" />
              <h1 className="text-2xl font-bold text-gray-800">Peak Focus</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">
                Welcome {profile?.first_name ? `${profile.first_name}!` : user.email?.split('@')[0]}
              </span>
              <UserProfile />
              <Button variant="ghost" size="sm" onClick={signOut} className="text-gray-600 p-2">
                <LogOut className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-4 lg:w-[500px] bg-white/50 backdrop-blur-sm">
            <TabsTrigger value="overview" className="data-[state=active]:bg-white">
              <TrendingUp className="w-4 h-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="tasks" className="data-[state=active]:bg-white">
              <CheckSquare className="w-4 h-4 mr-2" />
              Tasks
            </TabsTrigger>
            <TabsTrigger value="projects" className="data-[state=active]:bg-white">
              <FolderOpen className="w-4 h-4 mr-2" />
              Projects
            </TabsTrigger>
            <TabsTrigger value="notes" className="data-[state=active]:bg-white">
              <FileText className="w-4 h-4 mr-2" />
              Notes
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="mt-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Mountain Visualization */}
              <div className="lg:col-span-2">
                <Card className="border-0 bg-white/80 backdrop-blur-sm shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Mountain className="w-5 h-5" />
                      Daily Focus
                    </CardTitle>
                    <CardDescription>
                      {(() => {
                        const hour = new Date().getHours();
                        const greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';
                        
                        return profile?.first_name 
                          ? `${greeting}! Complete tasks to reveal the beautiful sky behind your mountain, ${profile.first_name}!`
                          : `${greeting}! Complete tasks to reveal the beautiful sky behind your mountain`;
                      })()}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <MountainVisualization completionPercentage={completionPercentage} theme="alpine" />
                  </CardContent>
                </Card>
              </div>

              {/* Today's Tasks */}
              <div>
                <Card className="border-0 bg-white/80 backdrop-blur-sm shadow-lg">
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span className="flex items-center gap-2">
                        <CheckSquare className="w-5 h-5" />
                        Today's Tasks
                      </span>
                      <TaskForm projects={projects} onSubmit={saveTask} onCancel={() => {}} trigger={<Button size="sm" variant="outline">
                            <Plus className="w-4 h-4" />
                          </Button>} />
                    </CardTitle>
                    <CardDescription>
                      {tasksCompleted} of {totalTasks} completed
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <TaskList 
                      tasks={tasks.filter(task => {
                        const today = new Date().toISOString().split('T')[0];
                        // Include tasks with due date today
                        if (task.due_date === today) return true;
                        // Include tasks created today that don't have a due date
                        if (!task.due_date && task.created_at && task.created_at.startsWith(today)) return true;
                        // Include active tasks without due dates (for ongoing work)
                        if (!task.due_date && (task.status === 'todo' || task.status === 'in_progress')) return true;
                        return false;
                      })} 
                      projects={projects} 
                      onUpdateTask={updateTask} 
                      onDeleteTask={deleteTask} 
                      dailyProgress={dailyProgress} 
                    />
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Tasks Tab */}
          <TabsContent value="tasks" className="mt-8">
            <Card className="border-0 bg-white/80 backdrop-blur-sm shadow-lg">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <CheckSquare className="w-5 h-5" />
                      Tasks
                    </CardTitle>
                    <CardDescription>
                      {profile?.first_name 
                        ? `Manage your tasks and track progress, ${profile.first_name}`
                        : 'Manage your tasks and track progress'
                      }
                    </CardDescription>
                  </div>
                  <TaskForm projects={projects} onSubmit={saveTask} onCancel={() => {}} trigger={<Button className="bg-indigo-600 hover:bg-indigo-700">
                        <Plus className="w-4 h-4 mr-2" />
                        Add Task
                      </Button>} />
                </div>
              </CardHeader>
              <CardContent>
                <TaskList tasks={tasks} projects={projects} onUpdateTask={updateTask} onDeleteTask={deleteTask} dailyProgress={dailyProgress} />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Projects Tab */}
          <TabsContent value="projects" className="mt-8">
            <Card className="border-0 bg-white/80 backdrop-blur-sm shadow-lg">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="flex items-center gap-2 pb-px">
                      <FolderOpen className="w-5 h-5" />
                      Projects
                    </CardTitle>
                    <CardDescription>
                      {profile?.first_name 
                        ? `Organize your work into projects, ${profile.first_name}`
                        : 'Organize your work into projects'
                      }
                    </CardDescription>
                  </div>
                  <ProjectForm onSubmit={saveProject} trigger={<Button className="bg-indigo-600 hover:bg-indigo-700">
                        <Plus className="w-4 h-4 mr-2" />
                        Add Project
                      </Button>} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="mb-6">
                  <MountainVisualization completionPercentage={completionPercentage} theme="alpine" />
                </div>
                <ProjectManagement projects={projects} tasks={tasks} notes={notes} onCreateProject={saveProject} onUpdateProject={updateProject} onDeleteProject={deleteProject} onCreateTask={saveTask} onUpdateTask={updateTask} onDeleteTask={deleteTask} onCreateNote={saveNote} onUpdateNote={updateNote} onDeleteNote={deleteNote} />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notes Tab */}
          <TabsContent value="notes" className="mt-8">
            <Card className="border-0 bg-white/80 backdrop-blur-sm shadow-lg">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="w-5 h-5" />
                      Notes
                    </CardTitle>
                    <CardDescription>
                      {profile?.first_name 
                        ? `Capture your thoughts and ideas, ${profile.first_name}`
                        : 'Capture your thoughts and ideas'
                      }
                    </CardDescription>
                  </div>
                  <NoteForm projects={projects} onSubmit={saveNote} trigger={<Button className="bg-indigo-600 hover:bg-indigo-700">
                        <Plus className="w-4 h-4 mr-2" />
                        Add Note
                      </Button>} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="mb-6">
                  <MountainVisualization completionPercentage={completionPercentage} theme="alpine" />
                </div>
                <NotesList notes={notes} projects={projects} onUpdateNote={updateNote} onDeleteNote={deleteNote} />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>;
}