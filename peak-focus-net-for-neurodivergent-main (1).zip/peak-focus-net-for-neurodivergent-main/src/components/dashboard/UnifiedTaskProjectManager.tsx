
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { CalendarIcon, Clock, Folder, CheckSquare, Edit, Trash2, Play, Timer, Target, Minus, Plus } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { PomodoroTaskTimer } from '@/components/pomodoro/PomodoroTaskTimer';
import { TaskForm } from '@/components/tasks/TaskForm';
import { usePomodoroSessions } from '@/hooks/usePomodoroSessions';
import { RelatedItemsList } from '@/components/relationships/RelatedItemsList';
import { LinkItemsDialog } from '@/components/relationships/LinkItemsDialog';
import type { Task, Project, Priority, MountainTheme } from '@/types/database';

interface UnifiedTaskProjectManagerProps {
  tasks: Task[];
  projects: Project[];
  onCreateTask: (taskData: Partial<Task>) => Promise<void>;
  onUpdateTask: (id: string, updates: Partial<Task>) => Promise<void>;
  onDeleteTask: (id: string) => Promise<void>;
  onCreateProject: (projectData: Partial<Project>) => Promise<void>;
  onUpdateProject: (id: string, updates: Partial<Project>) => Promise<void>;
  onDeleteProject: (id: string) => Promise<void>;
  operationLoading: boolean;
}

type CreateMode = 'project';

const mountainThemes: { value: MountainTheme; label: string; color: string }[] = [
  { value: 'alpine', label: 'Alpine', color: '#3b82f6' },
  { value: 'desert', label: 'Desert', color: '#f59e0b' },
  { value: 'volcanic', label: 'Volcanic', color: '#ef4444' },
  { value: 'coastal', label: 'Coastal', color: '#06b6d4' },
  { value: 'forest', label: 'Forest', color: '#22c55e' }
];

export const UnifiedTaskProjectManager = ({
  tasks,
  projects,
  onCreateTask,
  onUpdateTask,
  onDeleteTask,
  onCreateProject,
  onUpdateProject,
  onDeleteProject,
  operationLoading
}: UnifiedTaskProjectManagerProps) => {
  const [createMode, setCreateMode] = useState<CreateMode | null>(null);
  const [showCreateTaskForm, setShowCreateTaskForm] = useState(false);
  const [selectedTimerTask, setSelectedTimerTask] = useState<Task | null>(null);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [deletingTaskId, setDeletingTaskId] = useState<string | null>(null);
  const { toast } = useToast();
  const { createPomodoroSession } = usePomodoroSessions();

  const [projectName, setProjectName] = useState('');
  const [projectDescription, setProjectDescription] = useState('');
  const [projectColor, setProjectColor] = useState('#3b82f6');
  const [projectTheme, setProjectTheme] = useState<MountainTheme>('alpine');

  const resetProjectForm = () => {
    setProjectName('');
    setProjectDescription('');
    setProjectColor('#3b82f6');
    setProjectTheme('alpine');
  };

  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!projectName.trim()) {
      toast({
        title: "Project name required",
        description: "Please enter a project name",
        variant: "destructive",
      });
      return;
    }

    try {
      await onCreateProject({
        name: projectName.trim(),
        description: projectDescription.trim() || undefined,
        color: projectColor,
        mountain_theme: projectTheme,
        icon: 'folder',
        estimated_duration: 0,
        actual_duration: 0,
        completion_percentage: 0,
      });

      resetProjectForm();
      setCreateMode(null);
      toast({
        title: "Project created",
        description: "Your project has been created successfully.",
      });
    } catch (error) {
      console.error('Create project error:', error);
    }
  };

  const handlePomodoroSessionComplete = async (taskId: string, duration: number) => {
    try {
      await createPomodoroSession(taskId, duration);
      window.location.reload();
    } catch (error) {
      console.error('Failed to complete Pomodoro session:', error);
    }
  };

  const handleTaskUpdate = async (taskData: Partial<Task>) => {
    if (editingTask) {
      await onUpdateTask(editingTask.id, taskData);
      setEditingTask(null);
      toast({
        title: "Task updated",
        description: "Your task has been updated successfully.",
      });
    }
  };

  const handleTaskCreate = async (taskData: Partial<Task>) => {
    await onCreateTask(taskData);
    setShowCreateTaskForm(false);
    toast({
      title: "Task created",
      description: "Your task has been created successfully.",
    });
  };

  const handleDeleteTask = async (taskId: string) => {
    setDeletingTaskId(taskId);
    try {
      await onDeleteTask(taskId);
      toast({
        title: "Task deleted",
        description: "The task has been removed.",
      });
    } catch (error) {
      console.error('Delete task error:', error);
    } finally {
      setDeletingTaskId(null);
    }
  };

  const handleSessionsChange = async (taskId: string, change: number) => {
    const task = tasks.find(t => t.id === taskId);
    if (task) {
      const newSessions = Math.max(1, Math.min(10, task.pomodoro_sessions_planned + change));
      await onUpdateTask(taskId, { pomodoro_sessions_planned: newSessions });
    }
  };

  const priorityColors = {
    low: 'bg-green-100 text-green-800',
    medium: 'bg-yellow-100 text-yellow-800',
    high: 'bg-orange-100 text-orange-800',
    urgent: 'bg-red-100 text-red-800'
  };

  const tasksByProject = tasks.reduce((acc, task) => {
    const projectId = task.project_id || 'no-project';
    if (!acc[projectId]) {
      acc[projectId] = [];
    }
    acc[projectId].push(task);
    return acc;
  }, {} as Record<string, Task[]>);

  return (
    <TooltipProvider>
      <div className="space-y-6 p-4">
        {!createMode && (
          <div className="flex flex-col sm:flex-row gap-2">
            <Button 
              onClick={() => setShowCreateTaskForm(true)}
              className="flex-1"
            >
              <CheckSquare className="w-4 h-4 mr-2" />
              Add Task
            </Button>
            <Button 
              onClick={() => setCreateMode('project')}
              variant="outline"
              className="flex-1"
            >
              <Folder className="w-4 h-4 mr-2" />
              Add Project
            </Button>
          </div>
        )}

        {createMode === 'project' && (
          <Card className="border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Folder className="w-5 h-5" />
                Create New Project
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreateProject} className="space-y-4">
                <div>
                  <Label htmlFor="project-name">Project Name</Label>
                  <Input
                    id="project-name"
                    value={projectName}
                    onChange={(e) => setProjectName(e.target.value)}
                    placeholder="Enter project name..."
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="project-description">Description</Label>
                  <Textarea
                    id="project-description"
                    value={projectDescription}
                    onChange={(e) => setProjectDescription(e.target.value)}
                    placeholder="Describe your project..."
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Theme</Label>
                    <div className="grid grid-cols-1 gap-2">
                      {mountainThemes.map((mt) => (
                        <button
                          key={mt.value}
                          type="button"
                          onClick={() => {
                            setProjectTheme(mt.value);
                            setProjectColor(mt.color);
                          }}
                          className={`flex items-center gap-2 p-2 rounded border text-left transition-colors ${
                            projectTheme === mt.value ? 'border-primary bg-primary/10' : 'border-border hover:bg-muted'
                          }`}
                        >
                          <div 
                            className="w-4 h-4 rounded-full" 
                            style={{ backgroundColor: mt.color }}
                          />
                          <span className="text-sm">{mt.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="project-color">Custom Color</Label>
                    <Input
                      id="project-color"
                      type="color"
                      value={projectColor}
                      onChange={(e) => setProjectColor(e.target.value)}
                      className="h-12"
                    />
                  </div>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => {
                      setCreateMode(null);
                      resetProjectForm();
                    }}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={!projectName.trim() || operationLoading}
                    className="flex-1"
                  >
                    {operationLoading ? 'Creating...' : 'Create Project'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        <div className="space-y-4">
          {projects.map((project) => (
            <Card key={project.id} className="border-l-4" style={{ borderLeftColor: project.color }}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: project.color }}
                    />
                    <CardTitle className="text-lg">{project.name}</CardTitle>
                    <Badge variant="secondary" className="text-xs">
                      {project.mountain_theme}
                    </Badge>
                  </div>
                </div>
                {project.description && (
                  <p className="text-sm text-muted-foreground">{project.description}</p>
                )}
              </CardHeader>
              <CardContent>
                {tasksByProject[project.id] && tasksByProject[project.id].length > 0 ? (
                  <div className="space-y-2">
                    {tasksByProject[project.id].map((task) => (
                      <div key={task.id} className="flex items-start gap-3 p-3 bg-muted/50 rounded border">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium truncate">{task.title}</span>
                            <Badge className={priorityColors[task.priority]}>{task.priority}</Badge>
                          </div>
                          {task.description && (
                            <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{task.description}</p>
                          )}
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              <span>{task.estimated_duration}min</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Timer className="w-3 h-3" />
                              <span>{task.pomodoro_sessions_completed}/{task.pomodoro_sessions_planned}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button 
                                size="icon" 
                                variant="outline"
                                onClick={() => setSelectedTimerTask(task)}
                                disabled={task.status === 'completed'}
                                className="h-8 w-8"
                              >
                                <Play className="w-3 h-3" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Start Focus Session</TooltipContent>
                          </Tooltip>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button 
                                size="icon" 
                                variant="ghost"
                                onClick={() => setEditingTask(task)}
                                className="h-8 w-8"
                              >
                                <Edit className="w-3 h-3" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>Edit Task</TooltipContent>
                          </Tooltip>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button 
                                    size="icon" 
                                    variant="ghost" 
                                    className="h-8 w-8 text-red-600 hover:text-red-700"
                                    disabled={deletingTaskId === task.id}
                                  >
                                    <Trash2 className="w-3 h-3" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Delete Task</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Are you sure you want to delete "{task.title}"? This action cannot be undone.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => handleDeleteTask(task.id)}
                                      className="bg-red-600 hover:bg-red-700"
                                    >
                                      Delete
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </TooltipTrigger>
                            <TooltipContent>Delete Task</TooltipContent>
                          </Tooltip>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground italic">No tasks in this project</p>
                )}
                
                {/* Related items for project */}
                <div className="mt-4 pt-4 border-t">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-sm font-medium">Related Items</h4>
                    <LinkItemsDialog 
                      sourceType="project" 
                      sourceId={project.id}
                      onLinked={() => {}} // Projects don't need refresh since we're in read-only view
                    />
                  </div>
                  <RelatedItemsList 
                    entityType="project" 
                    entityId={project.id}
                  />
                </div>
              </CardContent>
            </Card>
          ))}

          {tasksByProject['no-project'] && tasksByProject['no-project'].length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <CheckSquare className="w-5 h-5" />
                  Tasks (No Project)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {tasksByProject['no-project'].map((task) => (
                    <div key={task.id} className="flex items-start gap-3 p-3 bg-muted/50 rounded border">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium truncate">{task.title}</span>
                          <Badge className={priorityColors[task.priority]}>{task.priority}</Badge>
                        </div>
                        {task.description && (
                          <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{task.description}</p>
                        )}
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>{task.estimated_duration}min</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Timer className="w-3 h-3" />
                            <span>{task.pomodoro_sessions_completed}/{task.pomodoro_sessions_planned}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button 
                              size="icon" 
                              variant="outline"
                              onClick={() => setSelectedTimerTask(task)}
                              disabled={task.status === 'completed'}
                              className="h-8 w-8"
                            >
                              <Play className="w-3 h-3" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Start Focus Session</TooltipContent>
                        </Tooltip>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button 
                              size="icon" 
                              variant="ghost"
                              onClick={() => setEditingTask(task)}
                              className="h-8 w-8"
                            >
                              <Edit className="w-3 h-3" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Edit Task</TooltipContent>
                        </Tooltip>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button 
                                  size="icon" 
                                  variant="ghost" 
                                  className="h-8 w-8 text-red-600 hover:text-red-700"
                                  disabled={deletingTaskId === task.id}
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Delete Task</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Are you sure you want to delete "{task.title}"? This action cannot be undone.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => handleDeleteTask(task.id)}
                                    className="bg-red-600 hover:bg-red-700"
                                  >
                                    Delete
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </TooltipTrigger>
                          <TooltipContent>Delete Task</TooltipContent>
                        </Tooltip>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {tasks.length === 0 && projects.length === 0 && (
            <Card className="text-center py-12">
              <CardContent>
                <div className="mb-4">
                  <Target className="w-16 h-16 mx-auto text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Get started</h3>
                <p className="text-muted-foreground mb-4">
                  Create your first project or task to begin organizing your work.
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        {selectedTimerTask && (
          <PomodoroTaskTimer
            task={selectedTimerTask}
            open={!!selectedTimerTask}
            onClose={() => setSelectedTimerTask(null)}
            onSessionComplete={handlePomodoroSessionComplete}
          />
        )}

        {editingTask && (
          <TaskForm
            task={editingTask}
            projects={projects}
            onSubmit={handleTaskUpdate}
            onCancel={() => setEditingTask(null)}
            isOpen={!!editingTask}
            onClose={() => setEditingTask(null)}
          />
        )}

        {showCreateTaskForm && (
          <TaskForm
            projects={projects}
            onSubmit={handleTaskCreate}
            onCancel={() => setShowCreateTaskForm(false)}
            isOpen={showCreateTaskForm}
            onClose={() => setShowCreateTaskForm(false)}
          />
        )}
      </div>
    </TooltipProvider>
  );
};
