
import React, { useState, useEffect, useRef, useCallback, useMemo, startTransition } from 'react';
import { Play, Pause, RotateCcw, SkipForward, Settings, Coffee, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Slider } from '@/components/ui/slider';
import { toast } from '@/hooks/use-toast';
import TaskEditor from './TaskEditor';
import TaskHistory from './TaskHistory';
import { useTaskManager } from '@/hooks/useTaskManager';

interface TimerSettings {
  workMinutes: number;
  breakMinutes: number;
  longBreakMinutes: number;
  sessionsUntilLongBreak: number;
}

const PomodoroTimer = () => {
  const [settings, setSettings] = useState<TimerSettings>({
    workMinutes: 25,
    breakMinutes: 5,
    longBreakMinutes: 15,
    sessionsUntilLongBreak: 4,
  });

  // Single source of truth for timer state
  const [totalSeconds, setTotalSeconds] = useState(settings.workMinutes * 60);
  const [isActive, setIsActive] = useState(false);
  const [isWork, setIsWork] = useState(true);
  const [completedSessions, setCompletedSessions] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const bellAudioRef = useRef<HTMLAudioElement | null>(null);
  const chimeAudioRef = useRef<HTMLAudioElement | null>(null);
  const lastNotificationRef = useRef<number>(0);

  const taskManager = useTaskManager('Focus Session');

  // Work duration options in minutes
  const workDurationOptions = [15, 25, 45, 90];

  // Memoize calculated values
  const { minutes, seconds, progress, currentSessionDuration } = useMemo(() => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    const sessionDuration = isWork 
      ? settings.workMinutes * 60 
      : (completedSessions % settings.sessionsUntilLongBreak === settings.sessionsUntilLongBreak - 1 
         ? settings.longBreakMinutes * 60 
         : settings.breakMinutes * 60);
    const prog = ((sessionDuration - totalSeconds) / sessionDuration) * 100;
    
    return {
      minutes: mins,
      seconds: secs,
      progress: Math.max(0, Math.min(100, prog)),
      currentSessionDuration: sessionDuration
    };
  }, [totalSeconds, isWork, settings, completedSessions]);

  // Initialize audio files once
  useEffect(() => {
    // Bell sound for focus session completion - deeper, more resonant bell
    bellAudioRef.current = new Audio();
    bellAudioRef.current.src = "data:audio/wav;base64,UklGRjIEAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQ4EAACBHYSC7YFnhUiJooVmhXWGJoh1hDKDLIJHhFqFVIM6hGaF8IFRgwWDGYU/hDmDNINGhReEcoRbhLCDsIJPhAaEgYPogzeE84P7gZeEkITjgv2CvoPRhOODnINNhPaD/ILGhMqEtIN4hEiFqoT0gomDgYOpg6yD0YMwhOeCfYPbgz2DuYPFhKKDb4PXhNeEcoRBhPiDP4SPg7aDy4R5g4WD0IOQhD6Ds4PWg8ODk4P8g2mDrIMrg4CDpIOJhLqD5IL+gnKC8IHQgZqBx4GegXKBsoFGgbWBl4EJgq+B14F1gU+By4Fqgf6Bt4HDgTyC/YENgryB2oFtgYKBtoGEgXWBcIGYgVSBj4G1gQuBvoGGgbeB44GkgaOBDYL8gQKCIYI7gsiBpoGXgciBVYGXgVSBhYGdgYaBkoH2gR+C14FLgdeBWYGrgeWBmIGDgYqBU4FfgX2B54G8gSeCM4LZgaGBqIGKgX6BfYG7gUaBm4FqgQ+BpIG7gWOBvIFhgYmBbYHdgSSCyoH4gfGBDYKzgZaBjIF6gaqBSYGGgXWBPoGHgZiBHoGggZOBUYGzgUqBp4FAgY2BlIFigVOBf4EngYyBwYFXgWqBT4FXgbuBNIGIgc+B+YCkgSKBhYEKgb+BWoF+gTaBqoFpgY+BKYF6gR+BjYG6gQ==";
    
    // Chime sound for break completion - softer, lighter chimes
    chimeAudioRef.current = new Audio();
    chimeAudioRef.current.src = "data:audio/wav;base64,UklGRjoDAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YRYDAACBhYqFbFtfdJmwrJBgNjRfodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvv55xOEA1QqOLwtmMcBjmQ1/HNeSsFJXfG8N2QQQoUXrHp66hVFApGn+DwxWEcBjyW3vPTgjMGKHzL8t6PQAkUXbPp66hWFApHoODwxGIbBjuV3vHTgz4HKIDE9OGMPggTX7rs56tXFAtGoN/zuWMcBDuT2fHOeywFJHfH8N2QQAkTXrPq7ahVFAlGoN/vxGUcBzuV3vHTgz4HKIDE9N2QPwoSX7js56tYFAtGoN/zuGEbBjyU2/DOeiwEJHrJ8t6PQAkTX7Hq7KhVFAlGoN/vxGUcBzuV3vHTgz4HKIDE9N2QQAoSX7js56xXFAtGoN/zuGEbBjyU2/HOeSwEJXnI8t6PQQoSX7Dq7KhVFAlGoN/vxGUcBzuW3/PTgjMGKXvM9N+OPgkUXLHp66pWEwlInuLwxGEbBTyV4PHOeiwEJnvG8d+PQQkSXrHq66pWEwlInuHwxGEbBT2V3/PWgjMFKnvL9N+OPggUXbLo7KpXEwlInuDwxWIbBjyV3/PTgjMGKnvL9N+OPggUXbLo7KpXEwlJnuDwxWIbBjyV3/PTgzIFKnvL9N+OPggUXbLo7KlWFAlInuDwxGIbBjyV3/PWgjMGKnzN9N+OPggTXbLo7KpXEwlInuDvxWEbBjyW3/PWgjMGKnzN9N+OPggTXbLo7KlXEwlInuDvxWEbBjyW3/PWgjMGKnzN9N+OPggTXbLo7KlXEwlInuDvxmEbBjyW3/PWgjMGKnzN9N+OPggTXbLo7KlXEwlJnuDvxmEbBjyW3/PWgjMGKnzN9N+OPggTXbLo7KlXEwlJnuDvxmEbBjyW3/PWgjMGKnzN9N+OPggTXbLo7KlXEwlJnuDvxmEbBjyW4PHWgjMGKnzM9N+OPggTXbLo7KlXEwlJnuDvxmEbBjyW4PHWgjMGKnzM9N+OPggTXbLo7KlXEwlJnuDvxmEbBjyW4PHWgjMGKnzM9N+OPggTXbLo7KlXEwlJnuDvxmEbBjyW4PHWgjMGKnzM9N+OPggT";
    
    return () => {
      if (bellAudioRef.current) {
        bellAudioRef.current.remove();
      }
      if (chimeAudioRef.current) {
        chimeAudioRef.current.remove();
      }
    };
  }, []);

  // Optimized timer completion handler with useCallback
  const handleTimerComplete = useCallback(() => {
    const now = Date.now();
    
    // Debounce notifications to prevent spam
    if (now - lastNotificationRef.current < 1000) {
      return;
    }
    lastNotificationRef.current = now;

    // Play audio
    if (isWork) {
      bellAudioRef.current?.play().catch(console.error);
    } else {
      chimeAudioRef.current?.play().catch(console.error);
    }

    // Batch state updates using startTransition
    startTransition(() => {
      setIsActive(false);
      
      if (isWork) {
        setCompletedSessions(prev => prev + 1);
        const nextCompletedSessions = completedSessions + 1;
        const isLongBreak = nextCompletedSessions % settings.sessionsUntilLongBreak === 0;
        const breakMinutes = isLongBreak ? settings.longBreakMinutes : settings.breakMinutes;
        
        setTotalSeconds(breakMinutes * 60);
        setIsWork(false);
        
        toast({
          title: `"${taskManager.currentTask}" completed!`,
          description: `Time for a ${isLongBreak ? 'long' : 'short'} break (${breakMinutes} minutes)`,
        });
      } else {
        setTotalSeconds(settings.workMinutes * 60);
        setIsWork(true);
        
        toast({
          title: "Break time over!",
          description: `Ready for another work session (${settings.workMinutes} minutes)`,
        });
      }
    });
  }, [isWork, completedSessions, settings, taskManager.currentTask]);

  // Optimized timer effect - only recreate when isActive changes
  useEffect(() => {
    if (isActive) {
      intervalRef.current = setInterval(() => {
        setTotalSeconds(prevSeconds => {
          if (prevSeconds <= 1) {
            // Timer complete - will be handled in next render
            return 0;
          }
          return prevSeconds - 1;
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [isActive]);

  // Handle timer completion when totalSeconds reaches 0
  useEffect(() => {
    if (isActive && totalSeconds === 0) {
      handleTimerComplete();
    }
  }, [isActive, totalSeconds, handleTimerComplete]);

  const toggleTimer = useCallback(() => {
    setIsActive(prev => !prev);
  }, []);

  const resetTimer = useCallback(() => {
    setIsActive(false);
    const sessionDuration = isWork ? settings.workMinutes : settings.breakMinutes;
    setTotalSeconds(sessionDuration * 60);
  }, [isWork, settings.workMinutes, settings.breakMinutes]);

  const skipSession = useCallback(() => {
    setIsActive(false);
    handleTimerComplete();
  }, [handleTimerComplete]);

  const handleWorkDurationChange = useCallback((value: number[]) => {
    const newDuration = value[0];
    setSettings(prev => ({ ...prev, workMinutes: newDuration }));
    
    // Update current timer if it's a work session and not active
    if (isWork && !isActive) {
      setTotalSeconds(newDuration * 60);
    }
  }, [isWork, isActive]);

  const formatTime = useCallback((mins: number, secs: number) => {
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-gray-800 flex items-center justify-center gap-2">
            <Target className="text-indigo-600" />
            Pomodoro Timer
          </h1>
          <p className="text-gray-600">Focus • Work • Achieve</p>
        </div>

        {/* Task Editor */}
        <Card className="p-4 bg-white/80 backdrop-blur-sm border-0 shadow-lg">
          <div className="flex flex-col items-center space-y-2">
            <p className="text-sm text-gray-600">Current Task</p>
            <TaskEditor 
              currentTask={taskManager.currentTask}
              onTaskUpdate={taskManager.updateTask}
            />
          </div>
        </Card>

        {/* Work Duration Slider */}
        <Card className="p-4 bg-white/80 backdrop-blur-sm border-0 shadow-lg">
          <div className="space-y-4">
            <div className="text-center">
              <p className="text-sm text-gray-600 mb-1">Work Session Duration</p>
              <p className="text-2xl font-bold text-indigo-600">{settings.workMinutes} min</p>
            </div>
            
            <div className="px-2">
              <Slider
                value={[settings.workMinutes]}
                onValueChange={handleWorkDurationChange}
                min={15}
                max={90}
                step={5}
                disabled={isActive}
                className="w-full"
              />
            </div>
            
            <div className="flex justify-between text-xs text-gray-500">
              {workDurationOptions.map(duration => (
                <button
                  key={duration}
                  onClick={() => handleWorkDurationChange([duration])}
                  disabled={isActive}
                  className={`px-2 py-1 rounded text-xs ${
                    settings.workMinutes === duration 
                      ? 'bg-indigo-100 text-indigo-600 font-medium' 
                      : 'hover:bg-gray-100'
                  } ${isActive ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
                >
                  {duration}min
                </button>
              ))}
            </div>
          </div>
        </Card>

        {/* Main Timer Card */}
        <Card className="p-8 bg-white/80 backdrop-blur-sm border-0 shadow-xl">
          <div className="text-center space-y-6">
            {/* Session Type Indicator */}
            <div className="flex items-center justify-center gap-2">
              {isWork ? (
                <>
                  <Target className="text-indigo-600" size={20} />
                  <span className="text-lg font-medium text-indigo-600">Work Session</span>
                </>
              ) : (
                <>
                  <Coffee className="text-amber-600" size={20} />
                  <span className="text-lg font-medium text-amber-600">Break Time</span>
                </>
              )}
            </div>

            {/* Circular Progress */}
            <div className="relative w-48 h-48 mx-auto">
              <svg className="w-48 h-48 transform -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  stroke="currentColor"
                  strokeWidth="2"
                  fill="none"
                  className="text-gray-200"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  stroke="currentColor"
                  strokeWidth="4"
                  fill="none"
                  strokeDasharray={`${2 * Math.PI * 45}`}
                  strokeDashoffset={`${2 * Math.PI * 45 * (1 - progress / 100)}`}
                  className={`transition-all duration-1000 ${
                    isWork ? 'text-indigo-600' : 'text-amber-600'
                  }`}
                  strokeLinecap="round"
                />
              </svg>
              
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-4xl font-mono font-bold text-gray-800">
                  {formatTime(minutes, seconds)}
                </span>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-3">
              <Button
                onClick={toggleTimer}
                size="lg"
                className={`w-16 h-16 rounded-full ${
                  isWork 
                    ? 'bg-indigo-600 hover:bg-indigo-700' 
                    : 'bg-amber-600 hover:bg-amber-700'
                } text-white shadow-lg transition-all duration-200 hover:scale-105`}
              >
                {isActive ? <Pause size={24} /> : <Play size={24} />}
              </Button>

              <Button
                onClick={resetTimer}
                size="lg"
                variant="outline"
                className="w-12 h-12 rounded-full border-2 hover:scale-105 transition-all duration-200"
              >
                <RotateCcw size={20} />
              </Button>

              <Button
                onClick={skipSession}
                size="lg"
                variant="outline"
                className="w-12 h-12 rounded-full border-2 hover:scale-105 transition-all duration-200"
              >
                <SkipForward size={20} />
              </Button>
            </div>
          </div>
        </Card>

        {/* Stats Card */}
        <Card className="p-4 bg-white/60 backdrop-blur-sm border-0 shadow-lg">
          <div className="text-center space-y-2">
            <p className="text-sm text-gray-600">Completed Sessions</p>
            <p className="text-2xl font-bold text-indigo-600">{completedSessions}</p>
          </div>
        </Card>

        {/* Task History */}
        <TaskHistory
          recentTasks={taskManager.recentTasks}
          currentTask={taskManager.currentTask}
          onTaskSelect={taskManager.selectTask}
          onTaskDelete={taskManager.deleteTask}
          onClearHistory={taskManager.clearHistory}
        />

        {/* Settings Toggle */}
        <div className="text-center">
          <Button
            onClick={() => setShowSettings(!showSettings)}
            variant="ghost"
            className="text-gray-600 hover:text-gray-800"
          >
            <Settings size={18} className="mr-2" />
            Advanced Settings
          </Button>
        </div>

        {/* Settings Panel */}
        {showSettings && (
          <Card className="p-4 bg-white/80 backdrop-blur-sm border-0 shadow-lg space-y-4">
            <h3 className="font-semibold text-gray-800">Advanced Timer Settings</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-600 mb-1">Break (min)</label>
                <input
                  type="number"
                  value={settings.breakMinutes}
                  onChange={(e) => setSettings(prev => ({
                    ...prev,
                    breakMinutes: Math.max(1, parseInt(e.target.value) || 5)
                  }))}
                  className="w-full px-3 py-2 border rounded-lg text-center"
                  min="1"
                  max="30"
                />
              </div>
              
              <div>
                <label className="block text-sm text-gray-600 mb-1">Long Break (min)</label>
                <input
                  type="number"
                  value={settings.longBreakMinutes}
                  onChange={(e) => setSettings(prev => ({
                    ...prev,
                    longBreakMinutes: Math.max(1, parseInt(e.target.value) || 15)
                  }))}
                  className="w-full px-3 py-2 border rounded-lg text-center"
                  min="1"
                  max="60"
                />
              </div>
            </div>

            <Button
              onClick={() => {
                if (!isActive) {
                  const sessionDuration = isWork ? settings.workMinutes : settings.breakMinutes;
                  setTotalSeconds(sessionDuration * 60);
                }
                setShowSettings(false);
                toast({
                  title: "Settings updated!",
                  description: "Your timer settings have been saved.",
                });
              }}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white"
            >
              Save Settings
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
};

export default PomodoroTimer;
