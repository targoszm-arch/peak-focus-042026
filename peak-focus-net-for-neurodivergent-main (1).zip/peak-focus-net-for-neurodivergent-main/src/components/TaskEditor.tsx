
import React, { useState, useEffect } from 'react';
import { Edit, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface TaskEditorProps {
  currentTask: string;
  onTaskUpdate: (newTask: string) => void;
}

const TaskEditor = ({ currentTask, onTaskUpdate }: TaskEditorProps) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(currentTask);

  useEffect(() => {
    setEditValue(currentTask);
  }, [currentTask]);

  const handleSave = () => {
    const trimmedValue = editValue.trim();
    if (trimmedValue && trimmedValue !== currentTask) {
      onTaskUpdate(trimmedValue);
    }
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditValue(currentTask);
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSave();
    } else if (e.key === 'Escape') {
      handleCancel();
    }
  };

  if (isEditing) {
    return (
      <div className="flex items-center gap-3 w-full px-4">
        <Input
          value={editValue}
          onChange={(e) => setEditValue(e.target.value)}
          onKeyDown={handleKeyDown}
          className="text-center font-semibold text-lg h-14 flex-1 rounded-xl border-2 focus:border-indigo-400"
          maxLength={50}
          autoFocus
          placeholder="Enter task name..."
        />
        <Button
          size="sm"
          onClick={handleSave}
          className="h-12 w-12 p-0 bg-green-600 hover:bg-green-700 flex-shrink-0 rounded-xl"
        >
          <Check className="w-5 h-5" />
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={handleCancel}
          className="h-12 w-12 p-0 flex-shrink-0 rounded-xl border-2"
        >
          <X className="w-5 h-5" />
        </Button>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-4 group w-full px-4 py-2">
      <h2 className="text-xl md:text-2xl font-bold text-gray-800 flex-1 truncate min-w-0 text-center">
        {currentTask}
      </h2>
      <Button
        size="sm"
        variant="ghost"
        onClick={() => setIsEditing(true)}
        className="h-10 w-10 p-0 opacity-60 group-hover:opacity-100 transition-all duration-200 flex-shrink-0 rounded-lg hover:bg-gray-100"
      >
        <Edit className="w-4 h-4" />
      </Button>
    </div>
  );
};

export default TaskEditor;
