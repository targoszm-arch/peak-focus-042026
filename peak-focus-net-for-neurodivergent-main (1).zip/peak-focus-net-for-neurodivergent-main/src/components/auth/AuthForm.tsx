
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth, isPasswordResetFlow, parseUrlParameters } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { useRateLimit } from '@/hooks/useRateLimit';
import { Mountain, CheckCircle, AlertTriangle, Shield } from 'lucide-react';
import { PasswordResetForm } from './PasswordResetForm';
import { PasswordUpdateForm } from './PasswordUpdateForm';
import { sanitizeText, isValidEmail, validatePasswordStrength } from '@/lib/security';
import { supabase } from '@/integrations/supabase/client';

export const AuthForm = () => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [showPasswordReset, setShowPasswordReset] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [loading, setLoading] = useState(false);
  const [signUpSuccess, setSignUpSuccess] = useState(false);
  const [isReturningFromEmail, setIsReturningFromEmail] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState({ isValid: false, errors: [] as string[] });
  
  const { signUp, signIn, session, user } = useAuth();
  const { toast } = useToast();
  const { rateLimitState, checkRateLimit, recordFailedAttempt, resetRateLimit } = useRateLimit();

  // Check if user is returning from email confirmation or if we're in password reset flow
  useEffect(() => {
    const checkAuthState = () => {
      const { accessToken, type, error, errorDescription } = parseUrlParameters();
      
      console.log('🔐 AuthForm checking auth state:', { accessToken: !!accessToken, type, error });
      
      if (error) {
        console.error('🔐 Auth error detected:', error, errorDescription);
        toast({
          title: "Authentication Error",
          description: errorDescription || error,
          variant: "destructive",
        });
        return;
      }
      
      // Check if we're in password reset flow
      if (isPasswordResetFlow()) {
        console.log('🔐 Password reset flow detected in AuthForm');
        return; // Don't show other messages, PasswordUpdateForm will handle this
      }
      
      // Check for email confirmation
      if (type === 'signup' || (accessToken && type !== 'recovery')) {
        console.log('🔐 Email confirmation detected');
        setIsReturningFromEmail(true);
        
        toast({
          title: "Email Confirmed!",
          description: "Your account has been verified. You should be signed in automatically.",
        });
      }
    };

    checkAuthState();
  }, [toast]);

  // Auto-detect successful authentication after email confirmation
  useEffect(() => {
    if (user && isReturningFromEmail) {
      console.log('🔐 User authenticated after email confirmation:', user.email);
      toast({
        title: "Welcome!",
        description: `Successfully signed in as ${user.email}`,
      });
    }
  }, [user, isReturningFromEmail, toast]);

  // Password strength validation
  useEffect(() => {
    if (isSignUp && password) {
      const strength = validatePasswordStrength(password);
      setPasswordStrength(strength);
    }
  }, [password, isSignUp]);

  // Show password update form if in password reset flow
  if (isPasswordResetFlow()) {
    console.log('🔐 Rendering PasswordUpdateForm due to password reset flow');
    return <PasswordUpdateForm />;
  }

  // Show password reset form if requested
  if (showPasswordReset) {
    return <PasswordResetForm onBack={() => setShowPasswordReset(false)} />;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Sanitize inputs
    const sanitizedEmail = sanitizeText(email.toLowerCase().trim());
    const sanitizedPassword = password; // Don't sanitize password as it may contain special chars
    
    if (!sanitizedEmail || !sanitizedPassword) return;

    // Validate email format
    if (!isValidEmail(sanitizedEmail)) {
      toast({
        title: "Invalid Email",
        description: "Please enter a valid email address.",
        variant: "destructive",
      });
      return;
    }

    console.log('🔐 Form submit:', { isSignUp, email: sanitizedEmail });

    // Check rate limiting
    const attemptType = isSignUp ? 'signup' : 'signin';
    const canProceed = await checkRateLimit(sanitizedEmail, attemptType);
    
    if (!canProceed) {
      return; // Rate limit exceeded
    }

    // Validate password for signup
    if (isSignUp) {
      if (!passwordStrength.isValid) {
        toast({
          title: "Weak Password",
          description: passwordStrength.errors[0] || "Please choose a stronger password.",
          variant: "destructive",
        });
        return;
      }
    }

    setLoading(true);
    try {
      if (isSignUp) {
        const { error } = await signUp(sanitizedEmail, sanitizedPassword, {
          firstName: sanitizeText(firstName.trim()),
          lastName: sanitizeText(lastName.trim())
        });
        if (error) {
          console.error('🔐 Signup form error:', error);
          await recordFailedAttempt(sanitizedEmail, 'signup');
          
          if (error.message?.includes('rate') || error.status === 429) {
            toast({
              title: "Too Many Attempts",
              description: "Please wait a few minutes before trying again.",
              variant: "destructive",
            });
          } else if (error.message?.includes('already registered')) {
            toast({
              title: "Account Exists",
              description: "This email is already registered. Try signing in instead.",
              variant: "destructive",
            });
            setIsSignUp(false);
          } else {
            toast({
              title: "Signup Error",
              description: error.message || "Failed to create account. Please try again.",
              variant: "destructive",
            });
          }
        } else {
          await resetRateLimit(sanitizedEmail);
          setSignUpSuccess(true);
          toast({
            title: "Account Created!",
            description: "Please check your email and click the confirmation link to complete your registration.",
          });
        }
      } else {
        const { error } = await signIn(sanitizedEmail, sanitizedPassword);
        if (error) {
          console.error('🔐 Signin form error:', error);
          await recordFailedAttempt(sanitizedEmail, 'signin');
          
          if (error.status === 400 || error.message?.includes('Invalid login credentials')) {
            toast({
              title: "Sign In Failed",
              description: "Invalid email or password. If you forgot your password, use the reset option below.",
              variant: "destructive",
            });
          } else if (error.message?.includes('Email not confirmed')) {
            toast({
              title: "Email Not Confirmed",
              description: "Please check your email and click the confirmation link before signing in.",
              variant: "destructive",
            });
          } else {
            toast({
              title: "Sign In Error",
              description: error.message || "Failed to sign in. Please try again.",
              variant: "destructive",
            });
          }
        } else {
          await resetRateLimit(sanitizedEmail);
          console.log('🔐 Signin form success');
          toast({
            title: "Welcome back!",
            description: "Successfully signed in.",
          });
        }
      }
    } catch (error: any) {
      console.error('🔐 Form catch error:', error);
      toast({
        title: "Error",
        description: error.message || "An unexpected error occurred.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Show success state for email confirmation
  if (signUpSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <Mountain className="w-12 h-12 text-indigo-600" />
            </div>
            <CardTitle className="text-2xl font-bold">Peak Focus</CardTitle>
            <CardDescription>Check Your Email</CardDescription>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <div className="text-6xl mb-4">📧</div>
            <p className="text-muted-foreground">
              We've sent a confirmation email to <strong>{email}</strong>
            </p>
            <p className="text-sm text-muted-foreground">
              Click the link in the email to activate your account and start using Peak Focus.
            </p>
            <Button 
              variant="outline" 
              onClick={() => {
                setSignUpSuccess(false);
                setIsSignUp(false);
                setEmail('');
                setPassword('');
                setFirstName('');
                setLastName('');
              }}
              className="w-full"
            >
              Back to Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Mountain className="w-12 h-12 text-indigo-600" />
          </div>
          <CardTitle className="text-2xl font-bold">Peak Focus</CardTitle>
          <CardDescription>
            {isSignUp ? 'Create your account' : 'Sign in to your account'}
          </CardDescription>
          
          {isReturningFromEmail && (
            <div className="flex items-center gap-2 text-green-600 bg-green-50 p-2 rounded-md mt-2">
              <CheckCircle className="w-4 h-4" />
              <span className="text-sm">Email confirmed! You should be signed in automatically.</span>
            </div>
          )}

          {rateLimitState.isBlocked && (
            <div className="flex items-center gap-2 text-red-600 bg-red-50 p-2 rounded-md mt-2">
              <AlertTriangle className="w-4 h-4" />
              <span className="text-sm">Too many failed attempts. Try again later.</span>
            </div>
          )}
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignUp && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Input
                    type="text"
                    placeholder="First Name"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    required
                    disabled={loading || rateLimitState.isBlocked}
                    autoComplete="given-name"
                  />
                </div>
                <div>
                  <Input
                    type="text"
                    placeholder="Last Name"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    required
                    disabled={loading || rateLimitState.isBlocked}
                    autoComplete="family-name"
                  />
                </div>
              </div>
            )}
            
            <div>
              <Input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                disabled={loading || rateLimitState.isBlocked}
                autoComplete="email"
              />
            </div>
            <div>
              <Input
                type="password"
                placeholder={isSignUp ? "Password (min. 8 characters)" : "Password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                disabled={loading || rateLimitState.isBlocked}
                minLength={isSignUp ? 8 : undefined}
                autoComplete={isSignUp ? "new-password" : "current-password"}
              />
              {isSignUp && password && (
                <div className="mt-2 space-y-1">
                  {passwordStrength.errors.map((error, index) => (
                    <p key={index} className="text-xs text-red-500 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" />
                      {error}
                    </p>
                  ))}
                  {passwordStrength.isValid && (
                    <p className="text-xs text-green-500 flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" />
                      Password strength: Good
                    </p>
                  )}
                </div>
              )}
            </div>
            
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Shield className="w-3 h-3" />
              <span>Protected by security monitoring</span>
            </div>

            <div className="flex items-center justify-center">
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-background px-2 text-muted-foreground">or</span>
                </div>
              </div>
            </div>

            <Button
              type="button"
              variant="outline"
              className="w-full"
              onClick={async () => {
                setLoading(true);
                try {
                  const { error } = await supabase.auth.signInWithOAuth({
                    provider: 'google',
                    options: {
                      redirectTo: `${window.location.origin}/`
                    }
                  });
                  if (error) {
                    toast({
                      title: "Error",
                      description: error.message,
                      variant: "destructive",
                    });
                  }
                } catch (error) {
                  toast({
                    title: "Error",
                    description: "Failed to connect with Google",
                    variant: "destructive",
                  });
                } finally {
                  setLoading(false);
                }
              }}
              disabled={loading || rateLimitState.isBlocked}
            >
              <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              Continue with Google
            </Button>

            <Button 
              type="submit" 
              className="w-full" 
              disabled={loading || rateLimitState.isBlocked || (isSignUp && (!passwordStrength.isValid || !firstName.trim() || !lastName.trim()))}
            >
              {loading ? 'Processing...' : isSignUp ? 'Sign Up' : 'Sign In'}
            </Button>
          </form>
          
          <div className="mt-4 space-y-2 text-center">
            {!isSignUp && (
              <button
                type="button"
                onClick={() => setShowPasswordReset(true)}
                className="text-sm text-indigo-600 hover:underline"
                disabled={loading || rateLimitState.isBlocked}
              >
                Forgot your password?
              </button>
            )}
            
            <div>
              <button
                type="button"
                onClick={() => {
                  setIsSignUp(!isSignUp);
                  setEmail('');
                  setPassword('');
                  setFirstName('');
                  setLastName('');
                  setPasswordStrength({ isValid: false, errors: [] });
                }}
                className="text-sm text-muted-foreground hover:underline"
                disabled={loading || rateLimitState.isBlocked}
              >
                {isSignUp ? 'Already have an account? Sign in' : "Don't have an account? Sign up"}
              </button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
