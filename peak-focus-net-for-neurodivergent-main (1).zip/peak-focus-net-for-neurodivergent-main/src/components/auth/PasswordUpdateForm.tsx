
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth, parseUrlParameters } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { Mountain, Lock, CheckCircle, AlertCircle } from 'lucide-react';

export const PasswordUpdateForm = () => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const { updatePassword, session } = useAuth();
  const { toast } = useToast();

  // Check for auth errors and session state
  useEffect(() => {
    const { error, errorDescription } = parseUrlParameters();
    
    console.log('🔐 PasswordUpdateForm checking auth state:', { 
      hasSession: !!session,
      error,
      errorDescription
    });

    if (error) {
      console.error('🔐 Auth error in password update:', error, errorDescription);
      setAuthError(errorDescription || error);
      toast({
        title: "Authentication Error",
        description: errorDescription || error,
        variant: "destructive",
      });
    } else if (!session && !error) {
      // If no session and no error, the reset link might have expired
      console.log('🔐 No session found for password update');
      setAuthError("Password reset session expired. Please request a new password reset.");
      toast({
        title: "Session Expired",
        description: "Your password reset session has expired. Please request a new password reset.",
        variant: "destructive",
      });
    } else {
      console.log('🔐 Password update form ready');
      toast({
        title: "Password Reset Verified!",
        description: "Please enter your new password below.",
      });
    }
  }, [session, toast]);

  const validatePassword = (password: string) => {
    if (password.length < 6) {
      return "Password must be at least 6 characters long";
    }
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password || !confirmPassword) return;

    console.log('🔐 Password update form submit');

    // Validate password
    const passwordError = validatePassword(password);
    if (passwordError) {
      toast({
        title: "Invalid Password",
        description: passwordError,
        variant: "destructive",
      });
      return;
    }

    // Check passwords match
    if (password !== confirmPassword) {
      toast({
        title: "Passwords Don't Match",
        description: "Please make sure both passwords are the same.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const { error } = await updatePassword(password);
      
      if (error) {
        console.error('🔐 Password update form error:', error);
        toast({
          title: "Update Failed",
          description: error.message || "Failed to update password. Please try again.",
          variant: "destructive",
        });
      } else {
        console.log('🔐 Password update form success');
        toast({
          title: "Password Updated!",
          description: "Your password has been successfully updated. You are now signed in.",
        });
        // The auth state change will handle navigation
      }
    } catch (error: any) {
      console.error('🔐 Password update catch error:', error);
      toast({
        title: "Error",
        description: error.message || "An unexpected error occurred.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRequestNewReset = () => {
    // Clear URL and redirect to auth form
    window.history.replaceState({}, document.title, '/');
    window.location.reload();
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Mountain className="w-12 h-12 text-indigo-600" />
          </div>
          <CardTitle className="text-2xl font-bold">Set New Password</CardTitle>
          <CardDescription>
            Enter your new password to complete the reset process
          </CardDescription>
          
          {!authError ? (
            <div className="flex items-center gap-2 text-green-600 bg-green-50 p-2 rounded-md mt-2">
              <CheckCircle className="w-4 h-4" />
              <span className="text-sm">Password reset verified! Set your new password below.</span>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-red-600 bg-red-50 p-2 rounded-md mt-2">
              <AlertCircle className="w-4 h-4" />
              <span className="text-sm">{authError}</span>
            </div>
          )}
        </CardHeader>
        <CardContent>
          {!authError ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Input
                  type="password"
                  placeholder="New password (min. 6 characters)"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  disabled={loading}
                  minLength={6}
                />
              </div>
              <div>
                <Input
                  type="password"
                  placeholder="Confirm new password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  disabled={loading}
                  minLength={6}
                />
              </div>
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? 'Updating...' : (
                  <>
                    <Lock className="w-4 h-4 mr-2" />
                    Update Password
                  </>
                )}
              </Button>
            </form>
          ) : (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground text-center">
                Your password reset link may have expired or been used already.
              </p>
              <Button 
                onClick={handleRequestNewReset}
                className="w-full"
                variant="outline"
              >
                Request New Password Reset
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
