
import React from 'react';
import { History, Trash2, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface TaskHistoryProps {
  recentTasks: string[];
  currentTask: string;
  onTaskSelect: (task: string) => void;
  onTaskDelete: (task: string) => void;
  onClearHistory: () => void;
}

const TaskHistory = ({ 
  recentTasks, 
  currentTask, 
  onTaskSelect, 
  onTaskDelete, 
  onClearHistory 
}: TaskHistoryProps) => {
  if (recentTasks.length === 0) {
    return null;
  }

  return (
    <Card className="p-5 bg-white/80 backdrop-blur-sm border-0 shadow-lg space-y-4 mx-4 rounded-xl">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-lg text-gray-800 flex items-center gap-3">
          <History className="w-5 h-5 text-indigo-600" />
          Recent Tasks
        </h3>
        <Button
          variant="ghost"
          size="sm"
          onClick={onClearHistory}
          className="text-sm text-gray-500 hover:text-gray-700 h-10 px-3 rounded-lg"
        >
          Clear All
        </Button>
      </div>
      
      <div className="space-y-3 max-h-40 overflow-y-auto">
        {recentTasks.map((task, index) => (
          <div key={index} className="flex items-center justify-between group bg-gray-50/50 rounded-lg p-1">
            <button
              onClick={() => onTaskSelect(task)}
              className={`flex-1 text-left px-4 py-3 rounded-lg text-base transition-all duration-200 flex items-center gap-3 min-h-[44px] ${
                task === currentTask
                  ? 'bg-indigo-100 text-indigo-800 shadow-sm'
                  : 'hover:bg-white hover:shadow-sm text-gray-700'
              }`}
            >
              <Clock className="w-4 h-4 flex-shrink-0 text-gray-400" />
              <span className="truncate font-medium">{task}</span>
            </button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onTaskDelete(task)}
              className="h-10 w-10 p-0 opacity-0 group-hover:opacity-100 transition-all duration-200 ml-2 flex-shrink-0 rounded-lg hover:bg-red-50 hover:text-red-600"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        ))}
      </div>
    </Card>
  );
};

export default TaskHistory;
