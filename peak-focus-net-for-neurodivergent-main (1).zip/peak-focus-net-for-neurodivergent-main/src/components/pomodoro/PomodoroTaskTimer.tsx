
import { useState, useEffect, useRef, useCallback, useMemo, startTransition } from 'react';
import { Play, Pause, RotateCcw, X, Timer, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { toast } from '@/hooks/use-toast';
import type { Task } from '@/types/database';

interface PomodoroTaskTimerProps {
  task: Task;
  open: boolean;
  onClose: () => void;
  onSessionComplete: (taskId: string, duration: number) => void;
  workMinutes?: number;
  breakMinutes?: number;
}

export const PomodoroTaskTimer = ({ 
  task, 
  open, 
  onClose, 
  onSessionComplete,
  workMinutes = 25,
  breakMinutes = 5 
}: PomodoroTaskTimerProps) => {
  // Use task's estimated duration if available, otherwise fall back to workMinutes parameter
  const taskDurationMinutes = task.estimated_duration || workMinutes;
  
  // Single source of truth for timer state
  const [totalSeconds, setTotalSeconds] = useState(taskDurationMinutes * 60);
  const [isActive, setIsActive] = useState(false);
  const [isWork, setIsWork] = useState(true);
  const [currentSession, setCurrentSession] = useState(1);
  
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const bellAudioRef = useRef<HTMLAudioElement | null>(null);
  const lastNotificationRef = useRef<number>(0);

  // Memoize calculated values
  const { minutes, seconds, progress } = useMemo(() => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    const sessionDuration = (isWork ? taskDurationMinutes : breakMinutes) * 60;
    const prog = ((sessionDuration - totalSeconds) / sessionDuration) * 100;
    
    return {
      minutes: mins,
      seconds: secs,
      progress: Math.max(0, Math.min(100, prog))
    };
  }, [totalSeconds, isWork, taskDurationMinutes, breakMinutes]);

  useEffect(() => {
    // Reset timer when task changes or dialog opens
    if (open) {
      setTotalSeconds(taskDurationMinutes * 60);
      setIsActive(false);
      setIsWork(true);
      setCurrentSession(1);
    }
  }, [open, task.id, taskDurationMinutes]);

  useEffect(() => {
    // Simple bell sound for session completion
    bellAudioRef.current = new Audio();
    bellAudioRef.current.src = "data:audio/wav;base64,UklGRjIEAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQ4EAACBHYSC7YFnhUiJooVmhXWGJoh1hDKDLIJHhFqFVIM6hGaF8IFRgwWDGYU/hDmDNINGhReEcoRbhLCDsIJPhAaEgYPogzeE84P7gZeEkITjgv2CvoPRhOODnINNhPaD/ILGhMqEtIN4hEiFqoT0gomDgYOpg6yD0YMwhOeCfYPbgz2DuYPFhKKDb4PXhNeEcoRBhPiDP4SPg7aDy4R5g4WD0IOQhD6Ds4PWg8ODk4P8g2mDrIMrg4CDpIOJhLqD5IL+gnKC8IHQgZqBx4GegXKBsoFGgbWBl4EJgq+B14F1gU+By4Fqgf6Bt4HDgTyC/YENgryB2oFtgYKBtoGEgXWBcIGYgVSBj4G1gQuBvoGGgbeB44GkgaOBDYL8gQKCIYI7gsiBpoGXgciBVYGXgVSBhYGdgYaBkoH2gR+C14FLgdeBWYGrgeWBmIGDgYqBU4FfgX2B54G8gSeCM4LZgaGBqIGKgX6BfYG7gUaBm4FqgQ+BpIG7gWOBvIFhgYmBbYHdgSSCyoH4gfGBDYKzgZaBjIF6gaqBSYGGgXWBPoGHgZiBHoGggZOBUYGzgUqBp4FAgY2BlIFigVOBf4EngYyBwYFXgWqBT4FXgbuBNIGIgc+B+YCkgSKBhYEKgb+BWoF+gTaBqoFpgY+BKYF6gR+BjYG6gQ==";
    
    return () => {
      if (bellAudioRef.current) {
        bellAudioRef.current.remove();
      }
    };
  }, []);

  // Optimized timer completion handler
  const handleTimerComplete = useCallback(() => {
    const now = Date.now();
    
    // Debounce notifications to prevent spam
    if (now - lastNotificationRef.current < 1000) {
      return;
    }
    lastNotificationRef.current = now;
    
    // Play completion sound
    bellAudioRef.current?.play().catch(console.error);

    // Batch state updates using startTransition
    startTransition(() => {
      setIsActive(false);

      if (isWork) {
        // Work session completed
        onSessionComplete(task.id, taskDurationMinutes);
        
        if (currentSession >= task.pomodoro_sessions_planned) {
          toast({
            title: `Task "${task.title}" completed! 🎉`,
            description: `All ${task.pomodoro_sessions_planned} Pomodoro sessions finished.`,
          });
          onClose();
        } else {
          // Start break
          setTotalSeconds(breakMinutes * 60);
          setIsWork(false);
          
          toast({
            title: `Pomodoro ${currentSession}/${task.pomodoro_sessions_planned} completed! ⏰`,
            description: `Time for a ${breakMinutes}-minute break.`,
          });
        }
      } else {
        // Break completed
        setCurrentSession(prev => prev + 1);
        setTotalSeconds(taskDurationMinutes * 60);
        setIsWork(true);
        
        toast({
          title: "Break over! 💪",
          description: `Ready for Pomodoro ${currentSession + 1}/${task.pomodoro_sessions_planned}`,
        });
      }
    });
  }, [isWork, task.id, taskDurationMinutes, breakMinutes, currentSession, task.pomodoro_sessions_planned, task.title, onSessionComplete, onClose]);

  // Optimized timer effect - only recreate when isActive changes
  useEffect(() => {
    if (isActive) {
      intervalRef.current = setInterval(() => {
        setTotalSeconds(prevSeconds => {
          if (prevSeconds <= 1) {
            // Timer complete - will be handled in next render
            return 0;
          }
          return prevSeconds - 1;
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [isActive]);

  // Handle timer completion when totalSeconds reaches 0
  useEffect(() => {
    if (isActive && totalSeconds === 0) {
      handleTimerComplete();
    }
  }, [isActive, totalSeconds, handleTimerComplete]);

  const toggleTimer = useCallback(() => {
    setIsActive(prev => !prev);
  }, []);

  const resetTimer = useCallback(() => {
    setIsActive(false);
    const sessionDuration = isWork ? taskDurationMinutes : breakMinutes;
    setTotalSeconds(sessionDuration * 60);
  }, [isWork, taskDurationMinutes, breakMinutes]);

  const formatTime = useCallback((mins: number, secs: number) => {
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  }, []);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Timer className="w-5 h-5" />
            Pomodoro Timer
          </DialogTitle>
          <DialogDescription>
            Focus timer for your task with work and break sessions
          </DialogDescription>
        </DialogHeader>
        
        <Card className="border-0 shadow-none">
          <CardHeader className="text-center pb-2">
            <div className="space-y-2">
              <h3 className="font-medium text-lg truncate">{task.title}</h3>
              <div className="text-sm text-muted-foreground">
                Session {currentSession}/{task.pomodoro_sessions_planned}
              </div>
              <div className={`text-sm font-medium flex items-center justify-center gap-2 ${
                isWork ? 'text-blue-600' : 'text-green-600'
              }`}>
                {isWork ? (
                  <>
                    <Target className="w-4 h-4" />
                    Focus Time
                  </>
                ) : (
                  '☕ Break Time'
                )}
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {/* Circular Progress */}
            <div className="relative w-32 h-32 mx-auto">
              <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  stroke="currentColor"
                  strokeWidth="2"
                  fill="none"
                  className="text-muted"
                />
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  stroke="currentColor"
                  strokeWidth="4"
                  fill="none"
                  strokeDasharray={`${2 * Math.PI * 45}`}
                  strokeDashoffset={`${2 * Math.PI * 45 * (1 - progress / 100)}`}
                  className={`transition-all duration-1000 ${
                    isWork ? 'text-blue-500' : 'text-green-500'
                  }`}
                  strokeLinecap="round"
                />
              </svg>
              
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-2xl font-mono font-bold">
                  {formatTime(minutes, seconds)}
                </span>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-center gap-3">
              <Button
                onClick={toggleTimer}
                size="lg"
                className={`w-14 h-14 rounded-full ${
                  isWork 
                    ? 'bg-blue-600 hover:bg-blue-700' 
                    : 'bg-green-600 hover:bg-green-700'
                } text-white`}
              >
                {isActive ? <Pause size={20} /> : <Play size={20} />}
              </Button>

              <Button
                onClick={resetTimer}
                size="lg"
                variant="outline"
                className="w-12 h-12 rounded-full"
              >
                <RotateCcw size={18} />
              </Button>
            </div>

            {/* Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>Overall Progress</span>
                <span>{task.pomodoro_sessions_completed + (isWork && !isActive && totalSeconds === taskDurationMinutes * 60 ? 0 : currentSession - 1)}/{task.pomodoro_sessions_planned}</span>
              </div>
              <Progress 
                value={(task.pomodoro_sessions_completed / task.pomodoro_sessions_planned) * 100} 
                className="h-2" 
              />
            </div>
          </CardContent>
        </Card>
        
        <div className="flex justify-end">
          <Button variant="ghost" onClick={onClose}>
            <X className="w-4 h-4 mr-2" />
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
