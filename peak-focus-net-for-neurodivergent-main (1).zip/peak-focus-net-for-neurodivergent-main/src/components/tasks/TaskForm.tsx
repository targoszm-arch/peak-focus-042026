import { useState, useCallback, useMemo, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from '@/components/ui/dialog';
import { CalendarIcon, Clock, Plus, Edit2, X } from 'lucide-react';
import { format, parseISO } from 'date-fns';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { RelatedItemsList } from '@/components/relationships/RelatedItemsList';
import { LinkItemsDialog } from '@/components/relationships/LinkItemsDialog';
import type { Task, Project, Priority } from '@/types/database';
interface TaskFormProps {
  task?: Task;
  projects: Project[];
  onSubmit: (taskData: Partial<Task>) => Promise<void>;
  onCancel?: () => void;
  trigger?: React.ReactNode;
  // Modal mode props
  isOpen?: boolean;
  onClose?: () => void;
}
export const TaskForm = ({
  task,
  projects,
  onSubmit,
  onCancel,
  trigger,
  isOpen: controlledOpen,
  onClose
}: TaskFormProps) => {
  // Modal state management
  const [internalOpen, setInternalOpen] = useState(false);
  const isControlled = controlledOpen !== undefined;
  const open = isControlled ? controlledOpen : internalOpen;
  const setOpen = isControlled ? (open: boolean) => !open && onClose?.() : setInternalOpen;

  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [projectId, setProjectId] = useState('no-project');
  const [priority, setPriority] = useState<Priority>('medium');
  const [estimatedDuration, setEstimatedDuration] = useState(30);
  const [dueDate, setDueDate] = useState<Date | undefined>(undefined);
  const [pomodoroSessions, setPomodoroSessions] = useState(1);
  const [activeButton, setActiveButton] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [dueDatePopoverOpen, setDueDatePopoverOpen] = useState(false);
  const [relationshipsKey, setRelationshipsKey] = useState(0);
  const {
    toast
  } = useToast();

  // Reset form when task changes or dialog opens/closes
  useEffect(() => {
    if (open) {
      if (task) {
        console.log('📝 TaskForm editing task:', task);
        setTitle(task.title || '');
        setDescription(task.description || '');
        setProjectId(task.project_id || 'no-project');
        setPriority(task.priority || 'medium');
        setEstimatedDuration(task.estimated_duration || 30);
        setDueDate(task.due_date ? parseISO(task.due_date) : undefined);
        setPomodoroSessions(task.pomodoro_sessions_planned || 1);
      } else {
        console.log('📝 TaskForm creating new task');
        setTitle('');
        setDescription('');
        setProjectId('no-project');
        setPriority('medium');
        setEstimatedDuration(30);
        setDueDate(undefined);
        setPomodoroSessions(1);
      }
    }
  }, [open, task]);

  // Optimized duration handler with immediate feedback and proper state management
  const handleDurationChange = useCallback((duration: number) => {
    // Immediate state updates
    setEstimatedDuration(duration);
    setActiveButton(duration);

    // Clear active state quickly to prevent sticky hover
    requestAnimationFrame(() => {
      setTimeout(() => setActiveButton(null), 80);
    });
    console.log(`[TaskForm] Duration selected: ${duration}min`);
  }, []);
  const calculatePomodoroSessions = (duration: number) => {
    return Math.max(1, Math.ceil(duration / 25));
  };
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      toast({
        title: "Task title required",
        description: "Please enter a task title",
        variant: "destructive"
      });
      return;
    }
    setLoading(true);
    try {
      const taskData: Partial<Task> = {
        title: title.trim()
      };

      // Only add description if it's not empty
      if (description.trim()) {
        taskData.description = description.trim();
      }

      // Only add project_id if one is selected (not "no-project")
      if (projectId && projectId !== 'no-project') {
        taskData.project_id = projectId;
      }
      taskData.priority = priority;
      taskData.estimated_duration = estimatedDuration;
      taskData.pomodoro_sessions_planned = calculatePomodoroSessions(estimatedDuration);

      // Add date if provided
      if (dueDate) {
        taskData.due_date = format(dueDate, 'yyyy-MM-dd');
      }
      console.log('📝 TaskForm submitting task:', {
        title: taskData.title,
        priority: taskData.priority,
        estimatedDuration: taskData.estimated_duration,
        isEdit: !!task
      });
      await onSubmit(taskData);
      console.log('📝 TaskForm task submitted successfully');
      setOpen(false);
      if (!task) {
        // Reset form for new tasks
        setTitle('');
        setDescription('');
        setProjectId('no-project');
        setPriority('medium');
        setEstimatedDuration(30);
        setDueDate(undefined);
        setPomodoroSessions(1);
      }
    } catch (error) {
      console.error('📝 TaskForm submission error:', error);
      toast({
        title: task ? "Failed to update task" : "Failed to create task",
        description: "Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  const handleCancel = () => {
    setOpen(false);
    onCancel?.();
  };
  const handleDateSelect = (selectedDate: Date | undefined) => {
    setDueDate(selectedDate);
    setDueDatePopoverOpen(false);
  };
  const priorityColors = {
    low: 'bg-green-100 text-green-800',
    medium: 'bg-yellow-100 text-yellow-800',
    high: 'bg-orange-100 text-orange-800',
    urgent: 'bg-red-100 text-red-800'
  };
  const durationPresets = [15, 30, 60, 90, 120, 240];

  // Optimized duration buttons with proper state management
  const durationButtons = useMemo(() => {
    return durationPresets.map(duration => {
      const isSelected = estimatedDuration === duration;
      const isActive = activeButton === duration;
      return <button key={duration} type="button" onClick={() => handleDurationChange(duration)} onMouseLeave={() => setActiveButton(null)} onBlur={() => setActiveButton(null)} disabled={loading} className={cn("inline-flex items-center justify-center rounded-md text-xs font-medium", "h-9 px-3 transition-all duration-100 ease-out", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", "select-none touch-action-manipulation",
      // Base state
      "border border-input bg-background",
      // Selected state (highest priority)
      isSelected && "bg-primary text-primary-foreground border-primary shadow-sm",
      // Active/pressed state
      isActive && !isSelected && "bg-primary/20 border-primary/50 scale-95",
      // Hover state (only when not selected or active)
      !isSelected && !isActive && "hover:bg-accent hover:text-accent-foreground hover:border-accent-foreground/20")} style={{
        transform: isActive ? 'scale(0.95)' : isSelected ? 'scale(1.02)' : 'scale(1)',
        transition: 'transform 80ms ease-out, background-color 100ms ease-out, border-color 100ms ease-out'
      }}>
          {duration}m
        </button>;
    });
  }, [estimatedDuration, activeButton, handleDurationChange, loading]);
  const dialogContent = <DialogContent className="sm:max-w-[500px] max-w-[95vw] max-h-[90vh] overflow-y-auto">
      <DialogHeader className="space-y-0 pb-4">
        <DialogTitle className="text-lg font-semibold">
          {task ? 'Edit Task' : 'Create New Task'}
        </DialogTitle>
        <DialogDescription>
          {task ? 'Modify your task details and settings.' : 'Create a new task with all the necessary details.'}
        </DialogDescription>
      </DialogHeader>

      <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
        <div className="space-y-2">
          <Label htmlFor="title">Task Title</Label>
          <Input id="title" value={title} onChange={e => setTitle(e.target.value)} placeholder="What needs to be done?" required disabled={loading} />
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description (optional)</Label>
          <Textarea id="description" value={description} onChange={e => setDescription(e.target.value)} placeholder="Add more details..." className="min-h-[60px] sm:min-h-[80px]" disabled={loading} />
        </div>

        {projects.length > 0 && <div className="space-y-2">
            <Label>Project (optional)</Label>
            <Select value={projectId} onValueChange={setProjectId} disabled={loading}>
              <SelectTrigger>
                <SelectValue placeholder="Select a project" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="no-project">No project</SelectItem>
                {projects.map(project => <SelectItem key={project.id} value={project.id}>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{
                  backgroundColor: project.color
                }} />
                      {project.name}
                    </div>
                  </SelectItem>)}
              </SelectContent>
            </Select>
          </div>}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Priority</Label>
            <Select value={priority} onValueChange={(value: Priority) => setPriority(value)} disabled={loading}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">
                  <div className="flex items-center gap-2">
                    <Badge className={priorityColors.low}>Low</Badge>
                  </div>
                </SelectItem>
                <SelectItem value="medium">
                  <div className="flex items-center gap-2">
                    <Badge className={priorityColors.medium}>Medium</Badge>
                  </div>
                </SelectItem>
                <SelectItem value="high">
                  <div className="flex items-center gap-2">
                    <Badge className={priorityColors.high}>High</Badge>
                  </div>
                </SelectItem>
                <SelectItem value="urgent">
                  <div className="flex items-center gap-2">
                    <Badge className={priorityColors.urgent}>Urgent</Badge>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Estimated Duration (min)</Label>
            <div className="flex gap-1 flex-wrap">
              {durationButtons}
            </div>
            <div className="text-xs text-muted-foreground mt-1 font-medium">
              Selected: {estimatedDuration} minutes
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Due Date (optional)</Label>
            <Popover open={dueDatePopoverOpen} onOpenChange={setDueDatePopoverOpen}>
              <PopoverTrigger asChild>
                <Button variant="outline" className={cn("w-full justify-start text-left font-normal", !dueDate && "text-muted-foreground")} disabled={loading}>
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dueDate ? format(dueDate, "PPP") : "Pick a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar mode="single" selected={dueDate} onSelect={handleDateSelect} initialFocus className="pointer-events-auto" />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label>Pomodoro Sessions</Label>
            <div className="flex items-center gap-2">
              <Input type="number" value={pomodoroSessions} onChange={e => setPomodoroSessions(Math.max(1, Number(e.target.value)))} min={1} max={20} className="w-24" disabled={loading} />
              <Clock className="w-4 h-4" />
              <span className="text-sm text-muted-foreground">
                ≈ {pomodoroSessions * 25} minutes
              </span>
            </div>
            <div className="text-xs text-muted-foreground">
              Estimated Pomodoro sessions: {calculatePomodoroSessions(estimatedDuration)}
            </div>
          </div>
        </div>

        {task && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-medium">Related Items</h4>
              <LinkItemsDialog 
                sourceType="task" 
                sourceId={task.id}
                onLinked={() => setRelationshipsKey(prev => prev + 1)}
              />
            </div>
            <RelatedItemsList 
              key={relationshipsKey}
              entityType="task" 
              entityId={task.id}
              onRefresh={() => setRelationshipsKey(prev => prev + 1)}
            />
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-3 pt-4">
          <Button type="button" variant="outline" onClick={handleCancel} className="flex-1" disabled={loading}>
            Cancel
          </Button>
          <Button type="submit" disabled={!title.trim() || loading} className="flex-1">
            {loading ? <>
                <div className="w-4 h-4 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent" />
                {task ? 'Updating...' : 'Creating...'}
              </> : <>
                {task ? <Edit2 className="w-4 h-4 mr-2" /> : <Plus className="w-4 h-4 mr-2" />}
                {task ? 'Update Task' : 'Create Task'}
              </>}
          </Button>
        </div>
      </form>
    </DialogContent>;

  // If controlled (modal mode), don't render Dialog wrapper
  if (isControlled) {
    return <Dialog open={open} onOpenChange={setOpen}>
        {dialogContent}
      </Dialog>;
  }

  // Default trigger-based mode
  return <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || <Button><Plus className="w-4 h-4 mr-2" />Add Task</Button>}
      </DialogTrigger>
      {dialogContent}
    </Dialog>;
};