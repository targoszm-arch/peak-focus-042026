
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Clock, Timer, Play, CheckSquare, Target, Calendar, Filter, Edit, Trash2, FileText } from 'lucide-react';
import { MountainVisualization } from '@/components/mountain/MountainVisualization';
import { PomodoroTaskTimer } from '@/components/pomodoro/PomodoroTaskTimer';
import { TaskForm } from './TaskForm';
import { usePomodoroSessions } from '@/hooks/usePomodoroSessions';
import { useRelatedNotesCount } from '@/hooks/useRelatedNotesCount';
import type { Task, Project, DailyProgress } from '@/types/database';

// Component to show related notes count for a task
const TaskNotesCount = ({ taskId }: { taskId: string }) => {
  const { noteCount, loading } = useRelatedNotesCount('task', taskId);

  if (loading || noteCount === 0) return null;

  return (
    <div className="flex items-center gap-1">
      <FileText className="w-3 h-3" />
      <span>{noteCount}</span>
    </div>
  );
};

interface TaskListProps {
  tasks: Task[];
  projects: Project[];
  onUpdateTask: (id: string, updates: Partial<Task>) => Promise<void>;
  onDeleteTask: (id: string) => Promise<void>;
  dailyProgress?: DailyProgress | null;
  showMountain?: boolean; // Optional prop to control mountain visibility
}

export const TaskList = ({
  tasks,
  projects,
  onUpdateTask,
  onDeleteTask,
  dailyProgress,
  showMountain = true // Default to true for backward compatibility
}: TaskListProps) => {
  const [selectedTimerTask, setSelectedTimerTask] = useState<Task | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const {
    createPomodoroSession
  } = usePomodoroSessions();

  const priorityColors = {
    low: 'bg-green-100 text-green-800 border-green-200',
    medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    high: 'bg-orange-100 text-orange-800 border-orange-200',
    urgent: 'bg-red-100 text-red-800 border-red-200'
  };

  const statusColors = {
    todo: 'text-gray-600',
    completed: 'text-green-600 line-through',
    archived: 'text-gray-400'
  };

  const handleStatusChange = (task: Task, completed: boolean) => {
    console.log('[TASK_LIST] Status change:', task.id, completed);
    onUpdateTask(task.id, {
      status: completed ? 'completed' : 'todo',
      completion_date: completed ? new Date().toISOString() : undefined,
      actual_duration: completed ? task.estimated_duration : undefined
    });
  };

  const handlePomodoroSessionComplete = async (taskId: string, duration: number) => {
    try {
      await createPomodoroSession(taskId, duration);
      window.location.reload();
    } catch (error) {
      console.error('Failed to complete Pomodoro session:', error);
    }
  };

  const filteredTasks = tasks.filter(task => {
    if (statusFilter !== 'all' && task.status !== statusFilter) return false;
    if (priorityFilter !== 'all' && task.priority !== priorityFilter) return false;
    return true;
  });

  // Use dailyProgress data for mountain visualization
  const getCompletionPercentage = () => {
    if (dailyProgress) {
      console.log('[TASK_LIST] Using dailyProgress data:', dailyProgress.mountain_reduction_percentage);
      return dailyProgress.mountain_reduction_percentage || 0;
    }

    // Fallback calculation
    const completed = tasks.filter(task => task.status === 'completed').length;
    const total = tasks.length;
    const percentage = total > 0 ? completed / total * 100 : 0;
    console.log('[TASK_LIST] Fallback calculation:', {
      completed,
      total,
      percentage
    });
    return percentage;
  };

  const completionPercentage = getCompletionPercentage();

  if (tasks.length === 0) {
    return <Card className="text-center py-12">
        <CardContent>
          <div className="text-4xl mb-4">
            <Target className="w-16 h-16 mx-auto text-muted-foreground" />
          </div>
          <h3 className="text-lg font-medium mb-2">No tasks for today</h3>
          <p className="text-sm text-muted-foreground">Create your first task to start climbing your productivity mountain!</p>
        </CardContent>
      </Card>;
  }

  return <TooltipProvider>
      <div className="space-y-6">
        {/* Mountain Visualization - only show when showMountain is true */}
        {showMountain && (
          <div className="mb-6">
            <MountainVisualization completionPercentage={completionPercentage} theme="alpine" />
          </div>
        )}

        {/* Filters */}
        <div className="flex flex-wrap gap-4 items-center">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4" />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="todo">To Do</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Select value={priorityFilter} onValueChange={setPriorityFilter}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Priority</SelectItem>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="urgent">Urgent</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Tasks Grid */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckSquare className="w-5 h-5" />
              Tasks ({filteredTasks.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 p-4 sm:p-6">
              {filteredTasks.map(task => {
              const project = projects.find(p => p.id === task.project_id);
               return <Card 
                 key={task.id} 
                 className="hover:shadow-md transition-all duration-200 relative flex flex-col h-full cursor-pointer" 
                 onClick={(e) => {
                   // Don't trigger card click when clicking on interactive elements
                   if (
                     (e.target as HTMLElement).closest('button') || 
                     (e.target as HTMLElement).closest('[role="checkbox"]') ||
                     (e.target as HTMLElement).closest('.checkbox')
                   ) {
                     return;
                   }
                   setEditingTask(task);
                 }}
               >
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2 flex-1 min-w-0">
                          <Checkbox checked={task.status === 'completed'} onCheckedChange={checked => handleStatusChange(task, !!checked)} className="!h-5 !w-5 !min-w-[20px] !min-h-[20px] !max-w-[20px] !max-h-[20px] aspect-square !border-2 !rounded-md shrink-0" />
                          <div className="flex-1 min-w-0">
                            <h3 className={`font-medium text-sm truncate leading-5 ${statusColors[task.status]}`}>
                              {task.title}
                            </h3>
                            {project && <span className="text-xs text-muted-foreground mt-1 block">{project.name}</span>}
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <Badge className={priorityColors[task.priority]} variant="outline">
                            {task.priority}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="pt-0 flex-1 flex flex-col">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>{task.estimated_duration}min</span>
                          </div>

                          <div className="flex items-center gap-1">
                            <Timer className="w-3 h-3" />
                            <span>{task.pomodoro_sessions_completed}/{task.pomodoro_sessions_planned}</span>
                           </div>

                           <TaskNotesCount taskId={task.id} />

                           {task.due_date && <div className="flex items-center gap-1">
                               <Calendar className="w-3 h-3" />
                               <span>{new Date(task.due_date).toLocaleDateString()}</span>
                             </div>}
                         </div>
                      </div>

                      <div className="mt-auto pt-2 flex items-center gap-2">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button size="sm" variant="outline" onClick={() => setSelectedTimerTask(task)} disabled={task.status === 'completed'} className="h-8 w-24">
                              <Play className="w-3 h-3 mr-1" />
                              Timer
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Start Focus Session</TooltipContent>
                        </Tooltip>
                        
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-destructive hover:text-destructive">
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Task</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete "{task.title}"? This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => onDeleteTask(task.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </CardContent>
                  </Card>;
            })}
          </CardContent>
        </Card>
      </div>

      {/* Edit Task Form */}
      {editingTask && (
        <TaskForm 
          isOpen={!!editingTask} 
          onClose={() => setEditingTask(null)} 
          onSubmit={async (updates) => {
            await onUpdateTask(editingTask.id, updates);
            setEditingTask(null);
          }} 
          task={editingTask} 
          projects={projects} 
        />
      )}

      {/* Pomodoro Timer Modal */}
      {selectedTimerTask && <PomodoroTaskTimer task={selectedTimerTask} open={!!selectedTimerTask} onClose={() => setSelectedTimerTask(null)} onSessionComplete={handlePomodoroSessionComplete} />}
    </TooltipProvider>;
};
