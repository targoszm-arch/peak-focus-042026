import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Plus, CheckSquare, FileText, Folder } from 'lucide-react';
import { useRelationships, type EntityType } from '@/hooks/useRelationships';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface LinkItemsDialogProps {
  sourceType: EntityType;
  sourceId: string;
  onLinked?: () => void;
  trigger?: React.ReactNode;
}

export const LinkItemsDialog = ({ sourceType, sourceId, onLinked, trigger }: LinkItemsDialogProps) => {
  const [open, setOpen] = useState(false);
  const [targetType, setTargetType] = useState<EntityType>('task');
  const [targetId, setTargetId] = useState<string>('');
  const [availableItems, setAvailableItems] = useState<Array<{ id: string; title: string; created_at: string }>>([]);
  
  const { loading, createRelationship, getAvailableItems } = useRelationships();

  useEffect(() => {
    const fetchAvailableItems = async () => {
      if (open && targetType) {
        const items = await getAvailableItems(targetType, sourceId);
        setAvailableItems(items);
        setTargetId(''); // Reset selection when type changes
      }
    };

    fetchAvailableItems();
  }, [open, targetType, sourceId, getAvailableItems]);

  const handleLink = async () => {
    if (!targetId) return;

    const success = await createRelationship(sourceType, sourceId, targetType, targetId);
    if (success) {
      setOpen(false);
      setTargetId('');
      onLinked?.();
    }
  };

  const getEntityIcon = (type: EntityType) => {
    switch (type) {
      case 'task':
        return <CheckSquare className="w-4 h-4" />;
      case 'note':
        return <FileText className="w-4 h-4" />;
      case 'project':
        return <Folder className="w-4 h-4" />;
      default:
        return <Plus className="w-4 h-4" />;
    }
  };

  const getEntityColor = (type: EntityType) => {
    switch (type) {
      case 'task':
        return 'bg-blue-100 text-blue-800';
      case 'note':
        return 'bg-green-100 text-green-800';
      case 'project':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const availableEntityTypes = (['task', 'note', 'project'] as EntityType[]).filter(
    type => type !== sourceType
  );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button size="sm" variant="outline">
            <Plus className="w-4 h-4 sm:mr-1" />
            <span className="hidden sm:inline">Link Item</span>
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] max-w-[95vw] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Link Related Item</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Item Type</label>
            <Select value={targetType} onValueChange={(value: EntityType) => setTargetType(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {availableEntityTypes.map((type) => (
                  <SelectItem key={type} value={type}>
                    <div className="flex items-center gap-2">
                      {getEntityIcon(type)}
                      <Badge className={cn("text-xs", getEntityColor(type))}>
                        {type}
                      </Badge>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Select {targetType}</label>
            <Select value={targetId} onValueChange={setTargetId} disabled={loading}>
              <SelectTrigger>
                <SelectValue placeholder={`Choose a ${targetType} to link`} />
              </SelectTrigger>
              <SelectContent>
                {availableItems.map((item) => (
                  <SelectItem key={item.id} value={item.id}>
                    <div className="flex flex-col items-start">
                      <span className="font-medium">{item.title}</span>
                      <span className="text-xs text-muted-foreground">
                        {format(new Date(item.created_at), 'MMM d, yyyy')}
                      </span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            {availableItems.length === 0 && !loading && (
              <p className="text-xs text-muted-foreground">
                No {targetType}s available to link.
              </p>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleLink} 
              disabled={!targetId || loading}
            >
              {loading ? 'Linking...' : 'Link Item'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};