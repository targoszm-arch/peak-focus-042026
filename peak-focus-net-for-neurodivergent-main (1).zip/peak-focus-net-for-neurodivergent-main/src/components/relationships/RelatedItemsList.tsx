import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Link, Unlink, CheckSquare, FileText, Folder } from 'lucide-react';
import { useRelationships, type EntityType, type RelatedItem } from '@/hooks/useRelationships';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface RelatedItemsListProps {
  entityType: EntityType;
  entityId: string;
  onRefresh?: () => void;
}

export const RelatedItemsList = ({ entityType, entityId, onRefresh }: RelatedItemsListProps) => {
  const [relatedItems, setRelatedItems] = useState<RelatedItem[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const { loading, getRelatedItems, deleteRelationship } = useRelationships();

  useEffect(() => {
    const fetchRelatedItems = async () => {
      setRefreshing(true);
      const items = await getRelatedItems(entityType, entityId);
      setRelatedItems(items);
      setRefreshing(false);
    };

    if (entityId) {
      fetchRelatedItems();
    }
  }, [entityType, entityId, getRelatedItems]);

  const handleUnlink = async (relationshipId: string) => {
    const success = await deleteRelationship(relationshipId);
    if (success) {
      const updatedItems = await getRelatedItems(entityType, entityId);
      setRelatedItems(updatedItems);
      onRefresh?.();
    }
  };

  const getEntityIcon = (type: EntityType) => {
    switch (type) {
      case 'task':
        return <CheckSquare className="w-4 h-4" />;
      case 'note':
        return <FileText className="w-4 h-4" />;
      case 'project':
        return <Folder className="w-4 h-4" />;
      default:
        return <Link className="w-4 h-4" />;
    }
  };

  const getEntityColor = (type: EntityType) => {
    switch (type) {
      case 'task':
        return 'bg-blue-100 text-blue-800';
      case 'note':
        return 'bg-green-100 text-green-800';
      case 'project':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if ((loading || refreshing) && relatedItems.length === 0) {
    return <div className="text-sm text-muted-foreground">Loading related items...</div>;
  }

  if (relatedItems.length === 0) {
    return (
      <div className="text-center py-4 text-muted-foreground">
        <Link className="w-6 h-6 mx-auto mb-2 opacity-50" />
        <p className="text-sm">No related items found.</p>
      </div>
    );
  }

  return (
    <TooltipProvider>
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <h4 className="text-sm font-medium flex items-center gap-2">
            <Link className="w-4 h-4" />
            Related Items
          </h4>
          <Badge variant="secondary" className="text-xs">
            {relatedItems.length}
          </Badge>
        </div>

        <div className="space-y-2">
          {relatedItems.map((item) => (
            <Card key={item.relationship_id} className="border-l-4 border-l-primary/30">
              <CardContent className="p-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      {getEntityIcon(item.related_type)}
                      <Badge className={cn("text-xs", getEntityColor(item.related_type))}>
                        {item.related_type}
                      </Badge>
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium truncate">
                        {item.related_title}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(item.related_created_at), 'MMM d, yyyy')}
                      </p>
                    </div>
                  </div>
                  
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
                            disabled={loading}
                          >
                            <Unlink className="w-3 h-3" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Remove Link</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to unlink "{item.related_title}"? This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleUnlink(item.relationship_id)}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              Unlink
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </TooltipTrigger>
                    <TooltipContent>Remove link</TooltipContent>
                  </Tooltip>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </TooltipProvider>
  );
};