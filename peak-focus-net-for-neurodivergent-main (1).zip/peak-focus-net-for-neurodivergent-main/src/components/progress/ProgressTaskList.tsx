
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Clock, Timer, Play, CheckSquare, Target } from 'lucide-react';
import { PomodoroTaskTimer } from '@/components/pomodoro/PomodoroTaskTimer';
import { usePomodoroSessions } from '@/hooks/usePomodoroSessions';
import type { Task } from '@/types/database';

interface ProgressTaskListProps {
  tasks: Task[];
  onUpdateTask: (id: string, updates: Partial<Task>) => Promise<void>;
}

export const ProgressTaskList = ({
  tasks,
  onUpdateTask
}: ProgressTaskListProps) => {
  const [selectedTimerTask, setSelectedTimerTask] = useState<Task | null>(null);
  const { createPomodoroSession } = usePomodoroSessions();

  const priorityColors = {
    low: 'bg-green-100 text-green-800 border-green-200',
    medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    high: 'bg-orange-100 text-orange-800 border-orange-200',
    urgent: 'bg-red-100 text-red-800 border-red-200'
  };

  const statusColors = {
    todo: 'text-gray-600',
    in_progress: 'text-blue-600',
    completed: 'text-green-600 line-through',
    archived: 'text-gray-400'
  };

  // Filter tasks for today's date
  const getTodayTasks = () => {
    const today = new Date().toISOString().split('T')[0];
    
    return tasks.filter(task => {
      // Include tasks with due date today
      if (task.due_date === today) return true;
      
      // Include tasks created today that don't have a due date
      if (!task.due_date && task.created_at && task.created_at.startsWith(today)) return true;
      
      // Include active tasks without due dates (for ongoing work)
      if (!task.due_date && (task.status === 'todo' || task.status === 'in_progress')) return true;
      
      return false;
    });
  };

  const todayTasks = getTodayTasks();

  const handleStatusChange = (task: Task, completed: boolean) => {
    onUpdateTask(task.id, {
      status: completed ? 'completed' : 'todo',
      completion_date: completed ? new Date().toISOString() : undefined,
      actual_duration: completed ? task.estimated_duration : undefined
    });
  };

  const handlePomodoroSessionComplete = async (taskId: string, duration: number) => {
    try {
      await createPomodoroSession(taskId, duration);
      window.location.reload();
    } catch (error) {
      console.error('Failed to complete Pomodoro session:', error);
    }
  };

  const handleSessionsChange = async (taskId: string, change: number) => {
    const task = tasks.find(t => t.id === taskId);
    if (task) {
      const newSessions = Math.max(1, Math.min(10, task.pomodoro_sessions_planned + change));
      await onUpdateTask(taskId, {
        pomodoro_sessions_planned: newSessions
      });
    }
  };

  if (todayTasks.length === 0) {
    return (
      <Card className="text-center py-12">
        <CardContent>
          <div className="text-4xl mb-4">
            <Target className="w-16 h-16 mx-auto text-muted-foreground" />
          </div>
          <h3 className="text-lg font-medium mb-2">No tasks for today</h3>
          <p className="text-sm text-muted-foreground">
            Create your first task to start climbing your productivity mountain!
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <TooltipProvider>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckSquare className="w-5 h-5" />
            Today's Tasks
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {todayTasks.map(task => (
              <div
                key={task.id}
                className="p-4 bg-white rounded-lg border hover:shadow-md transition-all duration-200"
              >
                <div className="flex items-start gap-3">
                  <Checkbox
                    checked={task.status === 'completed'}
                    onCheckedChange={checked => handleStatusChange(task, !!checked)}
                    className="mt-1 flex-shrink-0"
                  />

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <h3 className={`font-medium truncate ${statusColors[task.status]}`}>
                        {task.title}
                      </h3>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <Badge className={priorityColors[task.priority]} variant="outline">
                          {task.priority}
                        </Badge>
                      </div>
                    </div>

                    {task.description && (
                      <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                        {task.description}
                      </p>
                    )}

                    <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        <span>{task.estimated_duration}min</span>
                      </div>

                      <div className="flex items-center gap-1">
                        <Timer className="w-3 h-3" />
                        <span>
                          {task.pomodoro_sessions_completed}/{task.pomodoro_sessions_planned}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {/* Future buttons/actions can be added here */}
                      </div>
                      <div className="ml-auto">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              size="icon"
                              variant="outline"
                              onClick={() => setSelectedTimerTask(task)}
                              disabled={task.status === 'completed'}
                              className="bg-blue-50 hover:bg-blue-100 border-blue-200 h-8 w-8"
                            >
                              <Play className="w-3 h-3" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            Start Focus Session ({task.pomodoro_sessions_planned * 25}min)
                          </TooltipContent>
                        </Tooltip>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Pomodoro Timer Modal */}
      {selectedTimerTask && (
        <PomodoroTaskTimer
          task={selectedTimerTask}
          open={!!selectedTimerTask}
          onClose={() => setSelectedTimerTask(null)}
          onSessionComplete={handlePomodoroSessionComplete}
        />
      )}
    </TooltipProvider>
  );
};
