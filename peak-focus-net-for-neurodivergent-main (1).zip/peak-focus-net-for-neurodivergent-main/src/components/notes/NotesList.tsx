
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Edit, Trash2, Search, FileText, Paperclip, MoreVertical, Download, Eye } from 'lucide-react';
import { format } from 'date-fns';
import { NoteForm } from './NoteForm';
import { useNoteAttachments } from '@/hooks/useNoteAttachments';
import { AttachmentsList } from './AttachmentsList';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import type { Note, Project } from '@/types/database';

interface NotesListProps {
  notes: Note[];
  projects: Project[];
  onUpdateNote: (id: string, updates: Partial<Note>) => Promise<void>;
  onDeleteNote: (id: string) => Promise<void>;
}

export const NotesList = ({ notes, projects, onUpdateNote, onDeleteNote }: NotesListProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProject, setSelectedProject] = useState<string>('all');
  const [expandedNotes, setExpandedNotes] = useState<Set<string>>(new Set());
  const [noteAttachments, setNoteAttachments] = useState<Record<string, number>>({});
  const { getAttachments } = useNoteAttachments();

  // Fetch attachment counts for all notes
  useEffect(() => {
    const fetchAttachmentCounts = async () => {
      const counts: Record<string, number> = {};
      for (const note of notes) {
        try {
          const attachments = await getAttachments(note.id);
          counts[note.id] = attachments.length;
        } catch (error) {
          console.error('Error fetching attachments for note:', note.id, error);
          counts[note.id] = 0;
        }
      }
      setNoteAttachments(counts);
    };

    if (notes.length > 0) {
      fetchAttachmentCounts();
    }
  }, [notes, getAttachments]);

  const filteredNotes = notes.filter(note => {
    const matchesSearch = note.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (note.content || '').toLowerCase().includes(searchTerm.toLowerCase());
    const matchesProject = selectedProject === 'all' || 
                          (selectedProject === 'no-project' ? !note.project_id : note.project_id === selectedProject);
    
    return matchesSearch && matchesProject;
  });

  const getProjectForNote = (projectId?: string) => {
    return projects.find(p => p.id === projectId);
  };

  const toggleNoteExpansion = (noteId: string) => {
    setExpandedNotes(prev => {
      const newSet = new Set(prev);
      if (newSet.has(noteId)) {
        newSet.delete(noteId);
      } else {
        newSet.add(noteId);
      }
      return newSet;
    });
  };

  const groupedNotes = filteredNotes.reduce((groups, note) => {
    const projectName = note.project_id 
      ? getProjectForNote(note.project_id)?.name || 'Unknown Project'
      : 'No Project';
    
    if (!groups[projectName]) {
      groups[projectName] = [];
    }
    groups[projectName].push(note);
    return groups;
  }, {} as Record<string, Note[]>);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative w-1/4">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search notes..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={selectedProject} onValueChange={setSelectedProject}>
          <SelectTrigger className="w-full sm:w-[200px]">
            <SelectValue placeholder="Filter by project" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Projects</SelectItem>
            <SelectItem value="no-project">No Project</SelectItem>
            {projects.map((project) => (
              <SelectItem key={project.id} value={project.id}>
                <div className="flex items-center">
                  <div 
                    className="w-3 h-3 rounded-full mr-2" 
                    style={{ backgroundColor: project.color }}
                  />
                  {project.name}
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {filteredNotes.length === 0 ? (
        <Card className="text-center py-8">
          <CardContent>
            <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">
              {searchTerm || selectedProject !== 'all' 
                ? 'No notes match your filters'
                : 'No notes yet. Create your first note to get started!'
              }
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {Object.entries(groupedNotes).map(([projectName, projectNotes]) => (
            <div key={projectName} className="space-y-4">
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-semibold">{projectName}</h3>
                <Badge variant="secondary" className="text-xs">
                  {projectNotes.length}
                </Badge>
              </div>
              <div className="space-y-3">
                {projectNotes.map((note) => {
                  const project = getProjectForNote(note.project_id);
                  const isExpanded = expandedNotes.has(note.id);
                  
                  return (
                     <Card key={note.id} className="hover:shadow-md transition-shadow">
                         <div className="flex items-center gap-4 p-4">
                        <div className="flex-1 min-w-0">
                          <div className="mb-2">
                            <div className="flex items-center gap-2">
                              <h4 className="font-medium text-sm truncate">
                                {note.title}
                              </h4>
                              {noteAttachments[note.id] > 0 && (
                                <div className="flex items-center gap-1 bg-secondary/50 px-2 py-1 rounded-full">
                                  <Paperclip className="h-3 w-3 text-secondary-foreground" />
                                  <span className="text-xs text-secondary-foreground font-medium">
                                    {noteAttachments[note.id]}
                                  </span>
                                </div>
                              )}
                            </div>
                             {project && (
                              <span className="text-xs text-muted-foreground truncate">{project.name}</span>
                             )}
                          </div>
                          <div className="flex items-center justify-between">
                            {note.content && (
                              <p className="text-xs text-muted-foreground truncate mr-4">
                                {note.content}
                              </p>
                            )}
                            <div className="flex items-center gap-2 flex-shrink-0">
                              <p className="text-xs text-muted-foreground">
                                {format(new Date(note.updated_at), 'MMM d')}
                              </p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                             <DropdownMenuContent align="end" className="w-48">
                               {noteAttachments[note.id] > 0 && (
                                 <DropdownMenuItem onClick={() => toggleNoteExpansion(note.id)}>
                                   <Eye className="w-4 h-4 mr-2" />
                                   {isExpanded ? 'Hide' : 'View'} Attachments ({noteAttachments[note.id]})
                                 </DropdownMenuItem>
                               )}
                               {noteAttachments[note.id] > 0 && <DropdownMenuSeparator />}
                              <NoteForm
                                note={note}
                                projects={projects}
                                onSubmit={(updates) => onUpdateNote(note.id, updates)}
                                trigger={
                                  <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                    <Edit className="w-4 h-4 mr-2" />
                                    Edit Note
                                  </DropdownMenuItem>
                                }
                              />
                              <DropdownMenuItem 
                                className="text-destructive focus:text-destructive"
                                onClick={() => onDeleteNote(note.id)}
                              >
                                <Trash2 className="w-4 h-4 mr-2" />
                                Delete Note
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </div>
                      
                      {isExpanded && noteAttachments[note.id] > 0 && (
                        <div className="px-4 pb-4 border-t">
                          <AttachmentsList 
                            noteId={note.id} 
                            onAttachmentDeleted={() => {
                              // Refresh attachment count after deletion
                              getAttachments(note.id).then(attachments => {
                                setNoteAttachments(prev => ({
                                  ...prev,
                                  [note.id]: attachments.length
                                }));
                              });
                            }}
                          />
                        </div>
                      )}
                    </Card>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
