
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Download, Trash2, File, Image, FileText, ExternalLink } from 'lucide-react';
import { useNoteAttachments } from '@/hooks/useNoteAttachments';
import type { NoteAttachment } from '@/types/database';

interface AttachmentsListProps {
  noteId: string;
  onAttachmentDeleted?: () => void;
}

export const AttachmentsList = ({ noteId, onAttachmentDeleted }: AttachmentsListProps) => {
  const [attachments, setAttachments] = useState<NoteAttachment[]>([]);
  const [loading, setLoading] = useState(true);
  const { deleteAttachment, getAttachments, getFileUrl } = useNoteAttachments();

  useEffect(() => {
    const fetchAttachments = async () => {
      setLoading(true);
      const data = await getAttachments(noteId);
      setAttachments(data);
      setLoading(false);
    };

    fetchAttachments();
  }, [noteId, getAttachments]);

  const handleOpen = async (attachment: NoteAttachment) => {
    try {
      console.log('[ATTACHMENTS] Opening file:', attachment.file_name);
      const url = await getFileUrl(attachment.file_path);
      if (url) {
        console.log('[ATTACHMENTS] File URL generated successfully');
        // For better file preview support, try to open in new tab
        const newWindow = window.open(url, '_blank');
        if (!newWindow) {
          // Fallback if popup blocked
          window.location.href = url;
        }
      } else {
        console.error('[ATTACHMENTS] Failed to get file URL');
      }
    } catch (error) {
      console.error('[ATTACHMENTS] Error opening file:', error);
    }
  };

  const handleDownload = async (attachment: NoteAttachment) => {
    const url = await getFileUrl(attachment.file_path);
    if (url) {
      const link = document.createElement('a');
      link.href = url;
      link.download = attachment.file_name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleDelete = async (attachment: NoteAttachment) => {
    const success = await deleteAttachment(attachment);
    if (success) {
      setAttachments(prev => prev.filter(a => a.id !== attachment.id));
      onAttachmentDeleted?.();
    }
  };

  const getFileIcon = (contentType: string | null) => {
    if (!contentType) return <File className="w-4 h-4" />;
    
    if (contentType.startsWith('image/')) {
      return <Image className="w-4 h-4" />;
    }
    if (contentType === 'application/pdf' || contentType.startsWith('text/')) {
      return <FileText className="w-4 h-4" />;
    }
    return <File className="w-4 h-4" />;
  };

  const formatFileSize = (bytes: number | null): string => {
    if (!bytes) return 'Unknown size';
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (loading) {
    return <div className="text-sm text-muted-foreground">Loading attachments...</div>;
  }

  if (attachments.length === 0) {
    return null;
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <h4 className="text-sm font-medium">Attachments</h4>
        <Badge variant="secondary" className="text-xs">
          {attachments.length}
        </Badge>
      </div>
      
      <div className="space-y-2">
        {attachments.map((attachment) => (
          <div
            key={attachment.id}
            className="flex items-center justify-between p-3 border rounded-lg"
          >
            <div className="flex items-center gap-2 min-w-0">
              {getFileIcon(attachment.content_type)}
              <div className="min-w-0">
                <p className="text-sm font-medium truncate">{attachment.file_name}</p>
                <p className="text-xs text-muted-foreground">
                  {formatFileSize(attachment.file_size)}
                </p>
              </div>
            </div>
            
            <div className="flex gap-1 flex-shrink-0">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleOpen(attachment)}
                title="Open attachment"
              >
                <ExternalLink className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleDownload(attachment)}
                title="Download attachment"
              >
                <Download className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleDelete(attachment)}
                title="Delete attachment"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
