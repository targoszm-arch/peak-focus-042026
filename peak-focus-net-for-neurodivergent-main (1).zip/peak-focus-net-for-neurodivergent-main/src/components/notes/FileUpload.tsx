
import { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Button } from '@/components/ui/button';
import { Upload, File, X, AlertTriangle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { validateFileType, validateFileSize, validateFileName } from '@/lib/security';
import { useToast } from '@/hooks/use-toast';

interface FileUploadProps {
  onFilesSelected: (files: File[]) => void;
  selectedFiles: File[];
  onRemoveFile: (index: number) => void;
  disabled?: boolean;
  maxFiles?: number;
  maxSize?: number; // in bytes
}

export const FileUpload = ({
  onFilesSelected,
  selectedFiles,
  onRemoveFile,
  disabled = false,
  maxFiles = 5,
  maxSize = 10 * 1024 * 1024, // 10MB
}: FileUploadProps) => {
  const { toast } = useToast();

  const onDrop = useCallback((acceptedFiles: File[], rejectedFiles: any[]) => {
    console.log('[SECURITY] File upload attempt:', {
      accepted: acceptedFiles.length,
      rejected: rejectedFiles.length
    });

    // Enhanced validation
    const validFiles: File[] = [];
    const invalidFiles: string[] = [];

    acceptedFiles.forEach((file) => {
      // Validate file type
      if (!validateFileType(file)) {
        invalidFiles.push(`${file.name}: Invalid file type`);
        return;
      }

      // Validate file size
      if (!validateFileSize(file, 10)) {
        invalidFiles.push(`${file.name}: File too large (max 10MB)`);
        return;
      }

      // Validate file name
      if (!validateFileName(file.name)) {
        invalidFiles.push(`${file.name}: Suspicious file extension`);
        return;
      }

      // Additional security check for file content type mismatch
      const extension = file.name.split('.').pop()?.toLowerCase();
      const expectedTypes: { [key: string]: string[] } = {
        'jpg': ['image/jpeg'],
        'jpeg': ['image/jpeg'],
        'png': ['image/png'],
        'gif': ['image/gif'],
        'webp': ['image/webp'],
        'pdf': ['application/pdf'],
        'doc': ['application/msword'],
        'docx': ['application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
        'txt': ['text/plain'],
        'csv': ['text/csv'],
      };

      if (extension && expectedTypes[extension] && !expectedTypes[extension].includes(file.type)) {
        invalidFiles.push(`${file.name}: File type doesn't match extension`);
        return;
      }

      validFiles.push(file);
    });

    // Handle rejected files
    rejectedFiles.forEach((rejection) => {
      const errors = rejection.errors.map((error: any) => error.message).join(', ');
      invalidFiles.push(`${rejection.file.name}: ${errors}`);
    });

    if (invalidFiles.length > 0) {
      toast({
        title: 'Some files were rejected',
        description: invalidFiles.slice(0, 3).join('; ') + (invalidFiles.length > 3 ? '...' : ''),
        variant: 'destructive',
      });
      console.warn('[SECURITY] Invalid files rejected:', invalidFiles);
    }

    if (validFiles.length > 0) {
      onFilesSelected(validFiles);
      toast({
        title: 'Files validated',
        description: `${validFiles.length} file(s) ready for upload.`,
      });
    }
  }, [onFilesSelected, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    disabled,
    maxFiles,
    maxSize,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.gif', '.webp'],
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'text/plain': ['.txt'],
      'text/csv': ['.csv'],
    },
  });

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileSecurityStatus = (file: File): { isSecure: boolean; warnings: string[] } => {
    const warnings: string[] = [];
    
    if (file.size > 5 * 1024 * 1024) { // 5MB warning
      warnings.push('Large file size');
    }
    
    if (file.type.startsWith('application/')) {
      warnings.push('Document file - scan before opening');
    }

    return {
      isSecure: warnings.length === 0,
      warnings,
    };
  };

  return (
    <div className="space-y-4">
      <div
        {...getRootProps()}
        className={cn(
          'border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors',
          isDragActive
            ? 'border-primary bg-primary/5'
            : 'border-muted-foreground/25 hover:border-primary/50',
          disabled && 'opacity-50 cursor-not-allowed'
        )}
      >
        <input {...getInputProps()} />
        <Upload className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
        <p className="text-sm text-muted-foreground">
          {isDragActive
            ? 'Drop files here...'
            : 'Drag & drop files here, or click to select'}
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          Max {maxFiles} files, up to {formatFileSize(maxSize)} each
        </p>
        <p className="text-xs text-orange-600 mt-1">
          ⚠️ Files are automatically scanned for security
        </p>
      </div>

      {selectedFiles.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-sm font-medium">Selected Files:</h4>
          {selectedFiles.map((file, index) => {
            const securityStatus = getFileSecurityStatus(file);
            return (
              <div
                key={index}
                className="flex items-center justify-between p-2 bg-muted rounded-lg"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <File className="w-4 h-4 flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{file.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatFileSize(file.size)}
                    </p>
                    {!securityStatus.isSecure && (
                      <div className="flex items-center gap-1 text-xs text-orange-600">
                        <AlertTriangle className="w-3 h-3" />
                        <span>{securityStatus.warnings.join(', ')}</span>
                      </div>
                    )}
                  </div>
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => onRemoveFile(index)}
                  disabled={disabled}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
