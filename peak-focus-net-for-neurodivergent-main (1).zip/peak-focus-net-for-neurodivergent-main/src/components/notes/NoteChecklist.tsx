import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Plus, Trash2, Edit2, Check, X, ListTodo } from 'lucide-react';
import { useNoteChecklists } from '@/hooks/useNoteChecklists';
import { cn } from '@/lib/utils';
import type { Database } from '@/integrations/supabase/types';

type Checklist = Database['public']['Tables']['checklists']['Row'];
type ChecklistItem = Database['public']['Tables']['checklist_items']['Row'];

interface NoteChecklistProps {
  noteId: string;
}

export const NoteChecklist = ({ noteId }: NoteChecklistProps) => {
  const [checklists, setChecklists] = useState<(Checklist & { items: ChecklistItem[] })[]>([]);
  const [newChecklistTitle, setNewChecklistTitle] = useState('');
  const [newItemTexts, setNewItemTexts] = useState<{ [checklistId: string]: string }>({});
  const [editingChecklist, setEditingChecklist] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');
  const [editingItem, setEditingItem] = useState<string | null>(null);
  const [editingItemText, setEditingItemText] = useState('');

  const {
    loading,
    getChecklists,
    createChecklist,
    updateChecklist,
    deleteChecklist,
    addChecklistItem,
    updateChecklistItem,
    deleteChecklistItem,
  } = useNoteChecklists();

  useEffect(() => {
    const fetchChecklists = async () => {
      const data = await getChecklists(noteId);
      setChecklists(data);
    };

    if (noteId) {
      fetchChecklists();
    }
  }, [noteId, getChecklists]);

  const refreshChecklists = async () => {
    const updatedChecklists = await getChecklists(noteId);
    setChecklists(updatedChecklists);
  };

  const handleCreateChecklist = async () => {
    if (!newChecklistTitle.trim()) return;
    
    const checklistId = await createChecklist(noteId, newChecklistTitle.trim());
    if (checklistId) {
      await refreshChecklists();
      setNewChecklistTitle('');
    }
  };

  const handleUpdateChecklist = async (checklistId: string) => {
    if (!editingTitle.trim()) return;
    
    const success = await updateChecklist(checklistId, editingTitle.trim());
    if (success) {
      await refreshChecklists();
      setEditingChecklist(null);
      setEditingTitle('');
    }
  };

  const handleDeleteChecklist = async (checklistId: string) => {
    const success = await deleteChecklist(checklistId);
    if (success) {
      await refreshChecklists();
    }
  };

  const handleAddItem = async (checklistId: string) => {
    const text = newItemTexts[checklistId]?.trim();
    if (!text) return;
    
    const itemId = await addChecklistItem(checklistId, text);
    if (itemId) {
      await refreshChecklists();
      setNewItemTexts(prev => ({ ...prev, [checklistId]: '' }));
    }
  };

  const handleUpdateItem = async (itemId: string, updates: { text?: string; completed?: boolean }) => {
    const success = await updateChecklistItem(itemId, updates);
    if (success) {
      await refreshChecklists();
      if (updates.text !== undefined) {
        setEditingItem(null);
        setEditingItemText('');
      }
    }
  };

  const handleDeleteItem = async (itemId: string) => {
    const success = await deleteChecklistItem(itemId);
    if (success) {
      await refreshChecklists();
    }
  };

  const startEditingChecklist = (checklist: Checklist) => {
    setEditingChecklist(checklist.id);
    setEditingTitle(checklist.title);
  };

  const startEditingItem = (item: ChecklistItem) => {
    setEditingItem(item.id);
    setEditingItemText(item.text);
  };

  const cancelEditingChecklist = () => {
    setEditingChecklist(null);
    setEditingTitle('');
  };

  const cancelEditingItem = () => {
    setEditingItem(null);
    setEditingItemText('');
  };

  if (loading && checklists.length === 0) {
    return <div className="text-sm text-muted-foreground">Loading checklists...</div>;
  }

  return (
    <TooltipProvider>
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <h4 className="text-sm font-medium flex items-center gap-2">
            <ListTodo className="w-4 h-4" />
            Checklists
          </h4>
          <Badge variant="secondary" className="text-xs">
            {checklists.length}
          </Badge>
        </div>

        {/* Create new checklist */}
        <div className="flex gap-2">
          <Input
            placeholder="New checklist title..."
            value={newChecklistTitle}
            onChange={(e) => setNewChecklistTitle(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleCreateChecklist()}
            className="flex-1"
            disabled={loading}
          />
          <Button
            onClick={handleCreateChecklist}
            disabled={!newChecklistTitle.trim() || loading}
            size="sm"
          >
            <Plus className="w-4 h-4 sm:mr-1" />
            <span className="hidden sm:inline">Add</span>
          </Button>
        </div>

        {/* Existing checklists */}
        <div className="space-y-3">
          {checklists.map((checklist) => {
            const completedCount = checklist.items.filter(item => item.completed).length;
            const totalCount = checklist.items.length;
            const completionPercentage = totalCount > 0 ? (completedCount / totalCount) * 100 : 0;
            
            return (
              <Card key={checklist.id} className="border-l-4 border-l-primary/50">
                <CardHeader className="pb-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 min-w-0 flex-1">
                      {editingChecklist === checklist.id ? (
                        <div className="flex gap-1 flex-1">
                          <Input
                            value={editingTitle}
                            onChange={(e) => setEditingTitle(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleUpdateChecklist(checklist.id);
                              if (e.key === 'Escape') cancelEditingChecklist();
                            }}
                            className="h-8 text-sm flex-1"
                            autoFocus
                            disabled={loading}
                          />
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleUpdateChecklist(checklist.id)}
                            disabled={loading}
                            className="h-8 w-8 p-0"
                          >
                            <Check className="w-3 h-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={cancelEditingChecklist}
                            className="h-8 w-8 p-0"
                          >
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                      ) : (
                        <>
                          <CardTitle className="text-base font-medium truncate">
                            {checklist.title}
                          </CardTitle>
                          <Badge variant="outline" className="text-xs whitespace-nowrap">
                            {completedCount}/{totalCount}
                          </Badge>
                          {totalCount > 0 && (
                            <div className="hidden sm:block text-xs text-muted-foreground">
                              {Math.round(completionPercentage)}% complete
                            </div>
                          )}
                        </>
                      )}
                    </div>
                    
                    {editingChecklist !== checklist.id && (
                      <div className="flex gap-1 flex-shrink-0">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => startEditingChecklist(checklist)}
                              className="h-8 w-8 p-0"
                              disabled={loading}
                            >
                              <Edit2 className="w-3 h-3" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>Edit checklist</TooltipContent>
                        </Tooltip>
                        
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
                                  disabled={loading}
                                >
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Delete Checklist</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Are you sure you want to delete "{checklist.title}"? This will also delete all its items. This action cannot be undone.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => handleDeleteChecklist(checklist.id)}
                                    className="bg-red-600 hover:bg-red-700"
                                  >
                                    Delete
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </TooltipTrigger>
                          <TooltipContent>Delete checklist</TooltipContent>
                        </Tooltip>
                      </div>
                    )}
                  </div>
                </CardHeader>

                <CardContent className="pt-0 space-y-3">
                  {/* Checklist items */}
                  <div className="space-y-2">
                    {checklist.items.map((item) => (
                      <div key={item.id} className="flex items-center gap-2 p-2 rounded bg-muted/30">
                        <Checkbox
                          checked={item.completed}
                          onCheckedChange={(checked) =>
                            handleUpdateItem(item.id, { completed: !!checked })
                          }
                          disabled={loading}
                          className="!h-5 !w-5 !min-w-[20px] !min-h-[20px] !max-w-[20px] !max-h-[20px] aspect-square !border-2 !rounded-md shrink-0"
                        />
                        
                        {editingItem === item.id ? (
                          <div className="flex gap-1 flex-1">
                            <Input
                              value={editingItemText}
                              onChange={(e) => setEditingItemText(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') handleUpdateItem(item.id, { text: editingItemText });
                                if (e.key === 'Escape') cancelEditingItem();
                              }}
                              className="h-8 text-sm flex-1"
                              autoFocus
                              disabled={loading}
                            />
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleUpdateItem(item.id, { text: editingItemText })}
                              disabled={loading}
                              className="h-8 w-8 p-0"
                            >
                              <Check className="w-3 h-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={cancelEditingItem}
                              className="h-8 w-8 p-0"
                            >
                              <X className="w-3 h-3" />
                            </Button>
                          </div>
                        ) : (
                          <>
                            <span className={cn(
                              "flex-1 text-sm break-words",
                              item.completed && "line-through text-muted-foreground"
                            )}>
                              {item.text}
                            </span>
                            <div className="flex gap-1 flex-shrink-0">
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => startEditingItem(item)}
                                    className="h-8 w-8 p-0"
                                    disabled={loading}
                                  >
                                    <Edit2 className="w-3 h-3" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>Edit item</TooltipContent>
                              </Tooltip>
                              
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <AlertDialog>
                                    <AlertDialogTrigger asChild>
                                      <Button
                                        size="sm"
                                        variant="ghost"
                                        className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
                                        disabled={loading}
                                      >
                                        <Trash2 className="w-3 h-3" />
                                      </Button>
                                    </AlertDialogTrigger>
                                    <AlertDialogContent>
                                      <AlertDialogHeader>
                                        <AlertDialogTitle>Delete Item</AlertDialogTitle>
                                        <AlertDialogDescription>
                                          Are you sure you want to delete this checklist item? This action cannot be undone.
                                        </AlertDialogDescription>
                                      </AlertDialogHeader>
                                      <AlertDialogFooter>
                                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                                        <AlertDialogAction
                                          onClick={() => handleDeleteItem(item.id)}
                                          className="bg-red-600 hover:bg-red-700"
                                        >
                                          Delete
                                        </AlertDialogAction>
                                      </AlertDialogFooter>
                                    </AlertDialogContent>
                                  </AlertDialog>
                                </TooltipTrigger>
                                <TooltipContent>Delete item</TooltipContent>
                              </Tooltip>
                            </div>
                          </>
                        )}
                      </div>
                    ))}

                    {/* Add new item */}
                    <div className="flex gap-2 pt-1">
                      <Input
                        placeholder="Add new item..."
                        value={newItemTexts[checklist.id] || ''}
                        onChange={(e) => setNewItemTexts(prev => ({ 
                          ...prev, 
                          [checklist.id]: e.target.value 
                        }))}
                        onKeyDown={(e) => e.key === 'Enter' && handleAddItem(checklist.id)}
                        className="h-8 text-sm flex-1"
                        disabled={loading}
                      />
                      <Button
                        onClick={() => handleAddItem(checklist.id)}
                        disabled={!newItemTexts[checklist.id]?.trim() || loading}
                        size="sm"
                        variant="ghost"
                        className="h-8 w-8 p-0"
                      >
                        <Plus className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {checklists.length === 0 && !loading && (
          <div className="text-center py-6 text-muted-foreground">
            <ListTodo className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No checklists yet. Create one to get started!</p>
          </div>
        )}
      </div>
    </TooltipProvider>
  );
};
