
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from '@/components/ui/dialog';
import { Plus, FileText, Shield, Link, CheckSquare } from 'lucide-react';
import { AttachmentsList } from './AttachmentsList';
import { NoteChecklist } from './NoteChecklist';
import { RelatedItemsList } from '@/components/relationships/RelatedItemsList';
import { LinkItemsDialog } from '@/components/relationships/LinkItemsDialog';
import { sanitizeHtml, sanitizeText } from '@/lib/security';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import type { Note, Project } from '@/types/database';

interface NoteFormProps {
  note?: Note;
  projects: Project[];
  onSubmit: (noteData: Partial<Note>) => Promise<void>;
  trigger?: React.ReactNode;
}

export const NoteForm = ({ note, projects, onSubmit, trigger }: NoteFormProps) => {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState(note?.title || '');
  const [content, setContent] = useState(note?.content || '');
  const [projectId, setProjectId] = useState(note?.project_id || 'no-project');
  const [relationshipsKey, setRelationshipsKey] = useState(0);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Sanitize inputs
    const sanitizedTitle = sanitizeText(title.trim());
    const sanitizedContent = content ? sanitizeHtml(content.trim()) : undefined;
    
    if (!sanitizedTitle) {
      toast({
        title: 'Invalid Input',
        description: 'Note title cannot be empty.',
        variant: 'destructive',
      });
      return;
    }

    // Check for potential security issues
    if (sanitizedTitle !== title.trim()) {
      console.warn('[SECURITY] Title was sanitized:', { original: title.trim(), sanitized: sanitizedTitle });
    }
    
    if (content && sanitizedContent !== content.trim()) {
      console.warn('[SECURITY] Content was sanitized');
      toast({
        title: 'Content Sanitized',
        description: 'Some potentially unsafe content was removed for security.',
      });
    }
    
    // Save/update the note
    await onSubmit({
      title: sanitizedTitle,
      content: sanitizedContent,
      project_id: projectId === 'no-project' ? undefined : projectId,
    });

    setOpen(false);
    if (!note) {
      // Reset form for new notes
      setTitle('');
      setContent('');
      setProjectId('no-project');
    }
  };


  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    // Basic length limit for title
    if (value.length > 200) {
      toast({
        title: 'Title too long',
        description: 'Note title must be less than 200 characters.',
        variant: 'destructive',
      });
      return;
    }
    setTitle(value);
  };

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    // Basic length limit for content
    if (value.length > 10000) {
      toast({
        title: 'Content too long',
        description: 'Note content must be less than 10,000 characters.',
        variant: 'destructive',
      });
      return;
    }
    setContent(value);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button>
            <Plus className="w-4 h-4 mr-2" />
            Add Note
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            {note ? 'Edit Note' : 'Create New Note'}
          </DialogTitle>
          <DialogDescription>
            {note ? 'Modify your note details and attachments.' : 'Create a new note with title and content.'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="title">Note Title</Label>
            <Input
              id="title"
              value={title}
              onChange={handleTitleChange}
              placeholder="Enter note title..."
              required
              maxLength={200}
            />
            <div className="flex justify-between items-center mt-1">
              <span className="text-xs text-muted-foreground">
                {title.length}/200 characters
              </span>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Shield className="w-3 h-3" />
                <span>Input validated</span>
              </div>
            </div>
          </div>

          <div>
            <Label>Project</Label>
            <Select value={projectId} onValueChange={setProjectId}>
              <SelectTrigger>
                <SelectValue placeholder="Select project" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="no-project">No Project</SelectItem>
                {projects.map((project) => (
                  <SelectItem key={project.id} value={project.id}>
                    <div className="flex items-center">
                      <div 
                        className="w-3 h-3 rounded-full mr-2" 
                        style={{ backgroundColor: project.color }}
                      />
                      {project.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="content">Content</Label>
            <Textarea
              id="content"
              value={content}
              onChange={handleContentChange}
              placeholder="Write your note content here..."
              rows={6}
              className="resize-none"
              maxLength={10000}
            />
            <div className="flex justify-between items-center mt-1">
              <span className="text-xs text-muted-foreground">
                {content.length}/10,000 characters
              </span>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <Shield className="w-3 h-3" />
                <span>Content will be sanitized</span>
              </div>
            </div>
          </div>

          {note && (
            <>
              <div className="border-t pt-6">
                <NoteChecklist noteId={note.id} />
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-medium">Related Items</h4>
                  <LinkItemsDialog 
                    sourceType="note" 
                    sourceId={note.id}
                    onLinked={() => setRelationshipsKey(prev => prev + 1)}
                  />
                </div>
                <RelatedItemsList 
                  key={relationshipsKey}
                  entityType="note" 
                  entityId={note.id}
                  onRefresh={() => setRelationshipsKey(prev => prev + 1)}
                />
              </div>
            </>
          )}

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={!title.trim()}>
              {note ? 'Update Note' : 'Create Note'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
