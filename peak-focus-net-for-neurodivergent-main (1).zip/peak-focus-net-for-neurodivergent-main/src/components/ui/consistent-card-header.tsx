
import React from 'react';
import { CardHeader } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface ConsistentCardHeaderProps {
  children: React.ReactNode;
  className?: string;
}

export const ConsistentCardHeader = ({ children, className }: ConsistentCardHeaderProps) => {
  return (
    <CardHeader className={cn("pb-2 pt-4 px-4 flex-shrink-0", className)}>
      {children}
    </CardHeader>
  );
};
