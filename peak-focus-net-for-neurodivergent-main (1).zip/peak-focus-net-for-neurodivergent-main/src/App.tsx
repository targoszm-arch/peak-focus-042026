
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider, useAuth } from '@/hooks/useAuth';
import { AuthForm } from '@/components/auth/AuthForm';
import { Dashboard } from '@/components/dashboard/Dashboard';

import { Mountain } from 'lucide-react';
import './App.css';

function AppContent() {
  const { user, loading: authLoading } = useAuth();

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 px-4">
        <div className="text-center max-w-sm w-full">
          <div className="flex justify-center mb-6">
            <Mountain className="w-16 h-16 text-indigo-600 animate-pulse" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800 mb-2">Peak Focus</h1>
          <p className="text-muted-foreground text-lg">Loading your productivity mountain...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthForm />;
  }

  return <Dashboard />;
}

function App() {
  return (
    <AuthProvider>
      <div className="min-h-screen w-full">
        <AppContent />
        <Toaster />
      </div>
    </AuthProvider>
  );
}

export default App;
