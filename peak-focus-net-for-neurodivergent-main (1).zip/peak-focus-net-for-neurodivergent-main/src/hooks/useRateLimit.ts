
import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface RateLimitState {
  isBlocked: boolean;
  attemptsLeft: number;
  blockedUntil: Date | null;
}

export const useRateLimit = () => {
  const [rateLimitState, setRateLimitState] = useState<RateLimitState>({
    isBlocked: false,
    attemptsLeft: 5,
    blockedUntil: null,
  });
  const { toast } = useToast();

  const checkRateLimit = useCallback(async (email: string, attemptType: 'signin' | 'signup' | 'reset'): Promise<boolean> => {
    try {
      const response = await fetch('/api/check-rate-limit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email,
          attemptType,
          userAgent: navigator.userAgent,
        }),
      });

      if (response.status === 429) {
        const data = await response.json();
        setRateLimitState({
          isBlocked: true,
          attemptsLeft: 0,
          blockedUntil: new Date(data.blockedUntil),
        });
        
        toast({
          title: 'Too Many Attempts',
          description: `Account temporarily blocked. Try again after ${new Date(data.blockedUntil).toLocaleTimeString()}.`,
          variant: 'destructive',
        });
        
        return false;
      }

      return true;
    } catch (error) {
      console.error('Rate limit check failed:', error);
      return true; // Allow on error to not block legitimate users
    }
  }, [toast]);

  const recordFailedAttempt = useCallback(async (email: string, attemptType: 'signin' | 'signup' | 'reset') => {
    try {
      await fetch('/api/record-failed-attempt', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email,
          attemptType,
          userAgent: navigator.userAgent,
        }),
      });
    } catch (error) {
      console.error('Failed to record attempt:', error);
    }
  }, []);

  const resetRateLimit = useCallback(async (email: string) => {
    try {
      await fetch('/api/reset-rate-limit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });
      
      setRateLimitState({
        isBlocked: false,
        attemptsLeft: 5,
        blockedUntil: null,
      });
    } catch (error) {
      console.error('Failed to reset rate limit:', error);
    }
  }, []);

  return {
    rateLimitState,
    checkRateLimit,
    recordFailedAttempt,
    resetRateLimit,
  };
};
