
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import type { Task } from '@/types/database';

export const usePomodoroSessions = () => {
  const [isLoading, setIsLoading] = useState(false);

  const createPomodoroSession = async (taskId: string, durationMinutes: number) => {
    setIsLoading(true);
    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('User not authenticated');
      }

      // Create the Pomodoro session record
      const { error: sessionError } = await supabase
        .from('pomodoro_sessions')
        .insert({
          user_id: user.id,
          task_id: taskId,
          duration_minutes: durationMinutes,
          completed_at: new Date().toISOString(),
        });

      if (sessionError) {
        console.error('Error creating Pomodoro session:', sessionError);
        throw sessionError;
      }

      // Update task pomodoro_sessions_completed count
      const { data: currentTask, error: fetchError } = await supabase
        .from('tasks')
        .select('pomodoro_sessions_completed, pomodoro_sessions_planned, status')
        .eq('id', taskId)
        .single();

      if (fetchError) {
        console.error('Error fetching task:', fetchError);
        throw fetchError;
      }

      const newCompletedSessions = (currentTask.pomodoro_sessions_completed || 0) + 1;
      const isTaskComplete = newCompletedSessions >= currentTask.pomodoro_sessions_planned;

      // Update task with new session count and potentially complete status
      const { error: updateError } = await supabase
        .from('tasks')
        .update({
          pomodoro_sessions_completed: newCompletedSessions,
          status: isTaskComplete ? 'completed' : currentTask.status,
          completion_date: isTaskComplete ? new Date().toISOString() : undefined,
          actual_duration: isTaskComplete 
            ? newCompletedSessions * durationMinutes 
            : undefined
        })
        .eq('id', taskId);

      if (updateError) {
        console.error('Error updating task:', updateError);
        throw updateError;
      }

      // Update daily progress
      await updateDailyProgress(durationMinutes, isTaskComplete);

      console.log('Pomodoro session completed successfully:', {
        taskId,
        durationMinutes,
        newCompletedSessions,
        isTaskComplete
      });

    } catch (error) {
      console.error('Error in createPomodoroSession:', error);
      toast({
        title: "Error",
        description: "Failed to record Pomodoro session. Please try again.",
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const updateDailyProgress = async (minutesCompleted: number, taskCompleted: boolean) => {
    try {
      const today = new Date().toISOString().split('T')[0];
      
      // Get current daily progress
      const { data: currentProgress, error: fetchError } = await supabase
        .from('daily_progress')
        .select('*')
        .eq('date', today)
        .single();

      if (fetchError && fetchError.code !== 'PGRST116') { // PGRST116 = no rows found
        console.error('Error fetching daily progress:', fetchError);
        return;
      }

      const newMinutesCompleted = (currentProgress?.total_minutes_completed || 0) + minutesCompleted;
      const newTasksCompleted = (currentProgress?.total_tasks_completed || 0) + (taskCompleted ? 1 : 0);
      const totalMinutesPlanned = currentProgress?.total_minutes_planned || 480; // Default 8 hours
      const totalTasksPlanned = currentProgress?.total_tasks_planned || 8; // Default 8 tasks

      // Calculate mountain reduction percentage (0-100)
      const timeProgress = Math.min((newMinutesCompleted / totalMinutesPlanned) * 100, 100);
      const taskProgress = Math.min((newTasksCompleted / totalTasksPlanned) * 100, 100);
      const mountainReduction = Math.round((timeProgress + taskProgress) / 2);

      // Calculate sky reveal level (1-10)
      const skyRevealLevel = Math.min(Math.floor(mountainReduction / 10) + 1, 10);

      const progressData = {
        user_id: (await supabase.auth.getUser()).data.user?.id,
        date: today,
        total_tasks_completed: newTasksCompleted,
        total_minutes_completed: newMinutesCompleted,
        total_tasks_planned: totalTasksPlanned,
        total_minutes_planned: totalMinutesPlanned,
        mountain_reduction_percentage: mountainReduction,
        sky_reveal_level: skyRevealLevel,
        updated_at: new Date().toISOString()
      };

      if (currentProgress) {
        // Update existing progress
        const { error: updateError } = await supabase
          .from('daily_progress')
          .update(progressData)
          .eq('id', currentProgress.id);

        if (updateError) {
          console.error('Error updating daily progress:', updateError);
        }
      } else {
        // Create new progress record
        const { error: insertError } = await supabase
          .from('daily_progress')
          .insert(progressData);

        if (insertError) {
          console.error('Error creating daily progress:', insertError);
        }
      }

      console.log('Daily progress updated:', {
        mountainReduction,
        skyRevealLevel,
        newMinutesCompleted,
        newTasksCompleted
      });

    } catch (error) {
      console.error('Error updating daily progress:', error);
    }
  };

  return {
    createPomodoroSession,
    isLoading
  };
};
