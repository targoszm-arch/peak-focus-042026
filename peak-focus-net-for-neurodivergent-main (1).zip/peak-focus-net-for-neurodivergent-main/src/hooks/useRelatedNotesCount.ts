import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import type { EntityType } from '@/hooks/useRelationships';

export const useRelatedNotesCount = (entityType: EntityType, entityId: string) => {
  const [noteCount, setNoteCount] = useState(0);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchNotesCount = async () => {
      if (!entityId) return;

      try {
        setLoading(true);
        
        const { data: user } = await supabase.auth.getUser();
        if (!user.user) return;

        // Count relationships where this entity is linked to notes
        const { count, error } = await supabase
          .from('relationships')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', user.user.id)
          .or(`and(source_type.eq.${entityType},source_id.eq.${entityId},target_type.eq.note),and(target_type.eq.${entityType},target_id.eq.${entityId},source_type.eq.note)`);

        if (error) {
          console.error('Error fetching notes count:', error);
          return;
        }

        setNoteCount(count || 0);
      } catch (error) {
        console.error('Error fetching notes count:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchNotesCount();
  }, [entityType, entityId]);

  return { noteCount, loading };
};