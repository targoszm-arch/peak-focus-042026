import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export type EntityType = 'task' | 'note' | 'project';

export interface RelatedItem {
  relationship_id: string;
  related_type: EntityType;
  related_id: string;
  related_title: string;
  related_created_at: string;
}

export const useRelationships = () => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const getRelatedItems = useCallback(async (
    entityType: EntityType,
    entityId: string
  ): Promise<RelatedItem[]> => {
    try {
      setLoading(true);
      
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) throw new Error('User not authenticated');

      const { data, error } = await supabase.rpc('get_related_items', {
        p_user_id: user.user.id,
        p_entity_type: entityType,
        p_entity_id: entityId
      });

      if (error) throw error;

      return (data || []) as RelatedItem[];
    } catch (error) {
      console.error('Error fetching related items:', error);
      toast({
        title: 'Error',
        description: 'Failed to load related items.',
        variant: 'destructive',
      });
      return [];
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const createRelationship = useCallback(async (
    sourceType: EntityType,
    sourceId: string,
    targetType: EntityType,
    targetId: string
  ): Promise<boolean> => {
    try {
      setLoading(true);
      
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) throw new Error('User not authenticated');

      const { error } = await supabase
        .from('relationships')
        .insert({
          user_id: user.user.id,
          source_type: sourceType,
          source_id: sourceId,
          target_type: targetType,
          target_id: targetId
        });

      if (error) {
        if (error.code === '23505') { // Unique constraint violation
          toast({
            title: 'Already linked',
            description: 'These items are already linked.',
            variant: 'destructive',
          });
          return false;
        }
        throw error;
      }

      toast({
        title: 'Success',
        description: 'Items linked successfully.',
      });

      return true;
    } catch (error) {
      console.error('Error creating relationship:', error);
      toast({
        title: 'Error',
        description: 'Failed to link items.',
        variant: 'destructive',
      });
      return false;
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const deleteRelationship = useCallback(async (relationshipId: string): Promise<boolean> => {
    try {
      setLoading(true);
      
      const { error } = await supabase
        .from('relationships')
        .delete()
        .eq('id', relationshipId);

      if (error) throw error;

      toast({
        title: 'Success',
        description: 'Link removed successfully.',
      });

      return true;
    } catch (error) {
      console.error('Error deleting relationship:', error);
      toast({
        title: 'Error',
        description: 'Failed to remove link.',
        variant: 'destructive',
      });
      return false;
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const getAvailableItems = useCallback(async (
    targetType: EntityType,
    excludeId?: string
  ): Promise<Array<{ id: string; title: string; created_at: string }>> => {
    try {
      setLoading(true);
      
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) throw new Error('User not authenticated');

      let data;

      if (targetType === 'project') {
        const { data: projectData, error } = await supabase
          .from('projects')
          .select('id, name, created_at')
          .eq('user_id', user.user.id)
          .order('created_at', { ascending: false });
        
        if (error) throw error;
        
        let filteredData = projectData || [];
        if (excludeId) {
          filteredData = filteredData.filter(item => item.id !== excludeId);
        }
        
        data = filteredData.map(item => ({ ...item, title: item.name }));
      } else {
        const { data: itemData, error } = await supabase
          .from(`${targetType}s`)
          .select('id, title, created_at')
          .eq('user_id', user.user.id)
          .order('created_at', { ascending: false });
        
        if (error) throw error;
        
        data = itemData || [];
        
        if (excludeId && data) {
          data = data.filter(item => item.id !== excludeId);
        }
      }

      return data || [];
    } catch (error) {
      console.error('Error fetching available items:', error);
      toast({
        title: 'Error',
        description: 'Failed to load available items.',
        variant: 'destructive',
      });
      return [];
    } finally {
      setLoading(false);
    }
  }, [toast]);

  return {
    loading,
    getRelatedItems,
    createRelationship,
    deleteRelationship,
    getAvailableItems,
  };
};