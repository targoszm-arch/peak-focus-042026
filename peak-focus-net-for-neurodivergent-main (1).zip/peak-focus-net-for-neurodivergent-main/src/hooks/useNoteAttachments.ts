
import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import type { NoteAttachment } from '@/types/database';

export const useNoteAttachments = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [uploading, setUploading] = useState(false);

  const uploadFile = async (file: File, noteId: string): Promise<NoteAttachment | null> => {
    if (!user) {
      console.error('[ATTACHMENTS] No user authenticated');
      toast({
        title: 'Authentication required',
        description: 'You must be logged in to upload files.',
        variant: 'destructive',
      });
      return null;
    }

    setUploading(true);
    
    try {
      console.log('[ATTACHMENTS] Starting upload for file:', file.name, 'size:', file.size, 'type:', file.type, 'noteId:', noteId);
      
      // Check if storage bucket exists first
      const { data: buckets, error: bucketError } = await supabase.storage.listBuckets();
      console.log('[ATTACHMENTS] Available buckets:', buckets?.map(b => b.name));
      
      if (bucketError) {
        console.error('[ATTACHMENTS] Bucket list error:', bucketError);
      }
      
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = `${user.id}/${noteId}/${fileName}`;
      
      console.log('[ATTACHMENTS] Upload path:', filePath);

      // Upload file to storage
      console.log('[ATTACHMENTS] Starting storage upload...');
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('note-files')
        .upload(filePath, file);

      console.log('[ATTACHMENTS] Upload result:', { data: uploadData, error: uploadError });

      if (uploadError) {
        console.error('[ATTACHMENTS] Upload error:', uploadError);
        toast({
          title: 'Upload failed',
          description: `Storage error: ${uploadError.message}`,
          variant: 'destructive',
        });
        return null;
      }
      
      console.log('[ATTACHMENTS] File uploaded to storage successfully');

      // Save attachment metadata to database
      const { data, error: dbError } = await supabase
        .from('note_attachments')
        .insert({
          note_id: noteId,
          user_id: user.id,
          file_name: file.name,
          file_path: filePath,
          file_size: file.size,
          content_type: file.type,
        })
        .select()
        .single();

      if (dbError) {
        console.error('[ATTACHMENTS] Database error:', dbError);
        // Clean up uploaded file
        await supabase.storage.from('note-files').remove([filePath]);
        
        toast({
          title: 'Failed to save attachment',
          description: dbError.message,
          variant: 'destructive',
        });
        return null;
      }

      console.log('[ATTACHMENTS] File uploaded successfully');
      toast({
        title: 'File uploaded',
        description: `${file.name} has been attached to the note.`,
      });

      return data;
    } catch (error) {
      console.error('[ATTACHMENTS] Unexpected error:', error);
      toast({
        title: 'Upload error',
        description: 'An unexpected error occurred during upload.',
        variant: 'destructive',
      });
      return null;
    } finally {
      setUploading(false);
    }
  };

  const deleteAttachment = async (attachment: NoteAttachment): Promise<boolean> => {
    if (!user) return false;

    try {
      console.log('[ATTACHMENTS] Deleting attachment:', attachment.id);

      // Delete from storage
      const { error: storageError } = await supabase.storage
        .from('note-files')
        .remove([attachment.file_path]);

      if (storageError) {
        console.error('[ATTACHMENTS] Storage delete error:', storageError);
      }

      // Delete from database
      const { error: dbError } = await supabase
        .from('note_attachments')
        .delete()
        .eq('id', attachment.id)
        .eq('user_id', user.id);

      if (dbError) {
        console.error('[ATTACHMENTS] Database delete error:', dbError);
        toast({
          title: 'Failed to delete attachment',
          description: dbError.message,
          variant: 'destructive',
        });
        return false;
      }

      toast({
        title: 'Attachment deleted',
        description: `${attachment.file_name} has been removed.`,
      });

      return true;
    } catch (error) {
      console.error('[ATTACHMENTS] Unexpected delete error:', error);
      toast({
        title: 'Delete error',
        description: 'Failed to delete attachment.',
        variant: 'destructive',
      });
      return false;
    }
  };

  const getAttachments = async (noteId: string): Promise<NoteAttachment[]> => {
    if (!user) return [];

    try {
      const { data, error } = await supabase
        .from('note_attachments')
        .select('*')
        .eq('note_id', noteId)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('[ATTACHMENTS] Error fetching attachments:', error);
        return [];
      }

      return data || [];
    } catch (error) {
      console.error('[ATTACHMENTS] Unexpected error fetching attachments:', error);
      return [];
    }
  };

  const getFileUrl = async (filePath: string): Promise<string | null> => {
    try {
      const { data } = await supabase.storage
        .from('note-files')
        .createSignedUrl(filePath, 3600); // 1 hour expiry

      return data?.signedUrl || null;
    } catch (error) {
      console.error('[ATTACHMENTS] Error getting file URL:', error);
      return null;
    }
  };

  return {
    uploading,
    uploadFile,
    deleteAttachment,
    getAttachments,
    getFileUrl,
  };
};
