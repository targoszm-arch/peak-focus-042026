
import { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { User, Session } from '@supabase/supabase-js';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  signUp: (email: string, password: string, userData?: { firstName: string; lastName: string }) => Promise<{ error: any }>;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ error: any }>;
  updatePassword: (password: string) => Promise<{ error: any }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Enhanced auth state cleanup utility
const cleanupAuthState = () => {
  console.log('🧹 Cleaning up auth state...');
  
  // Remove standard auth tokens
  localStorage.removeItem('supabase.auth.token');
  
  // Remove all Supabase auth keys from localStorage
  Object.keys(localStorage).forEach((key) => {
    if (key.startsWith('supabase.auth.') || key.includes('sb-')) {
      console.log('🧹 Removing auth key:', key);
      localStorage.removeItem(key);
    }
  });
  
  // Remove from sessionStorage if in use
  if (typeof sessionStorage !== 'undefined') {
    Object.keys(sessionStorage).forEach((key) => {
      if (key.startsWith('supabase.auth.') || key.includes('sb-')) {
        console.log('🧹 Removing session auth key:', key);
        sessionStorage.removeItem(key);
      }
    });
  }
};

// Improved URL parameter parsing for password reset detection
const parseUrlParameters = () => {
  const hash = window.location.hash.substring(1); // Remove the # symbol
  const search = window.location.search.substring(1); // Remove the ? symbol
  
  console.log('🔐 Parsing URL parameters:', { hash, search });
  
  const hashParams = new URLSearchParams(hash);
  const searchParams = new URLSearchParams(search);
  
  // Check both hash and search parameters
  const accessToken = hashParams.get('access_token') || searchParams.get('access_token');
  const refreshToken = hashParams.get('refresh_token') || searchParams.get('refresh_token');
  const type = hashParams.get('type') || searchParams.get('type');
  const error = hashParams.get('error') || searchParams.get('error');
  const errorDescription = hashParams.get('error_description') || searchParams.get('error_description');
  
  console.log('🔐 URL Parameters parsed:', { 
    accessToken: !!accessToken, 
    refreshToken: !!refreshToken, 
    type, 
    error, 
    errorDescription 
  });
  
  return { accessToken, refreshToken, type, error, errorDescription };
};

// Check if we're in password reset flow
const isPasswordResetFlow = () => {
  const { accessToken, type } = parseUrlParameters();
  const isRecovery = type === 'recovery';
  const hasTokens = !!accessToken;
  
  console.log('🔐 Password reset flow check:', { isRecovery, hasTokens, result: isRecovery && hasTokens });
  
  return isRecovery && hasTokens;
};

// Check if URL contains auth tokens from email confirmation
const checkForAuthTokensInUrl = () => {
  const { accessToken, refreshToken } = parseUrlParameters();
  
  const hasTokens = !!(accessToken || refreshToken);
  console.log('🔐 Auth tokens in URL check:', { hasTokens });
  
  return hasTokens;
};

// Clean URL of auth fragments
const cleanAuthUrl = () => {
  const { accessToken, refreshToken } = parseUrlParameters();
  
  if (accessToken || refreshToken) {
    console.log('🔐 Cleaning auth tokens from URL');
    // Replace current URL state without the auth tokens
    window.history.replaceState({}, document.title, window.location.pathname);
  }
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    console.log('🔐 Auth Provider initializing...');
    
    // Check URL parameters for auth flows
    const { type, error, errorDescription } = parseUrlParameters();
    
    if (error) {
      console.error('🔐 Auth error in URL:', error, errorDescription);
    }
    
    if (type) {
      console.log('🔐 Auth type detected in URL:', type);
    }
    
    // Listen for auth changes first
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log('🔐 Auth state changed:', event, session?.user?.email || 'no user');
      
      // Update state synchronously
      setSession(session);
      setUser(session?.user ?? null);
      
      if (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') {
        console.log('🔐 User signed in or token refreshed:', session?.user?.email);
        
        // Check if this is from password reset flow
        if (isPasswordResetFlow()) {
          console.log('🔐 Password reset flow detected, keeping URL for password update');
          // Don't clean URL yet - we need it for the PasswordUpdateForm
        } else if (checkForAuthTokensInUrl()) {
          console.log('🔐 Regular auth flow, cleaning URL');
          cleanAuthUrl();
        }
        
        setLoading(false);
      } else if (event === 'SIGNED_OUT') {
        console.log('🔐 User signed out');
        setLoading(false);
      } else if (event === 'INITIAL_SESSION') {
        console.log('🔐 Initial session loaded:', session?.user?.email || 'no session');
        
        // If we have a session from password reset, don't clean URL yet
        if (session && isPasswordResetFlow()) {
          console.log('🔐 Initial session from password reset, keeping URL');
        } else if (session && checkForAuthTokensInUrl()) {
          console.log('🔐 Initial session from regular auth flow, cleaning URL');
          cleanAuthUrl();
        }
        
        setLoading(false);
      } else if (event === 'PASSWORD_RECOVERY') {
        console.log('🔐 Password recovery event detected');
        setLoading(false);
      }
    });

    // Get initial session with better error handling
    const getInitialSession = async () => {
      try {
        console.log('🔐 Getting initial session...');
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('🔐 Error getting initial session:', error);
          
          // If it's a refresh token error, clean up and continue
          if (error.message?.includes('refresh_token_not_found') || error.message?.includes('Invalid Refresh Token')) {
            console.log('🔐 Refresh token error detected, cleaning up auth state');
            cleanupAuthState();
            setSession(null);
            setUser(null);
          }
          
          setLoading(false);
          return;
        }

        console.log('🔐 Initial session check:', session?.user?.email || 'no session');
        setSession(session);
        setUser(session?.user ?? null);
        
        // Don't clean URL if we're in password reset flow
        if (session && checkForAuthTokensInUrl() && !isPasswordResetFlow()) {
          console.log('🔐 Regular session with auth tokens, cleaning URL');
          cleanAuthUrl();
        }
        
        setLoading(false);
      } catch (error) {
        console.error('🔐 Exception getting initial session:', error);
        
        // Handle any other exceptions by cleaning up state
        console.log('🔐 Exception occurred, cleaning up auth state');
        cleanupAuthState();
        setSession(null);
        setUser(null);
        setLoading(false);
      }
    };

    getInitialSession();

    return () => subscription.unsubscribe();
  }, []);

  const signUp = async (email: string, password: string, userData?: { firstName: string; lastName: string }) => {
    console.log('🔐 Attempting signup for:', email);
    
    // Only clean up state if we're not already authenticated
    if (!session) {
      cleanupAuthState();
    }
    
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/`,
        data: {
          first_name: userData?.firstName || '',
          last_name: userData?.lastName || '',
          display_name: userData?.firstName ? `${userData.firstName} ${userData.lastName}`.trim() : ''
        }
      }
    });
    
    if (error) {
      console.error('🔐 Signup error:', error);
    } else {
      console.log('🔐 Signup successful for:', email);
    }
    
    return { error };
  };

  const signIn = async (email: string, password: string) => {
    console.log('🔐 Attempting signin for:', email);
    
    // Check if we already have a valid session
    const { data: { session: existingSession } } = await supabase.auth.getSession();
    
    if (existingSession?.user) {
      console.log('🔐 Already have valid session for:', existingSession.user.email);
      
      // If the existing session is for the same user, don't interfere
      if (existingSession.user.email === email) {
        console.log('🔐 Session matches sign-in email, using existing session');
        return { error: null };
      }
      
      // Only clean up if trying to sign in as different user
      console.log('🔐 Different user detected, cleaning up existing session');
      cleanupAuthState();
      await supabase.auth.signOut({ scope: 'global' });
    }
    
    const { error, data } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    
    if (error) {
      console.error('🔐 Signin error:', error.message, error);
      
      // Better error handling for specific cases
      if (error.message?.includes('Email not confirmed')) {
        return { 
          error: { 
            ...error, 
            message: 'Please check your email and click the confirmation link first.' 
          } 
        };
      }
    } else {
      console.log('🔐 Signin successful for:', email, data.user?.email);
    }
    
    return { error };
  };

  const signOut = async () => {
    console.log('🔐 Signing out...');
    
    try {
      await supabase.auth.signOut({ scope: 'global' });
      cleanupAuthState();
      // Clean URL in case there are any auth tokens
      cleanAuthUrl();
    } catch (error) {
      console.error('🔐 Signout error:', error);
      // Still clean up local state even if signout fails
      cleanupAuthState();
      cleanAuthUrl();
    }
  };

  const resetPassword = async (email: string) => {
    console.log('🔐 Attempting password reset for:', email);
    
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/`
    });
    
    if (error) {
      console.error('🔐 Password reset error:', error);
    } else {
      console.log('🔐 Password reset email sent to:', email);
    }
    
    return { error };
  };

  const updatePassword = async (password: string) => {
    console.log('🔐 Attempting password update...');
    
    const { error } = await supabase.auth.updateUser({
      password: password
    });
    
    if (error) {
      console.error('🔐 Password update error:', error);
    } else {
      console.log('🔐 Password updated successfully');
      // Clean URL after successful password update
      cleanAuthUrl();
    }
    
    return { error };
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      session, 
      loading, 
      signUp, 
      signIn, 
      signOut, 
      resetPassword, 
      updatePassword 
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Export utility functions for use in components
export { isPasswordResetFlow, parseUrlParameters };
