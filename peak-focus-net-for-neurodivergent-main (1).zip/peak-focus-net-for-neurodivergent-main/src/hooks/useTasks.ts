import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import type { Task, Project, DailyProgress } from '@/types/database';

export const useTasks = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [dailyProgress, setDailyProgress] = useState<DailyProgress | null>(null);
  const [loading, setLoading] = useState(true);
  const [operationLoading, setOperationLoading] = useState(false);

  // Fetch tasks
  const fetchTasks = async () => {
    if (!user) {
      console.log('[TASKS] No user, skipping fetch tasks');
      return;
    }

    try {
      console.log('[TASKS] Fetching tasks for user:', user.id);
      
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('[TASKS] Error fetching tasks:', error);
        toast({
          title: 'Error fetching tasks',
          description: error.message,
          variant: 'destructive',
        });
        return;
      }

      console.log('[TASKS] Successfully fetched tasks:', data?.length || 0);
      setTasks(data || []);
    } catch (error) {
      console.error('[TASKS] Unexpected error fetching tasks:', error);
      toast({
        title: 'Connection Error',
        description: 'Failed to load tasks. Please check your connection.',
        variant: 'destructive',
      });
    }
  };

  // Fetch projects
  const fetchProjects = async () => {
    if (!user) {
      console.log('[PROJECTS] No user, skipping fetch projects');
      return;
    }

    try {
      console.log('[PROJECTS] Fetching projects for user:', user.id);
      
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('[PROJECTS] Error fetching projects:', error);
        toast({
          title: 'Error fetching projects',
          description: error.message,
          variant: 'destructive',
        });
        return;
      }

      console.log('[PROJECTS] Successfully fetched projects:', data?.length || 0);
      setProjects(data || []);
    } catch (error) {
      console.error('[PROJECTS] Unexpected error fetching projects:', error);
    }
  };

  // Fetch today's progress
  const fetchDailyProgress = async () => {
    if (!user) return;

    try {
      const today = new Date().toISOString().split('T')[0];
      console.log('[PROGRESS] Fetching daily progress for:', today);
      
      const { data, error } = await supabase
        .from('daily_progress')
        .select('*')
        .eq('user_id', user.id)
        .eq('date', today)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        console.error('[PROGRESS] Error fetching daily progress:', error);
        return;
      }

      console.log('[PROGRESS] Daily progress fetched:', data ? 'found' : 'none');
      setDailyProgress(data);
    } catch (error) {
      console.error('[PROGRESS] Unexpected error fetching daily progress:', error);
    }
  };

  // Create task
  const saveTask = async (taskData: Partial<Task>): Promise<void> => {
    if (!user || !taskData.title) {
      console.error('[CREATE] Invalid task data:', { user: !!user, title: taskData.title });
      toast({
        title: 'Invalid task data',
        description: 'User or task title is missing',
        variant: 'destructive',
      });
      return;
    }

    setOperationLoading(true);
    
    try {
      console.log('[CREATE] Creating task:', taskData);
      
      const taskToInsert = {
        ...taskData,
        user_id: user.id,
        title: taskData.title.trim(),
        status: 'todo' as const,
        pomodoro_sessions_completed: 0,
      };

      const { error } = await supabase
        .from('tasks')
        .insert(taskToInsert);

      if (error) {
        console.error('[CREATE] Database error creating task:', error);
        toast({
          title: 'Failed to create task',
          description: error.message || 'Database operation failed',
          variant: 'destructive',
        });
        return;
      }

      console.log('[CREATE] Task created successfully');
      
      // Refresh data
      await Promise.all([fetchTasks(), updateDailyProgress()]);
      
      // Toast notification removed for task creation
    } catch (error) {
      console.error('[CREATE] Unexpected error creating task:', error);
      toast({
        title: 'Connection Error',
        description: 'Failed to create task. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setOperationLoading(false);
    }
  };

  // Update task with optimistic UI updates
  const updateTask = async (id: string, updates: Partial<Task>): Promise<void> => {
    if (!user) {
      console.error('[UPDATE] No user for task update');
      return;
    }

    setOperationLoading(true);
    
    // Optimistic update for immediate UI feedback
    setTasks(prevTasks => 
      prevTasks.map(task => 
        task.id === id ? { ...task, ...updates } : task
      )
    );

    // Optimistically update daily progress for mountain visualization
    if (updates.status) {
      console.log('[UPDATE] Task status changed, updating progress optimistically');
      await updateDailyProgress(true); // Pass true for optimistic update
    }
    
    try {
      console.log('[UPDATE] Updating task:', id, updates);
      
      const { error } = await supabase
        .from('tasks')
        .update(updates)
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) {
        console.error('[UPDATE] Database error updating task:', error);
        toast({
          title: 'Failed to update task',
          description: error.message || 'Database operation failed',
          variant: 'destructive',
        });
        
        // Revert optimistic update on error
        await fetchTasks();
        await fetchDailyProgress();
        return;
      }

      console.log('[UPDATE] Task updated successfully');
      
      // Refresh data to ensure consistency
      await Promise.all([fetchTasks(), updateDailyProgress()]);
      
    } catch (error) {
      console.error('[UPDATE] Unexpected error updating task:', error);
      toast({
        title: 'Connection Error',
        description: 'Failed to update task. Please try again.',
        variant: 'destructive',
      });
      
      // Revert optimistic update on error
      await fetchTasks();
      await fetchDailyProgress();
    } finally {
      setOperationLoading(false);
    }
  };

  // Delete task
  const deleteTask = async (id: string): Promise<void> => {
    if (!user) {
      console.error('[DELETE] No user for task deletion');
      return;
    }

    setOperationLoading(true);
    
    try {
      console.log('[DELETE] Deleting task:', id);
      
      const { error } = await supabase
        .from('tasks')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) {
        console.error('[DELETE] Database error deleting task:', error);
        toast({
          title: 'Failed to delete task',
          description: error.message || 'Database operation failed',
          variant: 'destructive',
        });
        return;
      }

      console.log('[DELETE] Task deleted successfully');
      
      // Refresh data
      await Promise.all([fetchTasks(), updateDailyProgress()]);
      
      toast({
        title: 'Task deleted',
        description: 'The task has been removed.',
      });
    } catch (error) {
      console.error('[DELETE] Unexpected error deleting task:', error);
      toast({
        title: 'Connection Error',
        description: 'Failed to delete task. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setOperationLoading(false);
    }
  };

  // Create project
  const saveProject = async (projectData: Partial<Project>): Promise<void> => {
    if (!user || !projectData.name) {
      console.error('[PROJECT] Invalid project data:', { user: !!user, name: projectData.name });
      toast({
        title: 'Invalid project data',
        description: 'User or project name is missing',
        variant: 'destructive',
      });
      return;
    }

    setOperationLoading(true);
    
    try {
      console.log('[PROJECT] Creating project:', projectData);
      
      const projectToInsert = {
        ...projectData,
        user_id: user.id,
        name: projectData.name.trim(),
      };

      const { error } = await supabase
        .from('projects')
        .insert(projectToInsert);

      if (error) {
        console.error('[PROJECT] Database error creating project:', error);
        toast({
          title: 'Failed to create project',
          description: error.message || 'Database operation failed',
          variant: 'destructive',
        });
        return;
      }

      console.log('[PROJECT] Project created successfully');
      await fetchProjects();
      
      // Toast notification removed for project creation
    } catch (error) {
      console.error('[PROJECT] Unexpected error creating project:', error);
      toast({
        title: 'Connection Error',
        description: 'Failed to create project. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setOperationLoading(false);
    }
  };

  // Update project
  const updateProject = async (id: string, updates: Partial<Project>): Promise<void> => {
    if (!user) {
      console.error('[PROJECT] No user for project update');
      return;
    }

    setOperationLoading(true);
    
    try {
      console.log('[PROJECT] Updating project:', id, updates);
      
      const { error } = await supabase
        .from('projects')
        .update(updates)
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) {
        console.error('[PROJECT] Database error updating project:', error);
        toast({
          title: 'Failed to update project',
          description: error.message || 'Database operation failed',
          variant: 'destructive',
        });
        return;
      }

      console.log('[PROJECT] Project updated successfully');
      await fetchProjects();
      
      // Toast notification removed for project updates
    } catch (error) {
      console.error('[PROJECT] Unexpected error updating project:', error);
      toast({
        title: 'Connection Error',
        description: 'Failed to update project. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setOperationLoading(false);
    }
  };

  // Delete project
  const deleteProject = async (id: string): Promise<void> => {
    if (!user) {
      console.error('[DELETE] No user for project deletion');
      return;
    }

    setOperationLoading(true);
    
    try {
      console.log('[DELETE] Deleting project:', id);
      
      const { error } = await supabase
        .from('projects')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) {
        console.error('[DELETE] Database error deleting project:', error);
        toast({
          title: 'Failed to delete project',
          description: error.message || 'Database operation failed',
          variant: 'destructive',
        });
        return;
      }

      console.log('[DELETE] Project deleted successfully');
      await fetchProjects();
      
    } catch (error) {
      console.error('[DELETE] Unexpected error deleting project:', error);
      toast({
        title: 'Connection Error',
        description: 'Failed to delete project. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setOperationLoading(false);
    }
  };

  // Calculate daily progress based on ALL tasks, not just today's
  const updateDailyProgress = async (isOptimistic = false) => {
    if (!user) return;

    try {
      console.log('[PROGRESS] Updating daily progress', isOptimistic ? '(optimistic)' : '');
      
      const today = new Date().toISOString().split('T')[0];
      
      // Get current tasks for calculation - ALL tasks, not filtered by date
      const currentTasks = isOptimistic ? tasks : await getCurrentTasks();
      console.log('[PROGRESS] Total tasks to analyze:', currentTasks.length);
      
      // Calculate based on ALL tasks
      const allTasks = currentTasks.filter(task => {
        // Include all tasks that are not deleted/archived
        return task.status === 'todo' || task.status === 'completed' || task.status === 'in_progress';
      });

      console.log('[PROGRESS] All relevant tasks:', allTasks.length, 'tasks');

      // Simple calculation based on ALL task completion
      const totalPlanned = Math.max(allTasks.length, 1); // Avoid division by zero
      const totalCompleted = allTasks.filter(task => task.status === 'completed').length;
      
      // Calculate time-based progress for today's tracking (but use all tasks for mountain)
      const todayTasks = allTasks.filter(task => {
        // Include tasks with due date today or completed today for time tracking
        return (task.due_date === today) || 
               (task.completion_date && task.completion_date.startsWith(today)) ||
               (!task.due_date && task.created_at && task.created_at.startsWith(today));
      });
      
      const totalMinutesPlanned = todayTasks.reduce((sum, task) => sum + (task.estimated_duration || 0), 0) || 480; // Default 8 hours
      const totalMinutesCompleted = todayTasks.reduce((sum, task) => {
        if (task.status === 'completed') {
          return sum + (task.actual_duration || task.estimated_duration || 0);
        }
        return sum;
      }, 0);
      
      // Calculate completion percentage (0-100) based on ALL tasks
      const completionPercentage = Math.round((totalCompleted / totalPlanned) * 100);
      
      // Sky reveal level increases gradually
      const skyRevealLevel = Math.min(Math.floor(completionPercentage / 10) + 1, 10);

      console.log('[PROGRESS] Simplified calculation:', {
        totalPlanned,
        totalCompleted,
        completionPercentage,
        skyRevealLevel,
        todayTasksCount: todayTasks.length
      });

      const progressData = {
        user_id: user.id,
        date: today,
        total_tasks_planned: totalPlanned,
        total_tasks_completed: totalCompleted,
        total_minutes_planned: totalMinutesPlanned,
        total_minutes_completed: totalMinutesCompleted,
        mountain_reduction_percentage: completionPercentage,
        sky_reveal_level: skyRevealLevel,
      };

      if (isOptimistic) {
        // Update local state immediately for UI responsiveness
        setDailyProgress(prev => prev ? { ...prev, ...progressData } : {
          id: '',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          ...progressData
        });
        console.log('[PROGRESS] Optimistic update applied:', completionPercentage, '% completion');
        return;
      }

      const { error } = await supabase
        .from('daily_progress')
        .upsert(progressData, { onConflict: 'user_id,date' });

      if (error) {
        console.error('[PROGRESS] Error updating daily progress:', error);
        return;
      }

      console.log('[PROGRESS] Daily progress updated successfully');
      await fetchDailyProgress();
    } catch (error) {
      console.error('[PROGRESS] Unexpected error updating daily progress:', error);
    }
  };

  // Helper function to get current tasks
  const getCurrentTasks = async (): Promise<Task[]> => {
    const { data } = await supabase
      .from('tasks')
      .select('*')
      .eq('user_id', user.id);
    
    return data || [];
  };

  useEffect(() => {
    const initializeData = async () => {
      if (user) {
        console.log('[INIT] Initializing data for user:', user.email);
        setLoading(true);
        
        try {
          await Promise.all([
            fetchTasks(),
            fetchProjects(),
            fetchDailyProgress()
          ]);
          console.log('[INIT] Data initialization complete');
        } catch (error) {
          console.error('[INIT] Error during data initialization:', error);
        } finally {
          setLoading(false);
        }
      } else {
        console.log('[INIT] No user, resetting state');
        setTasks([]);
        setProjects([]);
        setDailyProgress(null);
        setLoading(false);
      }
    };

    initializeData();
  }, [user]);

  return {
    tasks,
    projects,
    dailyProgress,
    loading,
    operationLoading,
    saveTask,
    updateTask,
    deleteTask,
    saveProject,
    updateProject,
    deleteProject,
    updateDailyProgress,
  };
};
