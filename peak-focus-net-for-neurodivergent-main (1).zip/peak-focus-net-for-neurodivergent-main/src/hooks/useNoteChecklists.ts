import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import type { Database } from '@/integrations/supabase/types';

type Checklist = Database['public']['Tables']['checklists']['Row'];
type ChecklistItem = Database['public']['Tables']['checklist_items']['Row'];

export const useNoteChecklists = () => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const getChecklists = useCallback(async (noteId: string): Promise<(Checklist & { items: ChecklistItem[] })[]> => {
    try {
      setLoading(true);
      
      const { data: checklists, error: checklistsError } = await supabase
        .from('checklists')
        .select('*')
        .eq('note_id', noteId)
        .order('created_at');

      if (checklistsError) throw checklistsError;

      if (!checklists || checklists.length === 0) {
        return [];
      }

      const checklistIds = checklists.map(c => c.id);
      const { data: items, error: itemsError } = await supabase
        .from('checklist_items')
        .select('*')
        .in('checklist_id', checklistIds)
        .order('created_at');

      if (itemsError) throw itemsError;

      return checklists.map(checklist => ({
        ...checklist,
        items: items?.filter(item => item.checklist_id === checklist.id) || []
      }));
    } catch (error) {
      console.error('Error fetching checklists:', error);
      toast({
        title: 'Error',
        description: 'Failed to load checklists.',
        variant: 'destructive',
      });
      return [];
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const createChecklist = useCallback(async (noteId: string, title: string): Promise<string | null> => {
    try {
      setLoading(true);
      
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('checklists')
        .insert({
          title,
          note_id: noteId,
          user_id: user.user.id
        })
        .select()
        .single();

      if (error) throw error;

      toast({
        title: 'Success',
        description: 'Checklist created successfully.',
      });

      return data.id;
    } catch (error) {
      console.error('Error creating checklist:', error);
      toast({
        title: 'Error',
        description: 'Failed to create checklist.',
        variant: 'destructive',
      });
      return null;
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const updateChecklist = useCallback(async (checklistId: string, title: string): Promise<boolean> => {
    try {
      setLoading(true);
      
      const { error } = await supabase
        .from('checklists')
        .update({ title })
        .eq('id', checklistId);

      if (error) throw error;

      toast({
        title: 'Success',
        description: 'Checklist updated successfully.',
      });

      return true;
    } catch (error) {
      console.error('Error updating checklist:', error);
      toast({
        title: 'Error',
        description: 'Failed to update checklist.',
        variant: 'destructive',
      });
      return false;
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const deleteChecklist = useCallback(async (checklistId: string): Promise<boolean> => {
    try {
      setLoading(true);
      
      const { error } = await supabase
        .from('checklists')
        .delete()
        .eq('id', checklistId);

      if (error) throw error;

      toast({
        title: 'Success',
        description: 'Checklist deleted successfully.',
      });

      return true;
    } catch (error) {
      console.error('Error deleting checklist:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete checklist.',
        variant: 'destructive',
      });
      return false;
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const addChecklistItem = useCallback(async (checklistId: string, text: string): Promise<string | null> => {
    try {
      setLoading(true);
      
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('checklist_items')
        .insert({
          text,
          checklist_id: checklistId,
          user_id: user.user.id
        })
        .select()
        .single();

      if (error) throw error;

      return data.id;
    } catch (error) {
      console.error('Error adding checklist item:', error);
      toast({
        title: 'Error',
        description: 'Failed to add checklist item.',
        variant: 'destructive',
      });
      return null;
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const updateChecklistItem = useCallback(async (itemId: string, updates: { text?: string; completed?: boolean }): Promise<boolean> => {
    try {
      setLoading(true);
      
      const updateData: any = { ...updates };
      if (updates.completed !== undefined) {
        updateData.completed_at = updates.completed ? new Date().toISOString() : null;
      }

      const { error } = await supabase
        .from('checklist_items')
        .update(updateData)
        .eq('id', itemId);

      if (error) throw error;

      return true;
    } catch (error) {
      console.error('Error updating checklist item:', error);
      toast({
        title: 'Error',
        description: 'Failed to update checklist item.',
        variant: 'destructive',
      });
      return false;
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const deleteChecklistItem = useCallback(async (itemId: string): Promise<boolean> => {
    try {
      setLoading(true);
      
      const { error } = await supabase
        .from('checklist_items')
        .delete()
        .eq('id', itemId);

      if (error) throw error;

      return true;
    } catch (error) {
      console.error('Error deleting checklist item:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete checklist item.',
        variant: 'destructive',
      });
      return false;
    } finally {
      setLoading(false);
    }
  }, [toast]);

  return {
    loading,
    getChecklists,
    createChecklist,
    updateChecklist,
    deleteChecklist,
    addChecklistItem,
    updateChecklistItem,
    deleteChecklistItem,
  };
};