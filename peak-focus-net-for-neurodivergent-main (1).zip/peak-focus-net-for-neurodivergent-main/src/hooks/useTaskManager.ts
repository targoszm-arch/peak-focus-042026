
import { useState, useEffect } from 'react';

const STORAGE_KEY = 'pomodoro_tasks';
const MAX_RECENT_TASKS = 10;

interface TaskManager {
  currentTask: string;
  recentTasks: string[];
  updateTask: (newTask: string) => void;
  selectTask: (task: string) => void;
  deleteTask: (task: string) => void;
  clearHistory: () => void;
}

export const useTaskManager = (defaultTask: string = 'Focus Session'): TaskManager => {
  const [currentTask, setCurrentTask] = useState(defaultTask);
  const [recentTasks, setRecentTasks] = useState<string[]>([]);

  // Load tasks from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const { current, recent } = JSON.parse(saved);
        if (current) setCurrentTask(current);
        if (Array.isArray(recent)) setRecentTasks(recent);
      }
    } catch (error) {
      console.error('Failed to load tasks from localStorage:', error);
    }
  }, []);

  // Save tasks to localStorage whenever they change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({
        current: currentTask,
        recent: recentTasks
      }));
    } catch (error) {
      console.error('Failed to save tasks to localStorage:', error);
    }
  }, [currentTask, recentTasks]);

  const addToRecentTasks = (task: string) => {
    setRecentTasks(prev => {
      const filtered = prev.filter(t => t !== task);
      const updated = [task, ...filtered].slice(0, MAX_RECENT_TASKS);
      return updated;
    });
  };

  const updateTask = (newTask: string) => {
    setCurrentTask(newTask);
    addToRecentTasks(newTask);
  };

  const selectTask = (task: string) => {
    setCurrentTask(task);
    addToRecentTasks(task);
  };

  const deleteTask = (task: string) => {
    setRecentTasks(prev => prev.filter(t => t !== task));
  };

  const clearHistory = () => {
    setRecentTasks([]);
  };

  return {
    currentTask,
    recentTasks,
    updateTask,
    selectTask,
    deleteTask,
    clearHistory
  };
};
