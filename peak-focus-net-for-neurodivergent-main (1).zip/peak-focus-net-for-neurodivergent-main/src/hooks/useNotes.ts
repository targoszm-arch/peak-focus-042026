import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { useNoteAttachments } from '@/hooks/useNoteAttachments';
import type { Note, NoteAttachment } from '@/types/database';

export const useNotes = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const { uploadFile } = useNoteAttachments();
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);
  const [operationLoading, setOperationLoading] = useState(false);

  const fetchNotes = async () => {
    if (!user) {
      console.log('[NOTES] No user, skipping fetch notes');
      return;
    }

    try {
      console.log('[NOTES] Fetching notes for user:', user.id);
      
      const { data, error } = await supabase
        .from('notes')
        .select('*')
        .eq('user_id', user.id)
        .order('updated_at', { ascending: false });

      if (error) {
        console.error('[NOTES] Error fetching notes:', error);
        toast({
          title: 'Error fetching notes',
          description: error.message,
          variant: 'destructive',
        });
        return;
      }

      console.log('[NOTES] Successfully fetched notes:', data?.length || 0);
      setNotes(data || []);
    } catch (error) {
      console.error('[NOTES] Unexpected error fetching notes:', error);
      toast({
        title: 'Connection Error',
        description: 'Failed to load notes. Please check your connection.',
        variant: 'destructive',
      });
    }
  };

  const saveNote = async (noteData: Partial<Note>, files?: File[]): Promise<void> => {
    if (!user || !noteData.title) {
      console.error('[NOTES] Invalid note data:', { user: !!user, title: noteData.title });
      toast({
        title: 'Invalid note data',
        description: 'User or note title is missing',
        variant: 'destructive',
      });
      return;
    }

    setOperationLoading(true);
    
    try {
      console.log('[NOTES] Creating note:', noteData);
      
      const noteToInsert = {
        ...noteData,
        user_id: user.id,
        title: noteData.title.trim(),
      };

      const { data: createdNote, error } = await supabase
        .from('notes')
        .insert(noteToInsert)
        .select()
        .single();

      if (error) {
        console.error('[NOTES] Database error creating note:', error);
        toast({
          title: 'Failed to create note',
          description: error.message || 'Database operation failed',
          variant: 'destructive',
        });
        return;
      }

      console.log('[NOTES] Note created successfully:', createdNote.id);

      // Upload files if any
      if (files && files.length > 0 && createdNote) {
        console.log('Files to upload after note creation:', files.length);
        console.log('[NOTES] Starting file uploads for note:', createdNote.id);
        
        try {
          const uploadPromises = files.map(file => {
            console.log('[NOTES] Creating upload promise for file:', file.name);
            return uploadFile(file, createdNote.id);
          });
          
          const uploadResults = await Promise.all(uploadPromises);
          console.log('[NOTES] Upload results:', uploadResults);
          
          const successfulUploads = uploadResults.filter(result => result !== null);
          console.log('[NOTES] Successful uploads:', successfulUploads.length, 'out of', files.length);
          
          if (successfulUploads.length > 0) {
            toast({
              title: 'Files uploaded',
              description: `${successfulUploads.length} file(s) attached successfully.`,
            });
          }
        } catch (uploadError) {
          console.error('[NOTES] File upload error:', uploadError);
          toast({
            title: 'Upload error',
            description: 'Some files failed to upload. Please try again.',
            variant: 'destructive',
          });
        }
      }

      await fetchNotes();
      
    } catch (error) {
      console.error('[NOTES] Unexpected error creating note:', error);
      toast({
        title: 'Connection Error',
        description: 'Failed to create note. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setOperationLoading(false);
    }
  };

  const updateNote = async (id: string, updates: Partial<Note>): Promise<void> => {
    if (!user) {
      console.error('[NOTES] No user for note update');
      return;
    }

    setOperationLoading(true);
    
    try {
      console.log('[NOTES] Updating note:', id, updates);
      
      const { error } = await supabase
        .from('notes')
        .update(updates)
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) {
        console.error('[NOTES] Database error updating note:', error);
        toast({
          title: 'Failed to update note',
          description: error.message || 'Database operation failed',
          variant: 'destructive',
        });
        return;
      }

      console.log('[NOTES] Note updated successfully');
      await fetchNotes();
      
    } catch (error) {
      console.error('[NOTES] Unexpected error updating note:', error);
      toast({
        title: 'Connection Error',
        description: 'Failed to update note. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setOperationLoading(false);
    }
  };

  const deleteNote = async (id: string): Promise<void> => {
    if (!user) {
      console.error('[NOTES] No user for note deletion');
      return;
    }

    setOperationLoading(true);
    
    try {
      console.log('[NOTES] Deleting note:', id);
      
      const { error } = await supabase
        .from('notes')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) {
        console.error('[NOTES] Database error deleting note:', error);
        toast({
          title: 'Failed to delete note',
          description: error.message || 'Database operation failed',
          variant: 'destructive',
        });
        return;
      }

      console.log('[NOTES] Note deleted successfully');
      await fetchNotes();
      
      toast({
        title: 'Note deleted',
        description: 'The note has been removed.',
      });
    } catch (error) {
      console.error('[NOTES] Unexpected error deleting note:', error);
      toast({
        title: 'Connection Error',
        description: 'Failed to delete note. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setOperationLoading(false);
    }
  };

  useEffect(() => {
    const initializeNotes = async () => {
      if (user) {
        console.log('[NOTES] Initializing notes for user:', user.email);
        setLoading(true);
        
        try {
          await fetchNotes();
          console.log('[NOTES] Notes initialization complete');
        } catch (error) {
          console.error('[NOTES] Error during notes initialization:', error);
        } finally {
          setLoading(false);
        }
      } else {
        console.log('[NOTES] No user, resetting notes state');
        setNotes([]);
        setLoading(false);
      }
    };

    initializeNotes();
  }, [user]);

  return {
    notes,
    loading,
    operationLoading,
    saveNote,
    updateNote,
    deleteNote,
  };
};
